import { attachDragRotate } from '../input/dragRotate.js';
import { createStarfield } from '../systems/starfield.js';
import { buildGoldberg } from '../systems/buildGoldberg.js';
import { createHubButtons } from '../ui/createHubButtons.js';
import { createLivingHubUI } from '../ui/createLivingHubUI.js';
import { getGlowLayers } from '../util/glow.js';

export function createScene(engine, canvas) {
  const scene = new BABYLON.Scene(engine);
  scene.clearColor = new BABYLON.Color3(0.01,0.01,0.05);

  // Camera
  const camera = new BABYLON.ArcRotateCamera('camera', -Math.PI/2, Math.PI/2.5, 8, BABYLON.Vector3.Zero(), scene);
  camera.inertia = 0.9; camera.angularSensibilityX = 500; camera.angularSensibilityY = 500;
  camera.panningSensibility = 50; camera.wheelPrecision = 50; camera.pinchPrecision = 50;
  camera.pinchDeltaPercentage = 0.01; camera.useNaturalPinchZoom = true;
  camera.minZ = 0.1; camera.maxZ = 100; camera.wheelDeltaPercentage = 0.01;

  // Lights (parented to camera as in your file)
  const mainLight = new BABYLON.DirectionalLight('mainLight', new BABYLON.Vector3(1.5,0,0), scene);
  mainLight.intensity = 1.8; mainLight.diffuse = new BABYLON.Color3(1.0,0.95,0.9); mainLight.parent = camera;
  const fillLight = new BABYLON.DirectionalLight('fillLight', new BABYLON.Vector3(-1.5,-1.5,0), scene);
  fillLight.intensity = 0.8; fillLight.diffuse = new BABYLON.Color3(0.8,0.8,1.0); fillLight.parent = camera;
  const topLight = new BABYLON.DirectionalLight('topLight', new BABYLON.Vector3(0,0,3), scene);
  topLight.intensity = 1.8; topLight.diffuse = new BABYLON.Color3(0.8,0.8,1.0); topLight.parent = camera;
  const shipLight = new BABYLON.SpotLight('shipLight', new BABYLON.Vector3(0.5,-0.5,-1.0), new BABYLON.Vector3(0.5,-0.5,-1.0), Math.PI, 2, scene);
  shipLight.diffuse = new BABYLON.Color3(0.9,0.95,1.0); shipLight.intensity = 0.8; shipLight.parent = camera;

  // Starfield
  createStarfield(scene);

  // Glow layers (one shared + specialized ones for UI)
  const glow = getGlowLayers(scene);

  // Build outer + inner goldberg for current level and setup level UI
  const gb = buildGoldberg(scene, glow.sharedGlow);
  const { goldberg, innerGoldberg, setLevel } = gb;


  // Drag-rotate inertial controls
  attachDragRotate(scene, canvas, goldberg);

  // UI (DOM HUD) & 3D hub buttons
  const living = createLivingHubUI(scene);
  const hub = createHubButtons(scene, camera, glow);
  living.hubButtons = hub; // wire-up if needed later

  // Export for console debugging
  window.hexverse = {
  scene, camera,
  goldberg, innerGoldberg,
  glow,
  living,
  hub,
  setLevel 
};
  return scene;
}