import React from 'react';
import { Stack, Typography, Button, Card, CardContent, Box } from '@mui/material';
import { styled } from '@mui/material/styles';

const SelectionContainer = styled(Box)(({ theme }) => ({
  position: 'fixed',
  inset: 0,
  zIndex: 1000,
  display: 'flex',
  flexDirection: 'column',
  background: 'radial-gradient(900px 600px at 20% 20%, #0d1730 0%, rgba(0,0,0,.6) 60%), #000',
  backdropFilter: 'blur(8px)',
  color: '#E8F0FF',
  fontFamily: 'Inter, Rajdhani, system-ui, sans-serif',
}));

const TopBar = styled(Box)(({ theme }) => ({
  position: 'sticky',
  top: 0,
  zIndex: 5,
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  padding: '12px 16px',
  background: 'linear-gradient(to bottom, rgba(10,14,19,0.95), rgba(10,14,19,0.75))',
  borderBottom: '1px solid rgba(255,255,255,.06)',
  backdropFilter: 'blur(6px)',
  [theme.breakpoints.down('sm')]: {
    padding: '8px 10px',
  },
}));

const ScrollArea = styled(Box)(({ theme }) => ({
  flex: 1,
  overflow: 'auto',
  WebkitOverflowScrolling: 'touch',
  padding: '16px',
  [theme.breakpoints.down('sm')]: {
    padding: '8px',
  },
}));

const GameCard = styled(Card)(({ theme }) => ({
  borderRadius: '22px',
  border: '1px solid rgba(255,255,255,.12)',
  background: 'linear-gradient(180deg, rgba(26,33,48,.7), rgba(12,16,26,.7))',
  color: '#E8F0FF',
  minHeight: '140px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  transition: 'transform .12s ease, box-shadow .12s ease, border-color .12s ease',
  cursor: 'pointer',
  '&:hover': {
    transform: 'translateY(-1px)',
    boxShadow: '0 12px 36px rgba(0,0,0,.5)',
    borderColor: 'rgba(0,229,255,.35)',
  },
  '&.locked': {
    opacity: 0.55,
    filter: 'grayscale(20%)',
    cursor: 'not-allowed',
  },
  [theme.breakpoints.down('sm')]: {
    minHeight: '120px',
    borderRadius: '16px',
  },
}));

const EnterButton = styled(Button)(({ theme }) => ({
  marginTop: '4px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '48px',
  borderRadius: '12px',
  border: '1px solid rgba(255,255,255,.16)',
  background: 'rgba(255,255,255,.06)',
  color: '#E8F0FF',
  fontWeight: 800,
  letterSpacing: '0.3px',
  fontSize: '16px',
  '&:hover': {
    background: 'rgba(255,255,255,.1)',
  },
  '&.locked': {
    pointerEvents: 'none',
    opacity: 0.7,
  },
  [theme.breakpoints.down('sm')]: {
    minHeight: '44px',
    fontSize: '14px',
  },
}));

const HubButton = styled(Button)(({ theme }) => ({
  border: '1px solid rgba(255,255,255,.14)',
  background: 'transparent',
  color: '#E8F0FF',
  padding: '10px 14px',
  borderRadius: '12px',
  fontWeight: 600,
  fontSize: '14px',
  minHeight: '44px',
  minWidth: '44px',
  '&:hover': {
    borderColor: '#2a3b56',
    transform: 'translateY(-1px)',
  },
  [theme.breakpoints.down('sm')]: {
    padding: '9px 12px',
    fontSize: '13px',
  },
}));

interface GameOption {
  key: string;
  name: string;
  description: string;
  available: boolean;
  cost?: number;
}

interface SelectionScreenProps {
  title: string;
  games: GameOption[];
  onGameSelect: (gameKey: string) => void;
  onBackToHub: () => void;
}

export const SelectionScreen: React.FC<SelectionScreenProps> = ({
  title,
  games,
  onGameSelect,
  onBackToHub,
}) => {
  return (
    <SelectionContainer>
      <TopBar>
        <HubButton onClick={onBackToHub}>
          Back to Hub
        </HubButton>
      </TopBar>
      
      <ScrollArea>
        <Stack spacing={3} sx={{ maxWidth: '820px', margin: '0 auto' }}>
          <Box sx={{ textAlign: 'center', mb: 2 }}>
            <Typography
              variant="h4"
              sx={{
                fontFamily: 'Orbitron, system-ui',
                fontWeight: 700,
                letterSpacing: '0.02em',
                color: '#00E5FF',
                textShadow: '0 0 10px rgba(0, 229, 255, 0.3)',
                fontSize: { xs: '1.3rem', sm: '1.5rem', md: '2rem' },
              }}
            >
              {title}
            </Typography>
          </Box>
          
          <Stack spacing={2}>
            {games.map((game) => (
              <GameCard
                key={game.key}
                className={!game.available ? 'locked' : ''}
                onClick={() => game.available && onGameSelect(game.key)}
              >
                <CardContent sx={{ p: '14px 16px', flex: 1 }}>
                  <Stack spacing={1}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography
                        variant="h6"
                        sx={{
                          fontFamily: 'Orbitron, system-ui',
                          fontWeight: 700,
                          letterSpacing: '0.3px',
                          fontSize: '1.05rem',
                        }}
                      >
                        {game.name}
                      </Typography>
                    </Box>
                    
                    <Typography
                      variant="body2"
                      sx={{
                        color: '#9FB0C7',
                        fontSize: '0.9rem',
                        lineHeight: 1.3,
                        opacity: 0.8,
                      }}
                    >
                      {game.description}
                    </Typography>
                    
                    {game.cost && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                        <Box
                          sx={{
                            width: 8,
                            height: 8,
                            borderRadius: '50%',
                            background: '#7aa2ff',
                            opacity: 0.9,
                          }}
                        />
                        <Typography
                          variant="caption"
                          sx={{
                            color: game.available ? '#9FB0C7' : '#ef4444',
                            fontWeight: 600,
                          }}
                        >
                          Energy: {game.cost}
                        </Typography>
                      </Box>
                    )}
                  </Stack>
                  
                  <EnterButton
                    className={!game.available ? 'locked' : ''}
                    fullWidth
                    sx={{ mt: 2 }}
                  >
                    {game.available ? 'ENTER' : 'NEED ENERGY'}
                  </EnterButton>
                </CardContent>
              </GameCard>
            ))}
          </Stack>
        </Stack>
      </ScrollArea>
    </SelectionContainer>
  );
};