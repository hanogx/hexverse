// src/shared/SaveStore.js
const NS = 'hexverse:';

function safeParse(v, fallback) {
  try { return v == null ? fallback : JSON.parse(v); } catch(e) { return fallback; }
}

export const SaveStore = {
  get(key, fallback=null) { return safeParse(localStorage.getItem(NS + key), fallback); },
  set(key, value)        { localStorage.setItem(NS + key, JSON.stringify(value)); },
  del(key)               { localStorage.removeItem(NS + key); },

  // Profiles
  getProfile() {
    return this.get('profile', { xp:0, level:1, coins:0, energy:5, seenTutorial:false });
  },
  updateProfile(patch) {
    const p = { ...this.getProfile(), ...patch };
    this.set('profile', p);
    return p;
  },

  // Settings
  getSettings() {
    return this.get('settings', { audio:true, music:true, sfx:true, lang:'tr' });
  },
  updateSettings(patch) {
    const s = { ...this.getSettings(), ...patch };
    this.set('settings', s);
    return s;
  },

  // Counters
  inc(key, by=1) {
    const v = this.get('cnt:'+key, 0) + by;
    this.set('cnt:'+key, v);
    return v;
  }
};

/* DEV seed (?seedDev=1) */
(function () {
  try {
    var usp = new URLSearchParams((window && window.location && window.location.search) || "");
    if (usp.get('seedDev') === '1') {
      SaveStore.updateProfile({ level: 8, energy: 50 });
      SaveStore.set('cnt:pentaRelic', 10);
      console.log('[SaveStore] Seeded dev values (level=8, energy=50, pentaRelic=10)');
    }
  } catch (e) { /* no-op */ }
})();