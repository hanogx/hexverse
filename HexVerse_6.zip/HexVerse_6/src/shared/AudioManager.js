// src/shared/AudioManager.js
import { SaveStore } from './SaveStore.js';

const cache = new Map();
let musicNode = null;

function loadAudio(name) {
  if (cache.has(name)) return cache.get(name);
  const a = new Audio(`assets/audio/${name}.mp3`);
  a.preload = 'auto';
  cache.set(name, a);
  return a;
}

export const AudioManager = {
  init() {
    const s = SaveStore.getSettings();
    // Warmup common sounds (optional)
    ['click','hit','reward','ambient'].forEach(n => loadAudio(n));
    if (s.music) this.playMusic('ambient', true);
  },
  playSfx(name) {
    const s = SaveStore.getSettings();
    if (!s.sfx) return;
    const a = loadAudio(name).cloneNode();
    a.volume = 0.8;
    a.play().catch(()=>{});
  },
  playMusic(name, loop=true) {
    const s = SaveStore.getSettings();
    if (!s.music) return;
    if (musicNode) { try { musicNode.pause(); } catch{} }
    musicNode = loadAudio(name);
    musicNode.loop = loop;
    musicNode.volume = 0.5;
    musicNode.play().catch(()=>{});
  },
  setMusicEnabled(on) {
    SaveStore.updateSettings({ music: !!on });
    if (on) this.playMusic('ambient', true);
    else if (musicNode) { try { musicNode.pause(); } catch{} }
  },
  setSfxEnabled(on) {
    SaveStore.updateSettings({ sfx: !!on });
  }
};
