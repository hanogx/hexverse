// src/shared/PlanetState.js
import { levelData } from '../systems/levelData.js';
import { SaveStore } from './SaveStore.js';

const KEYS = ['solar','electro','gravity','dark']; // 'electro' is EM

export function getGoldbergLevel(){
  return SaveStore.get('goldberg.level', 0);
}

export function setGoldbergLevel(n){
  SaveStore.set('goldberg.level', n);
}

export function getTotalsForLevel(level){
  const idx = Math.max(0, Math.min(level, levelData.length-1));
  const L = levelData[idx] || { solar:0, electro:0, gravity:0, dark:0 };
  // Map to UI keys: solar, em, gravity, dark
  return {
    solar:   L.solar   || 0,
    em:      L.electro || 0,
    gravity: L.gravity || 0,
    dark:    L.dark    || 0
  };
}

export function getActiveCounts(){
  return {
    solar:   SaveStore.get('hex.active.goldberg.solar', 0),
    em:      SaveStore.get('hex.active.goldberg.em', 0),
    gravity: SaveStore.get('hex.active.goldberg.gravity', 0),
    dark:    SaveStore.get('hex.active.goldberg.dark', 0),
  };
}

export function incActive(energy, by=1){
  const mapKey = { solar:'solar', em:'em', gravity:'gravity', dark:'dark' }[energy] || energy;
  const key = `hex.active.goldberg.${mapKey}`;
  SaveStore.set(key, (SaveStore.get(key, 0) + by));
}

export function getOverview(){
  const level = getGoldbergLevel();
  const totals = getTotalsForLevel(level);
  const active = getActiveCounts();
  const rows = {};
  let recommended = 'solar', bestNeed = -1;
  for (const k of ['solar','em','gravity','dark']){
    const total = totals[k] || 0;
    const act = active[k] || 0;
    const need = Math.max(0, total - act);
    const eff = total ? (act / total) : 0;
    rows[k] = { total, active: act, need, eff };
    if (need > bestNeed){ bestNeed = need; recommended = k; }
  }
  return { level, rows, recommended };
}
