// src/shared/Config.js
import { SaveStore } from './SaveStore.js';

const DEFAULTS = {
  rewards: { winCoins: 15, loseCoins: 3, xpPerHex: 5 },
  energy:  { max: 10, costPerRun: 1, regenMins: 15 },
  drop:    { coreShard: 0.07, darkMatter: 0.04 },
  difficulty: { baseSpeed: 1.0, accel: 0.02 },
};

function deepMerge(a, b) {
  const out = { ...a };
  for (const k in b) {
    if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])) out[k] = deepMerge(a[k] || {}, b[k]);
    else out[k] = b[k];
  }
  return out;
}

const stored = SaveStore.get('configOverrides', {});
const injected = typeof window !== 'undefined' && window.HEXVERSE_CONFIG ? window.HEXVERSE_CONFIG : {};
export const Config = deepMerge(DEFAULTS, deepMerge(stored, injected));

export function setConfigOverrides(patch) {
  const merged = deepMerge(SaveStore.get('configOverrides', {}), patch);
  SaveStore.set('configOverrides', merged);
  return merged;
}
