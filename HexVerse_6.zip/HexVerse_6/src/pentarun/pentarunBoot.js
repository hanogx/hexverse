import { GameManager } from "./game/Game.js";

export async function bootstrapScene(engine, canvas) {
  const scene = new BABYLON.Scene(engine);
  scene.clearColor = new BABYLON.Color4(0.01,0.01,0.02,1.0);

  // Legacy Penta camera & light defaults — replace with exact values from Pentarun.html
  const camera = new BABYLON.ArcRotateCamera("cam", -Math.PI/2, 1.1, 30, BABYLON.Vector3.Zero(), scene);
  camera.attachControl(canvas, true);
  const light = new BABYLON.HemisphericLight("h", new BABYLON.Vector3(0,1,0), scene);
  light.intensity = 1.0;

  return { engine, scene, camera, light };
}

export async function startCoreRun(ctx) {
  const gm = new GameManager(ctx.scene);
  if (gm.startCoreRun) gm.startCoreRun();
  return gm;
}

export async function startPentaStage(ctx, stage) {
  const gm = new GameManager(ctx.scene);
  if (gm.startStage) gm.startStage(stage);
  return gm;
}

export async function startPentaSelect(ctx) {
  const gm = new GameManager(ctx.scene);
  return gm;
}
