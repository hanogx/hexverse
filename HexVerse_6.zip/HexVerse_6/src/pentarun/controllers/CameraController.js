export class CameraController { 
        constructor(t, e) { this.scene = t; this.targetMesh = e; this.camera = null; this.cameraTarget = new BABYLON.Vector3.Zero; this.initCamera(); } 
        initCamera() { this.camera = new BABYLON.FreeCamera("GameCamera", BABYLON.Vector3.Zero(), this.scene); this.camera.inputs.clear(); this.reset(); } 
        reset() { this.update(); } 
        update() { if (!this.targetMesh || !this.camera) return; this.camera.position.x = this.targetMesh.position.x + GAME_CONSTANTS.CAMERA_X_OFFSET; this.camera.position.y = GAME_CONSTANTS.CAMERA_Y_POSITION; this.camera.position.z = this.targetMesh.position.z + GAME_CONSTANTS.CAMERA_Z_OFFSET; this.cameraTarget.copyFrom(this.targetMesh.position); this.camera.setTarget(this.cameraTarget); } 
    }