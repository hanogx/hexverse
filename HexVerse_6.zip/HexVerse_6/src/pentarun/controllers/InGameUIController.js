export class InGameUIController {
    constructor(scene) {
        this.scene = scene;
        this.uiParent = null;
        this.slotMeshes = [];
        this.indicatorMeshes = [];
        this.camera = null;

        this.isLandscape = true;
        this.lastScreenWidth = 0;
        this.lastScreenHeight = 0;
        
        // UI elemanları için ergonomik konumlar
        this.landscapePositions = {
            uiParent: new BABYLON.Vector3(-1.1, -1.4, 10),
            indicatorParent: new BABYLON.Vector3(-4, 2, 0),
            slotParent: new BABYLON.Vector3(-4, -2, 0)
        };
        
        this.portraitPositions = {
            uiParent: new BABYLON.Vector3(-0.8, -0.8, 10),
            indicatorParent: new BABYLON.Vector3(-3, 2.5, 0),
            slotParent: new BABYLON.Vector3(-3, -3, 0)
        };
    }

    createUI(camera) {
        this.camera = camera;
        
        // Önceki UI elemanlarını temizle
        if (this.uiParent) {
            this.uiParent.dispose();
            this.slotMeshes = [];
            this.indicatorMeshes = [];
        }

        // İlk yükleme için ekran boyutunu kaydet
        this.lastScreenWidth = engine.getRenderWidth();
        this.lastScreenHeight = engine.getRenderHeight();
        this.isLandscape = this.lastScreenWidth > this.lastScreenHeight;
        
        // Ekran yönüne göre ilk konumlandırma
        this.updatePositionsForOrientation();

        // UI için ana konteyner oluştur
        this.uiParent = new BABYLON.TransformNode("UIParent", this.scene);
        this.uiParent.parent = camera;
        
        // UI'ı kameranın önünde sabit bir konuma yerleştir
        this.uiParent.position = new BABYLON.Vector3(-1.1, -1.4, 10);
        
        // ===== İNDİKATÖRLER =====
        // Kombo göstergesi için panel
        const indicatorParent = new BABYLON.TransformNode("IndicatorParent", this.scene);
        indicatorParent.parent = this.uiParent;
        indicatorParent.position = new BABYLON.Vector3(-4, 2, 0);
        
        // İndikatörler için PBR materyal
        const indicatorMaterial = new BABYLON.PBRMaterial("indicatorPBRMat", this.scene);
        indicatorMaterial.metallic = 0.2;
        indicatorMaterial.roughness = 0.5;
        indicatorMaterial.albedoColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        indicatorMaterial.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        indicatorMaterial.alpha = 0.4;
        
        // İndikatör altıgenlerini oluştur - 3D görünüm için
        for (let i = 0; i < 3; i++) {
            // Ana indikatör
            const indicatorHex = BABYLON.MeshBuilder.CreateCylinder(
                "indicatorHex_" + i, 
                { height: 0.3, diameter: 2, tessellation: 6 },
                this.scene
            );
            indicatorHex.parent = indicatorParent;
            indicatorHex.position.x = i * 2;
            
            // İndikatörleri hafif açılandır
            indicatorHex.rotation.x = Math.PI / 2 - Math.PI / 12;
            indicatorHex.rotation.y = -Math.PI / 18;
            
            indicatorHex.material = indicatorMaterial.clone("indicatorMat_" + i);
            
            // İndikatör kapağı (3D görünüm için)
            const indicatorCap = BABYLON.MeshBuilder.CreateCylinder(
                "indicatorCap_" + i, 
                { height: 0.1, diameter: 1.8, tessellation: 6 },
                this.scene
            );
            indicatorCap.parent = indicatorHex;
            indicatorCap.position.y = 0.2;
            
            // Kapak için materyal
            const capMaterial = indicatorMaterial.clone("indicatorCapMat_" + i);
            capMaterial.emissiveColor = new BABYLON.Color3(0.15, 0.15, 0.15);
            indicatorCap.material = capMaterial;
            
            this.indicatorMeshes.push(indicatorHex);
        }
        
        // ===== SLOT BUTONLARI =====
        // Slot butonları için panel
        const slotParent = new BABYLON.TransformNode("SlotParent", this.scene);
        slotParent.parent = this.uiParent;
        slotParent.position = new BABYLON.Vector3(-4, -2, 0);
        
        // Slot butonları için PBR materyal
        const slotMaterial = new BABYLON.PBRMaterial("slotPBRMat", this.scene);
        slotMaterial.metallic = 0.3;
        slotMaterial.roughness = 0.4;
        slotMaterial.albedoColor = new BABYLON.Color3(0.3, 0.3, 0.3);
        slotMaterial.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1); // Daha düşük emisyon
        slotMaterial.alpha = 0.6;
        
        // Glow layer referansı
        const glowLayer = this.scene.getGlowLayerByName("glow");
        
        // Slot butonlarını oluştur
        for (let i = 0; i < 3; i++) {
            // Ana buton
            const hexSlot = BABYLON.MeshBuilder.CreateCylinder(
                "hexSlot_" + i, 
                { height: 1, diameter: 5, tessellation: 6 },
                this.scene
            );
            hexSlot.parent = slotParent;
            hexSlot.position.y = -i * 5;
            
            // Butonları hafif açılandır
            hexSlot.rotation.x = Math.PI / 2 - Math.PI / 12;
            hexSlot.rotation.y = -Math.PI / 18;
            
            hexSlot.material = slotMaterial.clone("slotMat_" + i);
            
            // Butonun üst kapağı (3D görünüm için)
            const hexCap = BABYLON.MeshBuilder.CreateCylinder(
                "hexCap_" + i, 
                { height: 0.2, diameter: 4.5, tessellation: 6 },
                this.scene
            );
            hexCap.parent = hexSlot;
            hexCap.position.y = 0.6;
            
            // Kapak için daha parlak materyal
            const capMaterial = slotMaterial.clone("capMat_" + i);
            capMaterial.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.2);
            hexCap.material = capMaterial;
            
            // Slot indeksini mesh'e ekle
            hexSlot.slotIndex = i;
            hexCap.slotIndex = i; // Kapağa da slot indeksi ekle
            
            // Tıklama olayını ekle (hem buton hem kapak için)
            const setupClickAction = (mesh) => {
                mesh.actionManager = new BABYLON.ActionManager(this.scene);
                mesh.actionManager.registerAction(
                    new BABYLON.ExecuteCodeAction(
                        BABYLON.ActionManager.OnPickTrigger,
                        (evt) => {
                            const clickedIndex = evt.source.slotIndex;
                            const targetMesh = this.slotMeshes[clickedIndex];
                            
                            // Tıklama animasyonu
                            const originalScale = targetMesh.scaling.clone();
                            const clickAnimation = new BABYLON.Animation(
                                "clickAnimation",
                                "scaling",
                                30,
                                BABYLON.Animation.ANIMATIONTYPE_VECTOR3
                            );
                            
                            const keys = [
                                { frame: 0, value: originalScale },
                                { frame: 5, value: originalScale.scale(0.8) },
                                { frame: 10, value: originalScale }
                            ];
                            
                            clickAnimation.setKeys(keys);
                            targetMesh.animations = [clickAnimation];
                            this.scene.beginAnimation(targetMesh, 0, 10, false);
                            
                            // Combo'yu ateşle
                            gameManager.goldbergController.fireCombo(clickedIndex);
                        }
                    )
                );
            };
            
            setupClickAction(hexSlot);
            setupClickAction(hexCap);
            
            this.slotMeshes.push(hexSlot);
            
            // Başlangıçta glow efekti EKLEME - sadece dolu slotlar için eklenecek
        }
        
        // UI'ı başlangıçta göster
        this.show();
        
        // Hover efekti için pointer gözlemcisi ekle
        this.scene.onPointerObservable.add((pointerInfo) => {
            if (pointerInfo.type === BABYLON.PointerEventTypes.POINTERMOVE) {
                const pickResult = this.scene.pick(
                    this.scene.pointerX, 
                    this.scene.pointerY,
                    (mesh) => {
                        // Hem butonları hem de kapakları kontrol et
                        return this.slotMeshes.includes(mesh) || 
                               (mesh.parent && this.slotMeshes.includes(mesh.parent));
                    }
                );
                
                // Tüm slotları normal haline getir
                this.slotMeshes.forEach(mesh => {
                    if (mesh.isPickable) {
                        mesh.scaling = new BABYLON.Vector3(1, 1, 1);
                    }
                });
                
                // Eğer bir slot veya kapak üzerindeyse, slotu büyüt
                if (pickResult.hit && pickResult.pickedMesh) {
                    let targetMesh;
                    
                    if (this.slotMeshes.includes(pickResult.pickedMesh)) {
                        // Doğrudan slot tıklandı
                        targetMesh = pickResult.pickedMesh;
                    } else if (pickResult.pickedMesh.parent && this.slotMeshes.includes(pickResult.pickedMesh.parent)) {
                        // Kapak tıklandı, parent'ı slot
                        targetMesh = pickResult.pickedMesh.parent;
                    }
                    
                    if (targetMesh && targetMesh.isPickable) {
                        targetMesh.scaling = new BABYLON.Vector3(1.1, 1.1, 1.1);
                    }
                }
            }
        });
        
        // Ekran boyutuna göre UI ölçeğini ayarla
        this.adjustUIScale();
        
        // Ekran boyutu değiştiğinde UI ölçeğini yeniden ayarla
        window.addEventListener('resize', () => {
            this.adjustUIScale();
        });
    }
    
updatePositionsForOrientation() {
    if (!this.uiParent) return;
    
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const isLandscape = width > height;
    
    if (isLandscape) {
        // Yatay ekran konumları
        this.uiParent.position = new BABYLON.Vector3(-1.1, -1.4, 10);
    } else {
        // Dikey ekran konumları
        this.uiParent.position = new BABYLON.Vector3(-0.8, -0.8, 10);
    }
}

adjustUIScale() {
    if (!this.uiParent) return;
    
    // Sabit bir ölçeklendirme faktörü kullan
    const baseScale = 0.1; // Bu değeri UI boyutuna göre ayarlayın
    
    this.uiParent.scaling = new BABYLON.Vector3(baseScale, baseScale, baseScale);
}

    updateAppearance(gameState) {
        if (!this.slotMeshes.length) return;
        
        const { unlockedSlots, storedCombos, comboSequence } = gameState;
        const hexColors = this.scene.metadata.hexColors;
        const glowLayer = this.scene.getGlowLayerByName("glow");
        
        // Slotların görünümünü güncelle
        this.slotMeshes.forEach((slotMesh, index) => {
            const comboInSlot = storedCombos[index];
            
            // Slot butonunun kapağını bul
            const capMesh = slotMesh.getChildren()[0];
            
            // Önce glow'u kaldır
            if (glowLayer) {
                glowLayer.removeIncludedOnlyMesh(slotMesh);
                if (capMesh) glowLayer.removeIncludedOnlyMesh(capMesh);
            }
            
            if (index < unlockedSlots) {
                // Açık slot
                slotMesh.isPickable = true;
                slotMesh.isVisible = true;
                
                if (comboInSlot) {
                    // Dolu slot
                    const color = hexColors[comboInSlot];
                    
                    // Ana buton
                    slotMesh.material.albedoColor = color.diffuseColor.scale(0.7);
                    slotMesh.material.emissiveColor = color.emissiveColor.scale(0.5);
                    slotMesh.material.alpha = 0.8;
                    
                    // Kapak
                    if (capMesh) {
                        capMesh.material.albedoColor = color.diffuseColor.scale(0.9);
                        capMesh.material.emissiveColor = color.emissiveColor.scale(0.7);
                        capMesh.material.alpha = 0.9;
                    }
                    
                    // Sadece dolu slotlara glow efekti ekle
                    if (glowLayer) {
                        glowLayer.addIncludedOnlyMesh(slotMesh);
                        if (capMesh) glowLayer.addIncludedOnlyMesh(capMesh);
                    }
                } else {
                    // Boş slot
                    slotMesh.material.albedoColor = new BABYLON.Color3(0.3, 0.3, 0.3);
                    slotMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    slotMesh.material.alpha = 0.6;
                    
                    // Kapak
                    if (capMesh) {
                        capMesh.material.albedoColor = new BABYLON.Color3(0.4, 0.4, 0.4);
                        capMesh.material.emissiveColor = new BABYLON.Color3(0.15, 0.15, 0.15);
                        capMesh.material.alpha = 0.7;
                    }
                }
            } else {
                // Kilitli slot
                slotMesh.isPickable = false;
                slotMesh.isVisible = true;
                slotMesh.material.albedoColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                slotMesh.material.emissiveColor = new BABYLON.Color3(0.05, 0.05, 0.05);
                slotMesh.material.alpha = 0.3;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = new BABYLON.Color3(0.15, 0.15, 0.15);
                    capMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    capMesh.material.alpha = 0.4;
                }
            }
        });
        
        // Göstergenin görünümünü güncelle
        this.indicatorMeshes.forEach((mesh, index) => {
            const colorName = comboSequence[index];
            const capMesh = mesh.getChildren()[0]; // İndikatör kapağı
            
            if (colorName) {
                mesh.isVisible = true;
                const color = hexColors[colorName];
                
                // Ana indikatör
                mesh.material.albedoColor = color.diffuseColor.scale(0.6);
                mesh.material.emissiveColor = color.emissiveColor.scale(1.0);
                mesh.material.alpha = 0.7;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = color.diffuseColor.scale(0.8);
                    capMesh.material.emissiveColor = color.emissiveColor.scale(1.2);
                    capMesh.material.alpha = 0.8;
                }
            } else {
                // Boş gösterge
                mesh.isVisible = true;
                mesh.material.albedoColor = new BABYLON.Color3(0.2, 0.2, 0.2);
                mesh.material.emissiveColor = new BABYLON.Color3(0.05, 0.05, 0.05);
                mesh.material.alpha = 0.3;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = new BABYLON.Color3(0.25, 0.25, 0.25);
                    capMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    capMesh.material.alpha = 0.4;
                }
            }
        });
    }
    
    show() {
        if (this.uiParent) {
            this.uiParent.setEnabled(true);
        }
    }
    
    hide() {
        if (this.uiParent) {
            this.uiParent.setEnabled(false);
        }
    }
}