export class MovementController { 
        constructor() { this.speed = GAME_CONSTANTS.HEX_RADIUS * 50 * GAME_CONSTANTS.SPACING_FACTOR; this.xVelocity = 0; this.zVelocity = 0; this.moveDirections = { forward: false, backward: false, left: false, right: false }; } 
        setVelocity(xVel, zVel) { this.xVelocity = xVel; this.zVelocity = zVel; } 
        startMove(direction) { this.moveDirections[direction] = true; } 
        stopMove(direction) { this.moveDirections[direction] = false; } 
    }