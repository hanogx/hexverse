export class PentaTileController { 
        constructor(mesh) { 
            this.mesh = mesh; 
            this.scene = mesh.getScene(); 
            this.originalMaterial = mesh.material; 
            this.hitsNeeded = GAME_CONSTANTS.HITS_TO_WIN; 
        } 

    setActiveMesh(newMesh) {
        this.mesh = newMesh;
    }

  reset() {
        // Skoru ve hedefi sıfırla
        this.hitsNeeded = GAME_CONSTANTS.HITS_TO_WIN;
        if (gameManager) { // gameManager'ın var olduğundan emin ol
             gameManager.state.score = 0;
        }
    }


        resetMaterial() { 
            this.mesh.material = this.originalMaterial; 
        } 

 takeHit(isCombo) {
        const damage = isCombo ? 6 : 1;
        let isWin = false;

        if (gameManager.state.isEndlessMode) {
            // Sonsuz moddaysak, hedefi düşürmek yerine skoru artır.
            gameManager.state.score += damage;
            // Sonsuz modda oyun asla bitmez.
            isWin = false; 
        } else {
            // Normal moddaysak, hedefi düşür.
            this.hitsNeeded = Math.max(0, this.hitsNeeded - damage);
            isWin = this.hitsNeeded <= 0;
        }

        const flash = new BABYLON.HighlightLayer("hl_" + Math.random(), this.scene);
        flash.addMesh(this.mesh, isCombo ? new BABYLON.Color3(1, 0.7, 0) : BABYLON.Color3.White());
        setTimeout(() => { flash.dispose(); }, isCombo ? 400 : 150);
        
        return isWin;
    }
        getHitsNeeded() { return this.hitsNeeded; } 
    }