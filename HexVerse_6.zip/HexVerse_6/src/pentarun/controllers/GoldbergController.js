export class GoldbergController { 
        constructor(scene, movementController) { 
            this.scene = scene; 
            this.movementController = movementController; 
            this.currentGoldberg = null; 
            this.defaultMaterial = null; 
            this.glowLayer = null; 
            this.comboSequence = []; 
            this.storedCombos = [null, null, null]; 
            this.indicatorPanel = null; 
            this.unstableTimerUI = document.getElementById('unstable-timer'); 
            this.unstableTimeText = document.getElementById('unstable-time'); 
            this.isUnstable = false; 
            this.isInvincible = false; 
            this.unstableTimeout = null; 
            this.invincibilityTimeout = null; 
            this.unstableTimerInterval = null; 
            this.unstableAura = null; 
            this.speedMultiplier = 1.0;
        } 
        create() { 
            if (this.currentGoldberg) this.currentGoldberg.dispose(); 
            this.currentGoldberg = BABYLON.MeshBuilder.CreateGoldberg("goldberg", { m: 3, n: 0, size: 1.0 }, this.scene); 
            this.defaultMaterial = new BABYLON.StandardMaterial("goldbergMat", this.scene); 
            const color = new BABYLON.Color3(0.6, 0.8, 1); 
            this.defaultMaterial.diffuseColor = color; 
            this.defaultMaterial.emissiveColor = color.scale(0.3); 
            this.currentGoldberg.material = this.defaultMaterial; 
            this.glowLayer = new BABYLON.HighlightLayer("playerGlow", this.scene); 
            this.unstableAura = createUnstableAura(this.currentGoldberg, this.scene); 
            this.reset(); 
            return this.currentGoldberg; 
        } 
        reset() { 
            if (!this.currentGoldberg) return; 
            this.clearAllCombos(); 
            this.isUnstable = false; 
            this.isInvincible = false; 
            clearTimeout(this.unstableTimeout); 
            clearTimeout(this.invincibilityTimeout); 
            clearInterval(this.unstableTimerInterval); 
            if(this.unstableTimerUI) this.unstableTimerUI.style.display = 'none'; 
            this.currentGoldberg.visibility = 1; 
            if (this.unstableAura) { this.unstableAura.stop(); } 
            this.currentGoldberg.position.copyFrom(GAME_CONSTANTS.PLAYER_START_POS); 
            this.currentGoldberg.rotationQuaternion = BABYLON.Quaternion.Identity(); 
            if (this.currentGoldberg.physicsImpostor) this.currentGoldberg.physicsImpostor.dispose(); 
            this.currentGoldberg.physicsImpostor = new BABYLON.PhysicsImpostor(this.currentGoldberg, BABYLON.PhysicsImpostor.SphereImpostor, { mass: 0.5, restitution: 0.1, friction: 0.9 }, this.scene); 
            this.currentGoldberg.physicsImpostor.setLinearVelocity(BABYLON.Vector3.Zero()); 
            this.currentGoldberg.physicsImpostor.setAngularVelocity(BABYLON.Vector3.Zero()); 
        } 
        handleHazardHit() { 
    if (this.isInvincible) return; 
    if (this.isUnstable) { 
        if (this.unstableAura) this.unstableAura.stop(); 
        if (this.currentGoldberg) this.currentGoldberg.dispose(); 
        // gameManager.endGame'deki "laser" sebebini "hazard" gibi daha genel bir şeye çevirebiliriz. 
        gameManager.endGame(false, "hazard");  
        return; 
    } 
            this.isUnstable = true; 
            if (this.unstableAura) { this.unstableAura.start(); } 
            this.unstableTimerUI.style.display = 'flex'; 
            const endTime = Date.now() + GAME_CONSTANTS.UNSTABLE_DEBUFF_DURATION; 
            this.unstableTimerInterval = setInterval(() => { 
                const remaining = Math.max(0, endTime - Date.now()); 
                this.unstableTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`; 
            }, 100); 
            this.unstableTimeout = setTimeout(() => { 
                this.isUnstable = false; 
                if (this.unstableAura) { this.unstableAura.stop(); } 
                clearInterval(this.unstableTimerInterval); 
                this.unstableTimerUI.style.display = 'none'; 
            }, GAME_CONSTANTS.UNSTABLE_DEBUFF_DURATION); 
            this.isInvincible = true; 
            const invincibilityInterval = setInterval(() => { 
                if (this.currentGoldberg) this.currentGoldberg.visibility = this.currentGoldberg.visibility === 1 ? 0.5 : 1; 
            }, 150); 
            this.invincibilityTimeout = setTimeout(() => { 
                this.isInvincible = false; 
                clearInterval(invincibilityInterval); 
                if (this.currentGoldberg) this.currentGoldberg.visibility = 1; 
            }, GAME_CONSTANTS.INVINCIBILITY_DURATION); 
        } 


   chargeCombo(colorName) {
        // 1. Rengi sıraya ve görsel göstergeye ekle
        this.comboSequence.push(colorName);
        
        // 2. Eğer sıra 3'ten uzunsa, en eskisini at
        if (this.comboSequence.length > 3) {
            this.comboSequence.shift();
        }
        
        // 3. Eğer 3 renk olduysa, kombo kontrolü yap
        if (this.comboSequence.length === 3) {
            const [c1, c2, c3] = this.comboSequence;
            if (c1 === c2 && c2 === c3) {
                // Kombo başarılı! Boş bir slot bul ve doldur.
                this.storeReadyCombo(c1);
            }
        }
        
        // UI'ı güncelle
        gameManager.requestUIUpdate();
    }

        activateGlow() { 
            const hexColors = this.scene.metadata.hexColors; 
            this.currentGoldberg.material = hexColors[this.comboReadyColor]; 
            this.glowLayer.addMesh(this.currentGoldberg, hexColors[this.comboReadyColor].emissiveColor.scale(2)); 
        const slotButton = gameManager.ui.comboSlotButtons[0]; // Şimdilik ilk slot
        if(slotButton) {
            slotButton.background = hexColors[this.comboReadyColor].emissiveColor.toHexString();
            slotButton.isEnabled = true; // Tıklanabilir yap
        }
        } 

    updateVisualIndicator() {
        if (!this.indicatorPanel) return;

        // Önce paneli temizle
        [...this.indicatorPanel.children].forEach(child => this.indicatorPanel.removeControl(child));

        // Sonra mevcut sıraya göre yeniden doldur
        this.comboSequence.forEach(colorName => {
            const indicatorHex = new BABYLON.GUI.Button(); // Buton olarak yaparsak tıklanabilir olur ama şimdilik sadece görsel
            indicatorHex.width = "20px";
            indicatorHex.height = "23px";
            indicatorHex.thickness = 0;
            indicatorHex.background = this.scene.metadata.hexColors[colorName].emissiveColor.toHexString();
            // CSS'teki altıgen maskesini buna da uygulayabiliriz
            // indicatorHex.domElement.className = "hexagon-mask"; // Bu çalışmaz, PNG gerekir. Şimdilik kare kalabilir.
            indicatorHex.paddingLeft = "2px";
            indicatorHex.paddingRight = "2px";
            this.indicatorPanel.addControl(indicatorHex);
        });
    }

    storeReadyCombo(comboColor) {
        const emptySlotIndex = this.storedCombos.indexOf(null);
        if (emptySlotIndex !== -1) {
            this.storedCombos[emptySlotIndex] = comboColor;
            this.comboSequence = []; // Sırayı temizle
            gameManager.requestUIUpdate(); // UI'ı güncelle
        }
    }

fireCombo(slotIndex) {
    const comboColor = this.storedCombos[slotIndex];
    if (!comboColor) return;
    
    // Combo slotunu hemen boşalt
    this.storedCombos[slotIndex] = null;
    gameManager.requestUIUpdate();
    
    // Bazı combo'ların etkilerini hemen aktifleştir
    if (comboColor === 'em_blue') {
        this.activateShield(); // Kalkanı hemen aktifleştir
    } else if (comboColor === 'gravity_green') {
        this.activateSpeedBoost(); // Hız artışını hemen aktifleştir
    }
    
    // Sonra atış animasyonunu başlat
    this.fireComboProjectile(comboColor);
}


fireComboProjectile(comboColor) {
    const playerMesh = this.currentGoldberg;
    const centralPentagonMesh = gameManager.pentaTileController.mesh;
    
    // Küre yerine altıgen tile oluştur
    const projectile = BABYLON.MeshBuilder.CreateCylinder("comboTile", { 
        diameter: 2.0, 
        height: 0.5, 
        tessellation: 6 // 6 kenarlı (altıgen)
    }, this.scene);
    
    // Altıgen tile'ı doğru yönlendir (üst yüzey yukarı baksın)
    projectile.rotation.x = Math.PI / 2;
    
    projectile.material = this.scene.metadata.hexColors[comboColor];
    projectile.position = playerMesh.position.clone().add(new BABYLON.Vector3(0, 1, 0));
    
    // Renk bazlı özel efektler
    switch (comboColor) {
        case 'ice_blue':
            this.addIceEffects(projectile);
            break;
        case 'solar_orange':
            this.addFireEffects(projectile);
            break;
        case 'em_blue':
            this.addElectricEffects(projectile);
            break;
        case 'gravity_green':
            this.addGravityEffects(projectile);
            break;
        case 'dark_purple':
            this.addDarkEnergyEffects(projectile);
            break;
    }
    
    // Temel parçacık izi (tüm renkler için)
    const trailPS = new BABYLON.ParticleSystem("comboTrail", 2000, this.scene);
    trailPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    trailPS.emitter = projectile;
    trailPS.minEmitBox = new BABYLON.Vector3(-0.2, -0.2, -0.2);
    trailPS.maxEmitBox = new BABYLON.Vector3(0.2, 0.2, 0.2);
    trailPS.color1 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.2).toColor4(1);
    trailPS.color2 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(0.7).toColor4(1);
    trailPS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0);
    trailPS.minSize = 0.2;
    trailPS.maxSize = 0.5;
    trailPS.minLifeTime = 0.2;
    trailPS.maxLifeTime = 0.6;
    trailPS.emitRate = 400;
    trailPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    trailPS.gravity = new BABYLON.Vector3(0, 0, 0);
    trailPS.direction1 = new BABYLON.Vector3(-0.5, -0.5, -0.5);
    trailPS.direction2 = new BABYLON.Vector3(0.5, 0.5, 0.5);
    trailPS.minEmitPower = 0.5;
    trailPS.maxEmitPower = 1.5;
    trailPS.updateSpeed = 0.01;
    trailPS.targetStopDuration = 0.2;
    trailPS.disposeOnStop = true;
    trailPS.start();
    
    // Animasyon
    const frameRate = 60;
    const animDuration = frameRate * 1.2;
    
    const positionAnim = new BABYLON.Animation("comboAnim", "position", frameRate, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
    
    // Yüksek kavis
    const midPoint = BABYLON.Vector3.Lerp(projectile.position, centralPentagonMesh.getAbsolutePosition(), 0.5);
    midPoint.y += 8;
    
    positionAnim.setKeys([
        { frame: 0, value: projectile.position },
        { frame: animDuration / 2, value: midPoint },
        { frame: animDuration, value: centralPentagonMesh.getAbsolutePosition() }
    ]);
    
    // Dönme animasyonu - altıgen için daha uygun bir dönme
    const rotationAnim = new BABYLON.Animation("rotateAnim", "rotation.y", frameRate, BABYLON.Animation.ANIMATIONTYPE_FLOAT);
    rotationAnim.setKeys([
        { frame: 0, value: projectile.rotation.y },
        { frame: animDuration, value: projectile.rotation.y + Math.PI * 4 } // 2 tam tur dön
    ]);
    
    // Animasyonu başlat
    const animatable = this.scene.beginDirectAnimation(projectile, [positionAnim, rotationAnim], 0, animDuration, false);
    
    // Animasyon bittiğinde
    animatable.onAnimationEnd = () => {
        // Çarpışma efekti
        this.createComboImpactEffect(projectile.position, comboColor);
        
        // Renk bazlı özel yetenekler
        switch (comboColor) {
            case 'ice_blue':
                // Penta Tile mekaniklerini interrupt et
                this.interruptPentaMechanics();
                break;
                
            case 'solar_orange':
                // Güçlü vuruş: 9 tile etkisi
                this.createSolarImpact(projectile.position);
                
                // 9 tile vuruş etkisi (normal 6 yerine)
                for (let i = 0; i < 3; i++) { // 3 ekstra vuruş
                    gameManager.pentaTileController.takeHit(false);
                }
                break;
                
            case 'em_blue':
                // Kalkan koruması
                this.activateShield();
                break;
                
            case 'gravity_green':
                // Hareket hızını artır
                this.activateSpeedBoost();
                break;
                
            case 'dark_purple':
                // Çekim alanı
                this.activateAttractionField();
                break;
        }
        
        // Penta Tile'a hasar ver (tüm renkler için temel hasar)
        const isWin = gameManager.pentaTileController.takeHit(true);
        gameManager.updateHUD();
        
        // Mermiyi temizle
        projectile.dispose();
        
        if (isWin) gameManager.endGame(true);
    };
}

createComboImpactEffect(position, comboColor) {
    // Temel patlama parçacıkları
    const explosionPS = new BABYLON.ParticleSystem("comboExplosion", 1000, this.scene);
    explosionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    explosionPS.emitter = position;
    explosionPS.minEmitBox = new BABYLON.Vector3(-0.2, -0.2, -0.2);
    explosionPS.maxEmitBox = new BABYLON.Vector3(0.2, 0.2, 0.2);
    explosionPS.color1 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.5).toColor4(1);
    explosionPS.color2 = this.scene.metadata.hexColors[comboColor].diffuseColor.toColor4(1);
    explosionPS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0);
    explosionPS.minSize = 0.3;
    explosionPS.maxSize = 0.8;
    explosionPS.minLifeTime = 0.3;
    explosionPS.maxLifeTime = 0.8;
    explosionPS.emitRate = 1000;
    explosionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    explosionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    explosionPS.direction1 = new BABYLON.Vector3(-2, 0, -2);
    explosionPS.direction2 = new BABYLON.Vector3(2, 2, 2);
    explosionPS.minEmitPower = 1;
    explosionPS.maxEmitPower = 3;
    explosionPS.updateSpeed = 0.01;
    explosionPS.targetStopDuration = 0.3;
    explosionPS.disposeOnStop = true;
    explosionPS.start();
    
    // Dalgalı halka efekti
    const ringMesh = BABYLON.MeshBuilder.CreateDisc("impactRing", {radius: 0.1, tessellation: 36}, this.scene);
    ringMesh.position = position.clone();
    ringMesh.rotation.x = Math.PI / 2;
    
    const ringMat = new BABYLON.StandardMaterial("ringMat", this.scene);
    ringMat.emissiveColor = this.scene.metadata.hexColors[comboColor].emissiveColor.scale(2);
    ringMat.disableLighting = true;
    ringMat.alpha = 0.7;
    ringMesh.material = ringMat;
    
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(ringMesh);
    
    // Halkanın büyüme ve kaybolma animasyonu
    const ringScaleAnim = new BABYLON.Animation("ringScale", "scaling", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
    ringScaleAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 30, value: new BABYLON.Vector3(15, 15, 15) }
    ]);
    
    const ringAlphaAnim = new BABYLON.Animation("ringAlpha", "material.alpha", 60, BABYLON.Animation.ANIMATIONTYPE_FLOAT);
    ringAlphaAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 30, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(ringMesh, [ringScaleAnim, ringAlphaAnim], 0, 30, false, 1, () => {
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(ringMesh);
        ringMesh.dispose();
    });
    
    // Penta Tile'da parlama efekti
    const pentaTile = gameManager.pentaTileController.mesh;
    const flash = new BABYLON.HighlightLayer("comboFlash", this.scene);
    flash.addMesh(pentaTile, this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.5));
    
    // Parlama efektini kademeli olarak kaldır
    setTimeout(() => {
        flash.dispose();
    }, 500);
}


    clearAllCombos() {
        this.comboSequence = [];
        this.storedCombos = [null, null, null];
        if (gameManager) {
            gameManager.requestUIUpdate();
        }
    }

update() {
    if (!this.currentGoldberg || !this.currentGoldberg.physicsImpostor) return;

    // Temel hız ve maksimum hız
    const baseSpeed = 8; // Bu değeri ayarlayarak oyuncunun temel hızını belirleyin.
    const maxVelocity = 12;

    // Joystick'ten gelen girdiyi al
    let inputX = this.movementController.xVelocity;
    let inputZ = this.movementController.zVelocity;

    // Klavye girdilerini de aynı şekilde al (eğer kullanılıyorsa)
    if (this.movementController.moveDirections.forward) { inputZ = 1; }
    if (this.movementController.moveDirections.backward) { inputZ = -1; }
    if (this.movementController.moveDirections.left) { inputX = -1; }
    if (this.movementController.moveDirections.right) { inputX = 1; }

    // Girdi vektörünü oluştur ve normalize et (köşegen hareketin daha hızlı olmasını engellemek için)
    const inputVector = new BABYLON.Vector3(inputX, 0, inputZ);
    if (inputVector.length() > 0) {
        inputVector.normalize();
    }

    // Son hızı hesapla (temel hız * çarpan)
    const finalSpeed = baseSpeed * this.speedMultiplier;

    // Yeni hızı ayarla
    const currentVelocity = this.currentGoldberg.physicsImpostor.getLinearVelocity();
    const newVelocity = new BABYLON.Vector3(
        inputVector.x * finalSpeed,
        currentVelocity.y, // Y eksenindeki hızı (zıplama/düşme) koru
        inputVector.z * finalSpeed
    );

    // Maksimum hızı uygula
    if (newVelocity.length() > maxVelocity * this.speedMultiplier) {
        newVelocity.normalize().scaleInPlace(maxVelocity * this.speedMultiplier);
    }

    this.currentGoldberg.physicsImpostor.setLinearVelocity(newVelocity);
}

 
showNotification(message, color) {
    // Bildirim elementi
    const notification = document.createElement('div');
    notification.style.position = 'absolute';
    notification.style.top = '100px';
    notification.style.left = '50%';
    notification.style.transform = 'translateX(-50%)';
    notification.style.backgroundColor = `rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 0.2)`;
    notification.style.border = `2px solid rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 0.7)`;
    notification.style.color = 'white';
    notification.style.padding = '10px 20px';
    notification.style.borderRadius = '8px';
    notification.style.fontFamily = "'Segoe UI', sans-serif";
    notification.style.fontSize = '1.2rem';
    notification.style.fontWeight = 'bold';
    notification.style.textShadow = `0 0 5px rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 1.0)`;
    notification.style.zIndex = '1000';
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s ease-in-out';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Bildirim animasyonu
    setTimeout(() => {
        notification.style.opacity = '1';
        
        setTimeout(() => {
            notification.style.opacity = '0';
            
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 2000);
    }, 0);
}

// Kamera titreşimi
shakeCamera(intensity, duration) {
    const camera = this.scene.activeCamera;
    const originalPosition = camera.position.clone();
    
    let shakeIntensity = intensity || 0.3;
    const shakeInterval = setInterval(() => {
        if (shakeIntensity <= 0.01) {
            clearInterval(shakeInterval);
            camera.position = originalPosition;
            return;
        }
        
        camera.position = originalPosition.add(
            new BABYLON.Vector3(
                (Math.random() - 0.5) * shakeIntensity,
                (Math.random() - 0.5) * shakeIntensity,
                (Math.random() - 0.5) * shakeIntensity
            )
        );
        
        shakeIntensity *= 0.85; // Titreşim giderek azalır
    }, 16); // ~60fps
    
    setTimeout(() => {
        clearInterval(shakeInterval);
        camera.position = originalPosition;
    }, duration || 500);
}

// 1. Buz Efektleri
addIceEffects(projectile) {
    // Buz materyali
    const iceMat = new BABYLON.PBRMaterial("iceMat", this.scene);
    iceMat.albedoColor = new BABYLON.Color3(0.8, 0.9, 1.0);
    iceMat.metallic = 0.1;
    iceMat.roughness = 0.1;
    iceMat.alpha = 0.8;
    projectile.material = iceMat;
    
    // Buz kristalleri - altıgenin kenarlarında
    const crystalCount = 6; // Altıgenin 6 kenarı
    for (let i = 0; i < crystalCount; i++) {
        const crystal = BABYLON.MeshBuilder.CreatePolyhedron("iceFragment", {
            type: 3, // Oktahedron
            size: 0.3
        }, this.scene);
        
       // Kristal materyali (daha parlak)
        const crystalMat = new BABYLON.StandardMaterial("iceCrystalMat" + i, this.scene);
        crystalMat.diffuseColor = new BABYLON.Color3(0.8, 0.95, 1.0);
        crystalMat.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0); // Parlaklık
        crystalMat.alpha = 0.8;
        crystal.material = crystalMat;
        
        // Kristalleri altıgenin kenarlarına yerleştir
        crystal.parent = projectile;
        
        // Altıgenin kenarlarına yerleştir
        const angle = (i / crystalCount) * Math.PI * 2;
        const radius = 1.0; // Altıgenin yarıçapı
        crystal.position.x = Math.cos(angle) * radius;
        crystal.position.z = Math.sin(angle) * radius;
        crystal.position.y = 0.3; // Altıgenin üstünde
        
        // Glow efekti
        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(crystal);
    }
    
    // Buz parçacıkları
    const icePS = new BABYLON.ParticleSystem("iceParticles", 600, this.scene);
    icePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    icePS.emitter = projectile;
    icePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    icePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    icePS.color1 = new BABYLON.Color4(0.8, 0.9, 1.0, 1.0);
    icePS.color2 = new BABYLON.Color4(0.5, 0.8, 1.0, 1.0);
    icePS.colorDead = new BABYLON.Color4(0.5, 0.8, 1.0, 0.0);
    icePS.minSize = 0.1;
    icePS.maxSize = 0.3;
    icePS.minLifeTime = 0.2;
    icePS.maxLifeTime = 0.6;
    icePS.emitRate = 300;
    icePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    icePS.gravity = new BABYLON.Vector3(0, -0.1, 0);
    icePS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    icePS.direction2 = new BABYLON.Vector3(1, 1, 1);
    icePS.minEmitPower = 0.5;
    icePS.maxEmitPower = 1.5;
    icePS.start();
    
    // Mermi yok edildiğinde parçacıkları da temizle
    projectile.onDisposeObservable.add(() => {
        icePS.dispose();
    });
}

interruptPentaMechanics() {
    let wasInterrupted = false;
    let interruptedMechanic = null;

    // 1. İptal edilecek mekaniği bul
    for (const mechanic of gameManager.activeMechanics) {
        if (mechanic.isWarmingUp || mechanic.isActive) {
            interruptedMechanic = mechanic;
            break; // Sadece bir mekaniği interrupt edebiliriz, ilk bulduğumuzda döngüden çık.
        }
    }

    // Eğer iptal edilecek bir mekanik bulunduysa...
    if (interruptedMechanic) {
        wasInterrupted = true;
        console.log(`Interrupting and CANCELLING mechanic: ${interruptedMechanic.constructor.name}`);

        // 2. MEKANİĞİ TAMAMEN DURDUR VE TEMİZLE
        // Kendi iç zamanlayıcılarını ve durumlarını temizle.
        if (interruptedMechanic.warningInterval) {
            clearInterval(interruptedMechanic.warningInterval);
            interruptedMechanic.warningInterval = null;
        }
        if (interruptedMechanic.activationTimeout) {
            clearTimeout(interruptedMechanic.activationTimeout);
            interruptedMechanic.activationTimeout = null;
        }
        if (interruptedMechanic.spawnerInterval) {
            clearInterval(interruptedMechanic.spawnerInterval);
            interruptedMechanic.spawnerInterval = null;
        }

        // Mekaniği "deaktif" duruma getirerek tüm görsel efektlerini temizlemesini sağla.
        interruptedMechanic.deactivate();

        // Durum bayraklarını (flag) manuel olarak sıfırla.
        interruptedMechanic.isWarmingUp = false;
        interruptedMechanic.isActive = false;

        // Penta Tile materyalini orijinal haline getir.
        gameManager.pentaTileController.resetMaterial();

        // 3. OYUN YÖNETİCİSİNİN SIRASINI İLERLET (EN KRİTİK ADIM)
        // Bu, mekaniğin "ertelenmesini" değil, "iptal edilmesini" sağlar.
        
        // Eğer oyun çoklu mekanik aşamasındaysa, sıradaki mekaniğe geç.
        if (gameManager.state.isMultiMechanicStage) {
            gameManager.state.eventIndex = (gameManager.state.eventIndex + 1) % gameManager.state.eventQueue.length;
            console.log(`Event index advanced. Next mechanic will be: ${gameManager.state.eventQueue[gameManager.state.eventIndex].constructor.name}`);
        }

        // Hem çoklu aşama hem de sonsuz mod için, bir sonraki olaya kadar oyuncuya zaman ver.
        if (gameManager.state.isMultiMechanicStage || gameManager.state.isEndlessMode) {
            gameManager.state.nextEventTimer = 8 + Math.random() * 4; // 8-12 saniye sonra yeni mekanik gelsin.
            console.log(`Next event timer reset. New event in ${gameManager.state.nextEventTimer.toFixed(1)}s`);
        }
        
        // 4. GÖRSEL EFEKTLERİ GÖSTER
        this.createFreezeEffect(gameManager.pentaTileController.mesh);
        this.showNotification("MEKANİK İPTAL EDİLDİ!", new BABYLON.Color3(0.4, 0.8, 1.0));
    }
}

// Donma efekti - Buz mavisi renginde
// GoldbergController sınıfına ekleyin
createFreezeEffect(targetMesh) {
    // Orijinal materyali sakla
    const originalMaterial = targetMesh.material;
    
    // Donma materyali (daha parlak)
    const freezeMaterial = new BABYLON.StandardMaterial("freezeMat", this.scene);
    freezeMaterial.diffuseColor = new BABYLON.Color3(0.6, 0.8, 1.0);
    freezeMaterial.emissiveColor = new BABYLON.Color3(0.3, 0.5, 0.8); // Parlaklık
    freezeMaterial.alpha = 0.95;
    freezeMaterial.specularPower = 128;
    targetMesh.material = freezeMaterial;

    // Buz kristalleri
    const crystalParent = new BABYLON.TransformNode("crystalParent", this.scene);
    crystalParent.position = targetMesh.position.clone();

    for (let i = 0; i < 8; i++) {
        const crystal = BABYLON.MeshBuilder.CreatePolyhedron("freezeCrystalEffect" + i, { type: 3, size: 0.8 + Math.random() * 0.5 }, this.scene);

        // Kristal materyali (daha parlak)
        const crystalMat = new BABYLON.StandardMaterial("freezeCrystalEffectMat" + i, this.scene);
        crystalMat.diffuseColor = new BABYLON.Color3(0.8, 0.95, 1.0);
        crystalMat.emissiveColor = new BABYLON.Color3(0.6, 0.85, 1.0); // Yüksek parlaklık
        crystalMat.alpha = 0.8;
        crystal.material = crystalMat;
        
        crystal.parent = crystalParent;
        
        // Rastgele pozisyon
        const angle = Math.random() * Math.PI * 2;
        const radius = 3 + Math.random() * 2;
        const height = Math.random() * 3;
        
        crystal.position.x = Math.cos(angle) * radius;
        crystal.position.z = Math.sin(angle) * radius;
        crystal.position.y = height;
        
        // Rastgele rotasyon
        crystal.rotation = new BABYLON.Vector3(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        
        // Glow efekti
        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(crystal);
    }
    
    // Buz buğusu
    const frostPS = new BABYLON.ParticleSystem("frostPS", 1000, this.scene);
    frostPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    frostPS.emitter = targetMesh.position;
    frostPS.minEmitBox = new BABYLON.Vector3(-3, 0, -3);
    frostPS.maxEmitBox = new BABYLON.Vector3(3, 3, 3);
    frostPS.color1 = new BABYLON.Color4(0.7, 0.8, 1.0, 0.2); // Buz mavisi
    frostPS.color2 = new BABYLON.Color4(0.5, 0.7, 1.0, 0.2); // Buz mavisi
    frostPS.colorDead = new BABYLON.Color4(0.4, 0.6, 1.0, 0.0); // Buz mavisi
    frostPS.minSize = 0.3;
    frostPS.maxSize = 0.8;
    frostPS.minLifeTime = 1.0;
    frostPS.maxLifeTime = 2.0;
    frostPS.emitRate = 300;
    frostPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ADD;
    frostPS.gravity = new BABYLON.Vector3(0, 0.05, 0);
    frostPS.minEmitPower = 0.2;
    frostPS.maxEmitPower = 0.5;
    frostPS.start();
    
    // 3 saniye sonra efekti kaldır
    setTimeout(() => {
        targetMesh.material = originalMaterial;
        crystalParent.dispose();
        frostPS.stop();
    }, 3000);
}


// Alev efektleri ekle
addFireEffects(projectile) {
    // Alev materyali
    const fireMat = new BABYLON.StandardMaterial("fireMat", this.scene);
    fireMat.diffuseColor = new BABYLON.Color3(1.0, 0.3, 0.0);
    fireMat.emissiveColor = new BABYLON.Color3(0.8, 0.2, 0.0);
    projectile.material = fireMat;
    
    // Alev parçacıkları
    const firePS = new BABYLON.ParticleSystem("fireParticles", 1000, this.scene);
    firePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    firePS.emitter = projectile;
    firePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    firePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    firePS.color1 = new BABYLON.Color4(1.0, 0.5, 0.0, 1.0);
    firePS.color2 = new BABYLON.Color4(1.0, 0.2, 0.0, 1.0);
    firePS.colorDead = new BABYLON.Color4(0.5, 0.0, 0.0, 0.0);
    firePS.minSize = 0.3;
    firePS.maxSize = 0.8;
    firePS.minLifeTime = 0.1;
    firePS.maxLifeTime = 0.3;
    firePS.emitRate = 600;
    firePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    firePS.gravity = new BABYLON.Vector3(0, 0, 0);
    firePS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    firePS.direction2 = new BABYLON.Vector3(1, 1, 1);
    firePS.minEmitPower = 1;
    firePS.maxEmitPower = 3;
    firePS.updateSpeed = 0.01;
    firePS.start();
    
    // Duman parçacıkları
    const smokePS = new BABYLON.ParticleSystem("smokeParticles", 300, this.scene);
    smokePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    smokePS.emitter = projectile;
    smokePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    smokePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    smokePS.color1 = new BABYLON.Color4(0.3, 0.3, 0.3, 0.4);
    smokePS.color2 = new BABYLON.Color4(0.2, 0.2, 0.2, 0.3);
    smokePS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0.0);
    smokePS.minSize = 0.5;
    smokePS.maxSize = 1.0;
    smokePS.minLifeTime = 0.5;
    smokePS.maxLifeTime = 1.0;
    smokePS.emitRate = 200;
    smokePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_STANDARD;
    smokePS.gravity = new BABYLON.Vector3(0, 0.5, 0);
    smokePS.minEmitPower = 0.5;
    smokePS.maxEmitPower = 1.5;
    smokePS.start();
    
    // Işık efekti
    const light = new BABYLON.PointLight("fireLight", BABYLON.Vector3.Zero(), this.scene);
    light.parent = projectile;
    light.diffuse = new BABYLON.Color3(1, 0.5, 0);
    light.intensity = 1.5;
    light.range = 10;
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        firePS.dispose();
        smokePS.dispose();
        light.dispose();
    });
}

// Solar çarpışma efekti
createSolarImpact(position) {
    // Büyük patlama dalgası
    const explosionPS = new BABYLON.ParticleSystem("solarExplosion", 3000, this.scene);
    explosionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    explosionPS.emitter = position;
    explosionPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.5, -0.5);
    explosionPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.5, 0.5);
    explosionPS.color1 = new BABYLON.Color4(1.0, 0.5, 0.0, 1.0);
    explosionPS.color2 = new BABYLON.Color4(1.0, 0.2, 0.0, 1.0);
    explosionPS.colorDead = new BABYLON.Color4(0.5, 0.0, 0.0, 0.0);
    explosionPS.minSize = 0.5;
    explosionPS.maxSize = 1.5;
    explosionPS.minLifeTime = 0.3;
    explosionPS.maxLifeTime = 0.8;
    explosionPS.emitRate = 3000;
    explosionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    explosionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    explosionPS.direction1 = new BABYLON.Vector3(-5, -5, -5);
    explosionPS.direction2 = new BABYLON.Vector3(5, 5, 5);
    explosionPS.minEmitPower = 3;
    explosionPS.maxEmitPower = 8;
    explosionPS.updateSpeed = 0.01;
    explosionPS.targetStopDuration = 0.2;
    explosionPS.disposeOnStop = true;
    explosionPS.start();
    
    // Şok dalgası
    const shockwave = BABYLON.MeshBuilder.CreateDisc("shockwave", {
        radius: 0.1,
        tessellation: 64
    }, this.scene);
    
    shockwave.position = position.clone();
    shockwave.rotation.x = Math.PI / 2;
    
    const shockwaveMat = new BABYLON.StandardMaterial("shockwaveMat", this.scene);
    shockwaveMat.emissiveColor = new BABYLON.Color3(1.0, 0.5, 0.0);
    shockwaveMat.diffuseColor = new BABYLON.Color3(1.0, 0.3, 0.0);
    shockwaveMat.alpha = 0.7;
    shockwaveMat.disableLighting = true;
    shockwave.material = shockwaveMat;
    
    // Şok dalgası animasyonu
    const shockwaveAnim = new BABYLON.Animation(
        "shockwaveAnim",
        "scaling",
        60,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    shockwaveAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 30, value: new BABYLON.Vector3(30, 30, 1) }
    ]);
    
    const shockwaveAlphaAnim = new BABYLON.Animation(
        "shockwaveAlphaAnim",
        "material.alpha",
        60,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    shockwaveAlphaAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 30, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(shockwave, [shockwaveAnim, shockwaveAlphaAnim], 0, 30, false, 1, () => {
        shockwave.dispose();
    });
    
    // Ekrana bildirim
    this.showNotification("GÜÇLÜ VURUŞ! +3 HASAR", new BABYLON.Color3(1.0, 0.5, 0.0));
    
    // Ekran titreşimi
    this.shakeCamera(0.5, 500);
}

// Elektrik efektleri ekle
addElectricEffects(projectile) {
    // Elektrik materyali
    const electricMat = new BABYLON.StandardMaterial("electricMat", this.scene);
    electricMat.diffuseColor = new BABYLON.Color3(0.3, 0.3, 1.0);
    electricMat.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.8);
    projectile.material = electricMat;
    
    // Elektrik parçacıkları
    const electricPS = new BABYLON.ParticleSystem("electricParticles", 800, this.scene);
    electricPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    electricPS.emitter = projectile;
    electricPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    electricPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    electricPS.color1 = new BABYLON.Color4(0.4, 0.4, 1.0, 1.0);
    electricPS.color2 = new BABYLON.Color4(0.6, 0.6, 1.0, 1.0);
    electricPS.colorDead = new BABYLON.Color4(0.3, 0.3, 0.8, 0.0);
    electricPS.minSize = 0.1;
    electricPS.maxSize = 0.3;
    electricPS.minLifeTime = 0.05;
    electricPS.maxLifeTime = 0.2;
    electricPS.emitRate = 400;
    electricPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    electricPS.gravity = new BABYLON.Vector3(0, 0, 0);
    electricPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    electricPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    electricPS.minEmitPower = 1;
    electricPS.maxEmitPower = 3;
    electricPS.updateSpeed = 0.01;
    electricPS.start();
    
    // Sürekli şimşek arkları oluştur
    const createLightningArcs = () => {
        if (projectile.isDisposed()) return;
        
        // Altıgenin kenarlarından şimşekler
        const arcCount = 2 + Math.floor(Math.random() * 2); // 2-3 ark
        
        for (let i = 0; i < arcCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const radius = 1.0; // Altıgenin yarıçapı
            
            const startPoint = new BABYLON.Vector3(
                projectile.position.x + Math.cos(angle) * radius,
                projectile.position.y,
                projectile.position.z + Math.sin(angle) * radius
            );
            
            const endAngle = angle + (Math.random() * Math.PI / 2 - Math.PI / 4);
            const endDistance = 1.5 + Math.random() * 1.5;
            
            const endPoint = new BABYLON.Vector3(
                startPoint.x + Math.cos(endAngle) * endDistance,
                startPoint.y + (Math.random() - 0.5) * endDistance,
                startPoint.z + Math.sin(endAngle) * endDistance
            );
            
            const arcPoints = generateFractalLightning(startPoint, endPoint, 0.5, 0.1);
            const arc = BABYLON.MeshBuilder.CreateTube("electricArc", {
                path: arcPoints,
                radius: 0.05,
                updatable: false
            }, this.scene);
            
            const arcMat = new BABYLON.StandardMaterial("arcMat", this.scene);
            arcMat.emissiveColor = new BABYLON.Color3(0.6, 0.6, 1.0);
            arcMat.disableLighting = true;
            arc.material = arcMat;
            
            // Glow efekti
            const glowLayer = this.scene.getGlowLayerByName("glow");
            if (glowLayer) glowLayer.addIncludedOnlyMesh(arc);
            
            // Kısa süre sonra arkı yok et
            setTimeout(() => {
                if (glowLayer) glowLayer.removeIncludedOnlyMesh(arc);
                arc.dispose();
            }, 100 + Math.random() * 100);
        }
        
        // Yeni arklar oluşturmaya devam et
        setTimeout(createLightningArcs, 100 + Math.random() * 150);
    };
    
    createLightningArcs();
    
    // Işık efekti
    const light = new BABYLON.PointLight("electricLight", BABYLON.Vector3.Zero(), this.scene);
    light.parent = projectile;
    light.diffuse = new BABYLON.Color3(0.4, 0.4, 1.0);
    light.intensity = 1.5;
    light.range = 10;
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        electricPS.dispose();
        light.dispose();
    });
}


// Kalkan aktivasyonu (devam)
activateShield() {
    // Kalkan süresi
    const shieldDuration = 5000; // 5 saniye
    
    // Kalkan mesh'i
    const shield = BABYLON.MeshBuilder.CreateSphere("shield", {
        diameter: 4,
        segments: 16
    }, this.scene);
    
    // Kalkan materyali
    const shieldMat = new BABYLON.StandardMaterial("shieldMat", this.scene);
    shieldMat.diffuseColor = new BABYLON.Color3(0.4, 0.4, 1.0);
    shieldMat.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.8);
    shieldMat.alpha = 0.3;
    shield.material = shieldMat;
    
    // Kalkanı oyuncuya bağla
    shield.parent = this.currentGoldberg;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(shield);
    
    // Kalkan dalgalanma animasyonu
    const pulseAnim = new BABYLON.Animation(
        "shieldPulse",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    pulseAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(shield, 0, 30, true);
    
    // Elektrik parçacıkları
    const shieldPS = new BABYLON.ParticleSystem("shieldParticles", 200, this.scene);
    shieldPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    shieldPS.emitter = shield;
    shieldPS.minEmitBox = new BABYLON.Vector3(-1.5, -1.5, -1.5);
    shieldPS.maxEmitBox = new BABYLON.Vector3(1.5, 1.5, 1.5);
    shieldPS.color1 = new BABYLON.Color4(0.4, 0.4, 1.0, 1.0);
    shieldPS.color2 = new BABYLON.Color4(0.6, 0.6, 1.0, 1.0);
    shieldPS.colorDead = new BABYLON.Color4(0.3, 0.3, 0.8, 0.0);
    shieldPS.minSize = 0.1;
    shieldPS.maxSize = 0.3;
    shieldPS.minLifeTime = 0.2;
    shieldPS.maxLifeTime = 0.5;
    shieldPS.emitRate = 50;
    shieldPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    shieldPS.minEmitPower = 0.1;
    shieldPS.maxEmitPower = 0.3;
    shieldPS.updateSpeed = 0.01;
    shieldPS.start();
    
    // Kalkan aktif olduğu sürece oyuncuyu hasardan koru
    this.isShielded = true;
    
    // Ekrana bildirim
    this.showNotification("KALKAN AKTİF! 5 SANİYE KORUMA", new BABYLON.Color3(0.4, 0.4, 1.0));
    
    // Kalkan süresini gösteren UI
    const shieldTimerUI = document.createElement('div');
    shieldTimerUI.className = 'hud-timer';
    shieldTimerUI.style.top = '180px';
    shieldTimerUI.style.backgroundColor = 'rgba(50, 50, 255, 0.2)';
    shieldTimerUI.style.borderColor = 'rgba(100, 100, 255, 0.7)';
    
    shieldTimerUI.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
        </svg>
        <span>KALKAN: </span>
        <span id="shield-time">5.0s</span>
    `;
    
    document.body.appendChild(shieldTimerUI);
    
    // Kalkan süresini geri say
    const startTime = Date.now();
    const endTime = startTime + shieldDuration;
    
    const shieldInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const shieldTimeText = document.getElementById('shield-time');
        if (shieldTimeText) {
            shieldTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);
    
    // Kalkan süresinin sonunda
    setTimeout(() => {
        this.isShielded = false;
        
        // Kalkan kaybolma animasyonu
        const fadeAnim = new BABYLON.Animation(
            "shieldFade",
            "material.alpha",
            30,
            BABYLON.Animation.ANIMATIONTYPE_FLOAT
        );
        
        fadeAnim.setKeys([
            { frame: 0, value: 0.3 },
            { frame: 30, value: 0 }
        ]);
        
        this.scene.beginDirectAnimation(shield, [fadeAnim], 0, 30, false, 1, () => {
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(shield);
            shield.dispose();
            shieldPS.stop();
        });
        
        // UI'ı temizle
        clearInterval(shieldInterval);
        shieldTimerUI.remove();
        
        // Bildirim
        this.showNotification("KALKAN DEVRE DIŞI", new BABYLON.Color3(0.4, 0.4, 1.0));
    }, shieldDuration);
    
    // handleHazardHit metodunu geçici olarak değiştir
    const originalHandleHazardHit = this.handleHazardHit;
    this.handleHazardHit = function() {
        if (this.isShielded) {
            // Kalkan aktifken hasar almaz
            this.showNotification("HASAR ENGELLENDİ!", new BABYLON.Color3(0.4, 0.4, 1.0));
            
            // Kalkan dalgası efekti
            const shieldImpact = BABYLON.MeshBuilder.CreateSphere("shieldImpact", {
                diameter: 4.2,
                segments: 16
            }, this.scene);
            
            const impactMat = new BABYLON.StandardMaterial("impactMat", this.scene);
            impactMat.diffuseColor = new BABYLON.Color3(0.4, 0.4, 1.0);
            impactMat.emissiveColor = new BABYLON.Color3(0.6, 0.6, 1.0);
            impactMat.alpha = 0.5;
            shieldImpact.material = impactMat;
            
            shieldImpact.parent = this.currentGoldberg;
            
            // Dalgalanma ve kaybolma animasyonu
            const impactAnim = new BABYLON.Animation(
                "impactAnim",
                "scaling",
                30,
                BABYLON.Animation.ANIMATIONTYPE_VECTOR3
            );
            
            impactAnim.setKeys([
                { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
                { frame: 15, value: new BABYLON.Vector3(1.3, 1.3, 1.3) }
            ]);
            
            const impactFadeAnim = new BABYLON.Animation(
                "impactFadeAnim",
                "material.alpha",
                30,
                BABYLON.Animation.ANIMATIONTYPE_FLOAT
            );
            
            impactFadeAnim.setKeys([
                { frame: 0, value: 0.5 },
                { frame: 15, value: 0 }
            ]);
            
            this.scene.beginDirectAnimation(shieldImpact, [impactAnim, impactFadeAnim], 0, 15, false, 1, () => {
                shieldImpact.dispose();
            });
            
            return;
        }
        
        // Kalkan yoksa normal hasar alma
        originalHandleHazardHit.call(this);
    };
    
    // Kalkan süresi bittiğinde orijinal fonksiyonu geri yükle
    setTimeout(() => {
        this.handleHazardHit = originalHandleHazardHit;
    }, shieldDuration);
}

// Yerçekimi efektleri ekle
addGravityEffects(projectile) {
    // Yerçekimi materyali
    const gravityMat = new BABYLON.StandardMaterial("gravityMat", this.scene);
    gravityMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
    gravityMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
    projectile.material = gravityMat;
    
    // Yerçekimi parçacıkları
    const gravityPS = new BABYLON.ParticleSystem("gravityParticles", 600, this.scene);
    gravityPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    gravityPS.emitter = projectile;
    gravityPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    gravityPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    gravityPS.color1 = new BABYLON.Color4(0.2, 1.0, 0.3, 1.0);
    gravityPS.color2 = new BABYLON.Color4(0.5, 1.0, 0.6, 1.0);
    gravityPS.colorDead = new BABYLON.Color4(0.1, 0.3, 0.1, 0.0);
    gravityPS.minSize = 0.1;
    gravityPS.maxSize = 0.4;
    gravityPS.minLifeTime = 0.2;
    gravityPS.maxLifeTime = 0.6;
    gravityPS.emitRate = 300;
    gravityPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    gravityPS.gravity = new BABYLON.Vector3(0, 0, 0);
    gravityPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    gravityPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    gravityPS.minEmitPower = 1;
    gravityPS.maxEmitPower = 2;
    gravityPS.updateSpeed = 0.01;
    gravityPS.start();
    
    // Kalkan efekti
    const shield = BABYLON.MeshBuilder.CreateSphere("gravityShield", {
        diameter: 3,
        segments: 16
    }, this.scene);
    
    const shieldMat = new BABYLON.StandardMaterial("shieldMat", this.scene);
    shieldMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
    shieldMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
    shieldMat.alpha = 0.3;
    shield.material = shieldMat;
    
    shield.parent = projectile;
    
    // Kalkan dalgalanma animasyonu
    const shieldAnim = new BABYLON.Animation(
        "shieldAnim",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    shieldAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(shield, 0, 30, true);
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(shield);
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        gravityPS.dispose();
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(shield);
        shield.dispose();
    });
}

// Hız artışı aktivasyonu
// GoldbergController sınıfı içinde...

activateSpeedBoost() {
    const boostDuration = 10000; // 10 saniye

    // Eğer zaten bir hız artışı aktifse, mevcut zamanlayıcıyı temizle ki süre sıfırlansın.
    if (this.speedBoostTimeout) {
        clearTimeout(this.speedBoostTimeout);
    }

    // Hız çarpanını 2.0 yap.
    this.speedMultiplier = 2.0;

    // --- Görsel Efektler ve UI (Bu kısım aynı kalabilir) ---

    // Eğer aura zaten varsa, tekrar oluşturma. Sadece varlığını kontrol et.
    let speedAura = this.scene.getMeshByName("speedAura");
    if (!speedAura) {
        // Hız efekti
        const speedTrail = new BABYLON.ParticleSystem("speedTrail", 300, this.scene);
        speedTrail.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
        speedTrail.emitter = this.currentGoldberg;
        // ... (speedTrail ayarları)
        speedTrail.start();
        this.speedTrailEffect = speedTrail; // Efekti daha sonra durdurmak için sakla

        // Oyuncuya hız aura'sı ekle
        speedAura = BABYLON.MeshBuilder.CreateSphere("speedAura", { diameter: 2.5, segments: 16 }, this.scene);
        const auraMat = new BABYLON.StandardMaterial("auraMat", this.scene);
        auraMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
        auraMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
        auraMat.alpha = 0.3;
        speedAura.material = auraMat;
        speedAura.parent = this.currentGoldberg;

        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(speedAura);

        const auraAnim = new BABYLON.Animation("auraAnim", "scaling", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
        auraAnim.setKeys([{ frame: 0, value: new BABYLON.Vector3(1, 1, 1) }, { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) }, { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }]);
        this.scene.beginAnimation(speedAura, 0, 30, true);
    }

    // Ekrana bildirim
    this.showNotification("HIZ ARTIŞI! 10 SANİYE", new BABYLON.Color3(0.2, 0.8, 0.3));

    // Hız süresini gösteren UI (Eğer zaten varsa, tekrar oluşturma)
    let speedTimerUI = document.getElementById('speed-timer-container');
    if (!speedTimerUI) {
        speedTimerUI = document.createElement('div');
        speedTimerUI.id = 'speed-timer-container';
        speedTimerUI.className = 'hud-timer';
        // ... (UI stil ayarları)
        speedTimerUI.innerHTML = `... HIZ: <span id="speed-time">10.0s</span> ...`;
        document.body.appendChild(speedTimerUI);
    }
    
    // Hız süresini geri say
    const endTime = Date.now() + boostDuration;
    if (this.speedInterval) clearInterval(this.speedInterval);
    this.speedInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const speedTimeText = document.getElementById('speed-time');
        if (speedTimeText) {
            speedTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);

    // Hız artışı süresinin sonunda çalışacak olan zamanlayıcı
    this.speedBoostTimeout = setTimeout(() => {
        // Hız çarpanını normale döndür
        this.speedMultiplier = 1.0;

        // Efektleri temizle
        if (this.speedTrailEffect) {
            this.speedTrailEffect.stop();
            this.speedTrailEffect = null;
        }
        
        const aura = this.scene.getMeshByName("speedAura");
        if (aura) {
            const glowLayer = this.scene.getGlowLayerByName("glow");
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(aura);
            aura.dispose();
        }

        // UI'ı temizle
        clearInterval(this.speedInterval);
        if (speedTimerUI) speedTimerUI.remove();

        // Bildirim
        this.showNotification("HIZ ARTIŞI SONA ERDİ", new BABYLON.Color3(0.2, 0.8, 0.3));
    }, boostDuration);
}

// Karanlık enerji efektleri ekle
addDarkEnergyEffects(projectile) {
    // Karanlık enerji materyali
    const darkMat = new BABYLON.StandardMaterial("darkMat", this.scene);
    darkMat.diffuseColor = new BABYLON.Color3(0.5, 0.1, 0.8);
    darkMat.emissiveColor = new BABYLON.Color3(0.3, 0.0, 0.5);
    projectile.material = darkMat;
    
    // Karanlık enerji parçacıkları
    const darkPS = new BABYLON.ParticleSystem("darkParticles", 600, this.scene);
    darkPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    darkPS.emitter = projectile;
    darkPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    darkPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    darkPS.color1 = new BABYLON.Color4(0.7, 0.2, 1.0, 1.0);
    darkPS.color2 = new BABYLON.Color4(0.5, 0.1, 0.8, 1.0);
    darkPS.colorDead = new BABYLON.Color4(0.3, 0.0, 0.5, 0.0);
    darkPS.minSize = 0.1;
    darkPS.maxSize = 0.4;
    darkPS.minLifeTime = 0.2;
    darkPS.maxLifeTime = 0.6;
    darkPS.emitRate = 300;
    darkPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    darkPS.gravity = new BABYLON.Vector3(0, 0, 0);
    darkPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    darkPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    darkPS.minEmitPower = 1;
    darkPS.maxEmitPower = 2;
    darkPS.updateSpeed = 0.01;
    darkPS.start();
    
    // Karanlık enerji halkası
    const darkRing = BABYLON.MeshBuilder.CreateTorus("darkRing", {
        diameter: 3,
        thickness: 0.4,
        tessellation: 32
    }, this.scene);
    
    const ringMat = new BABYLON.StandardMaterial("darkRingMat", this.scene);
    ringMat.emissiveColor = new BABYLON.Color3(0.5, 0.1, 0.8);
    ringMat.alpha = 0.7;
    ringMat.disableLighting = true;
    darkRing.material = ringMat;
    
    darkRing.parent = projectile;
    darkRing.rotation.x = Math.PI / 2;
    
    // Dönme animasyonu
    const ringAnim = new BABYLON.Animation(
        "ringRotation",
        "rotation.z",
        30,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    ringAnim.setKeys([
        { frame: 0, value: 0 },
        { frame: 30, value: Math.PI * 2 }
    ]);
    
    this.scene.beginAnimation(darkRing, 0, 30, true);
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(darkRing);
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        darkPS.dispose();
        darkRing.dispose();
    });
}

// Çekim alanı aktivasyonu (devam)
activateAttractionField() {
    // Çekim alanı süresi
    const attractionDuration = 15000; // 15 saniye
    
    // Orijinal toplama çapını sakla
    const originalPickupRadius = 2.5; // Varsayılan değer
    
    // Yeni toplama çapı
    const enhancedPickupRadius = 6.0;
    
    // Çekim alanı görsel efekti
    const attractionField = BABYLON.MeshBuilder.CreateSphere("attractionField", {
        diameter: enhancedPickupRadius * 2,
        segments: 16
    }, this.scene);
    
    const fieldMat = new BABYLON.StandardMaterial("fieldMat", this.scene);
    fieldMat.diffuseColor = new BABYLON.Color3(0.7, 0.2, 1.0);
    fieldMat.emissiveColor = new BABYLON.Color3(0.4, 0.1, 0.6);
    fieldMat.alpha = 0.15;
    attractionField.material = fieldMat;
    
    attractionField.parent = this.currentGoldberg;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(attractionField);
    
    // Alan dalgalanma animasyonu
    const fieldAnim = new BABYLON.Animation(
        "fieldAnim",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    fieldAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(attractionField, 0, 30, true);
    
    // Çekim parçacıkları
    const attractionPS = new BABYLON.ParticleSystem("attractionPS", 50, this.scene);
    attractionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    attractionPS.emitter = this.currentGoldberg;
    attractionPS.minEmitBox = new BABYLON.Vector3(-enhancedPickupRadius, 0, -enhancedPickupRadius);
    attractionPS.maxEmitBox = new BABYLON.Vector3(enhancedPickupRadius, 0, enhancedPickupRadius);
    attractionPS.color1 = new BABYLON.Color4(0.7, 0.2, 1.0, 0.5);
    attractionPS.color2 = new BABYLON.Color4(0.5, 0.1, 0.8, 0.5);
    attractionPS.colorDead = new BABYLON.Color4(0.3, 0.0, 0.5, 0.0);
    attractionPS.minSize = 0.1;
    attractionPS.maxSize = 0.3;
    attractionPS.minLifeTime = 0.5;
    attractionPS.maxLifeTime = 1.0;
    attractionPS.emitRate = 20;
    attractionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    attractionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    attractionPS.minEmitPower = 0;
    attractionPS.maxEmitPower = 0;
    attractionPS.updateSpeed = 0.01;
    
    // Özel güncelleme fonksiyonu - parçacıkları oyuncuya doğru hareket ettir
    attractionPS.updateFunction = (particles) => {
        for (let i = 0; i < particles.length; i++) {
            const particle = particles[i];
            const directionToPlayer = this.currentGoldberg.position.subtract(particle.position);
            const distance = directionToPlayer.length();
            
            if (distance < 0.5) {
                particle.age = particle.lifeTime; // Parçacığı yok et
                continue;
            }
            
            // Parçacığı oyuncuya doğru hareket ettir
            const speed = 0.05 + (1.0 - distance / enhancedPickupRadius) * 0.1;
            particle.direction = directionToPlayer.normalize().scale(speed);
            particle.position.addInPlace(particle.direction);
        }
    };
    
    attractionPS.start();
    
    // Ekrana bildirim
    this.showNotification("ÇEKİM ALANI AKTİF! 15 SANİYE", new BABYLON.Color3(0.7, 0.2, 1.0));
    
    // Çekim alanı süresini gösteren UI
    const attractionTimerUI = document.createElement('div');
    attractionTimerUI.className = 'hud-timer';
    attractionTimerUI.style.top = '180px';
    attractionTimerUI.style.backgroundColor = 'rgba(150, 50, 255, 0.2)';
    attractionTimerUI.style.borderColor = 'rgba(200, 100, 255, 0.7)';
    
    attractionTimerUI.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M8 12h8"></path>
            <path d="M12 8v8"></path>
        </svg>
        <span>ÇEKİM ALANI: </span>
        <span id="attraction-time">15.0s</span>
    `;
    
    document.body.appendChild(attractionTimerUI);
    
    // Çekim alanı süresini geri say
    const startTime = Date.now();
    const endTime = startTime + attractionDuration;
    
    const attractionInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const attractionTimeText = document.getElementById('attraction-time');
        if (attractionTimeText) {
            attractionTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);
    
    // Çekim alanı aktif olduğu sürece hex toplama mesafesini artır
    this.hasAttractionField = true;
    this.attractionFieldRadius = enhancedPickupRadius;
    
    // Yeni bir hex toplama fonksiyonu ekle
    const hexPickupObserver = this.scene.onBeforeRenderObservable.add(() => {
        if (!gameManager.state.isRunning) return;
        
        const playerMesh = this.currentGoldberg;
        const ground = this.scene.getTransformNodeByName("ground");
        
        if (ground) {
            ground.getChildMeshes().forEach(hex => {
                if (hex.isPlayable && hex.specialColor) {
                    const dist = BABYLON.Vector3.Distance(playerMesh.position, hex.getAbsolutePosition());
                    const pickupRadius = this.hasAttractionField ? this.attractionFieldRadius : originalPickupRadius;
                    
                    if (dist < pickupRadius) {
                        // Hex'i topla
                        createFlyingHexAnimation(hex, gameManager.pentaTileController.mesh.position, this.scene, gameManager, true);
                        
                        // Çekim efekti
                        if (this.hasAttractionField && dist > originalPickupRadius) {
                            this.createAttractionEffect(hex.getAbsolutePosition());
                        }
                    }
                }
            });
        }
    });
    
    // Çekim alanı süresinin sonunda
    setTimeout(() => {
        this.hasAttractionField = false;
        
        // Alan kaybolma animasyonu
        const fadeAnim = new BABYLON.Animation(
            "fieldFade",
            "material.alpha",
            30,
            BABYLON.Animation.ANIMATIONTYPE_FLOAT
        );
        
        fadeAnim.setKeys([
            { frame: 0, value: 0.15 },
            { frame: 30, value: 0 }
        ]);
        
        this.scene.beginDirectAnimation(attractionField, [fadeAnim], 0, 30, false, 1, () => {
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(attractionField);
            attractionField.dispose();
            attractionPS.stop();
        });
        
        // UI'ı temizle
        clearInterval(attractionInterval);
        attractionTimerUI.remove();
        
        // Bildirim
        this.showNotification("ÇEKİM ALANI SONA ERDİ", new BABYLON.Color3(0.7, 0.2, 1.0));
        
        // Eklenen observer'ı kaldır
        this.scene.onBeforeRenderObservable.remove(hexPickupObserver);
    }, attractionDuration);
}

// Çekim efekti
createAttractionEffect(hexPosition) {
    // Hex'ten oyuncuya doğru çekim çizgisi
    const points = [];
    const startPoint = hexPosition.clone();
    const endPoint = this.currentGoldberg.position.clone();
    
    // Hafif kavisli bir çizgi oluştur
    const midPoint = BABYLON.Vector3.Lerp(startPoint, endPoint, 0.5);
    midPoint.y += 1 + Math.random();
    
    // Bezier eğrisi için noktalar
    for (let i = 0; i <= 10; i++) {
        const t = i / 10;
        const point = new BABYLON.Vector3(
            (1-t)*(1-t)*startPoint.x + 2*(1-t)*t*midPoint.x + t*t*endPoint.x,
            (1-t)*(1-t)*startPoint.y + 2*(1-t)*t*midPoint.y + t*t*endPoint.y,
            (1-t)*(1-t)*startPoint.z + 2*(1-t)*t*midPoint.z + t*t*endPoint.z
        );
        points.push(point);
    }
    
    // Çekim çizgisi
    const attractionLine = BABYLON.MeshBuilder.CreateTube("attractionLine", {
        path: points,
        radius: 0.05,
        updatable: false
    }, this.scene);
    
    const lineMat = new BABYLON.StandardMaterial("lineMat", this.scene);
    lineMat.emissiveColor = new BABYLON.Color3(0.7, 0.2, 1.0);
    lineMat.alpha = 0.7;
    lineMat.disableLighting = true;
    attractionLine.material = lineMat;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(attractionLine);
    
    // Çizgi kaybolma animasyonu
    const fadeAnim = new BABYLON.Animation(
        "lineFade",
        "material.alpha",
        30,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    fadeAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 15, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(attractionLine, [fadeAnim], 0, 15, false, 1, () => {
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(attractionLine);
        attractionLine.dispose();
    });
}

    }