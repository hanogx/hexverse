export class Joystick3DController {
    constructor(scene, movementController) {
        this.scene = scene;
        this.movementController = movementController;
        this.camera = null;
        this.uiParent = null; 
        this.base = null;     
        this.nub = null;      

        this.isDragging = false;
        this.pointerId = -1;
        
        this.baseRadius = 7; 
        this.maxPixelRadius = 100;

        // Ekran yönünü takip etmek için yeni değişkenler
        this.isLandscape = true;
        this.lastScreenWidth = 0;
        this.lastScreenHeight = 0;
        
        // Joystick için ergonomik konumlar
        this.landscapePosition = new BABYLON.Vector3(1.5, -2.5, 12);
        this.portraitPosition = new BABYLON.Vector3(1.0, -1.8, 12);

        this.initialPointerPos = new BABYLON.Vector2(0, 0);
    }

    createUI(camera) {
        this.camera = camera;
        if (this.uiParent) this.uiParent.dispose();

        // İlk yükleme için ekran boyutunu kaydet
        this.lastScreenWidth = engine.getRenderWidth();
        this.lastScreenHeight = engine.getRenderHeight();
        this.isLandscape = this.lastScreenWidth > this.lastScreenHeight;
        
        // Ekran yönüne göre ilk konumlandırma
        this.updatePositionForOrientation();

        this.uiParent = new BABYLON.TransformNode("JoystickUIParent", this.scene);
        this.uiParent.parent = this.camera;
        this.uiParent.position = new BABYLON.Vector3(1.5, -2.5, 12);

        const baseMaterial = new BABYLON.PBRMaterial("joyBaseMat", this.scene);
        baseMaterial.metallic = 0.3;
        baseMaterial.roughness = 0.7;
        baseMaterial.albedoColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        baseMaterial.alpha = 0.5;

        const nubMaterial = new BABYLON.PBRMaterial("joyNubMat", this.scene);
        nubMaterial.metallic = 0.8;
        nubMaterial.roughness = 0.4;
        nubMaterial.albedoColor = new BABYLON.Color3(0.9, 0.1, 0.1);
        nubMaterial.emissiveColor = new BABYLON.Color3(0.5, 0.05, 0.05);

        this.base = BABYLON.MeshBuilder.CreateCylinder("joystickBase", { height: 0.2, diameter: this.baseRadius * 1.5, tessellation: 6 }, this.scene);
        this.base.material = baseMaterial;
        this.base.parent = this.uiParent;
        this.base.rotation.x = Math.PI / 2;

        this.nub = BABYLON.MeshBuilder.CreateCylinder("joystickNub", { height: 0.5, diameter: 5, tessellation: 6 }, this.scene);
        this.nub.material = nubMaterial;
        this.nub.parent = this.base;
        this.nub.position.z = -0.5;

        this.scene.onPointerObservable.add((pointerInfo) => {
            switch (pointerInfo.type) {
                case BABYLON.PointerEventTypes.POINTERDOWN:
                    if (!gameManager.state.isRunning || this.isDragging) return;
                    
                    const pickResult = this.scene.pick(this.scene.pointerX, this.scene.pointerY, (mesh) => mesh === this.base);
                    if (pickResult.hit) {
                        this.isDragging = true;
                        this.pointerId = pointerInfo.event.pointerId;
                        this.initialPointerPos.set(this.scene.pointerX, this.scene.pointerY);
                        this.updateMovement(this.scene.pointerX, this.scene.pointerY);
                    }
                    break;
                case BABYLON.PointerEventTypes.POINTERUP:
                case BABYLON.PointerEventTypes.POINTEROUT:
                    if (pointerInfo.event.pointerId === this.pointerId) {
                        this.isDragging = false;
                        this.pointerId = -1;
                        this.resetMovement();
                    }
                    break;
                case BABYLON.PointerEventTypes.POINTERMOVE:
                    if (this.isDragging && pointerInfo.event.pointerId === this.pointerId) {
                        this.updateMovement(this.scene.pointerX, this.scene.pointerY);
                    }
                    break;
            }
        });

        this.adjustUIScale();
        window.addEventListener('resize', () => this.adjustUIScale());
        this.hide();
    }

updatePositionForOrientation() {
    if (!this.uiParent) return;
    
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const isLandscape = width > height;
    
    if (isLandscape) {
        // Yatay ekran - joystick sağ alt köşede
        this.uiParent.position = new BABYLON.Vector3(1.5, -2.5, 12);
    } else {
        // Dikey ekran - joystick alt orta-sağda
        this.uiParent.position = new BABYLON.Vector3(1.0, -1.8, 12);
    }
}

increaseTouchArea() {
    // Dokunmatik alanı genişlet
    const touchArea = BABYLON.MeshBuilder.CreateCylinder("touchArea", {
        diameter: this.baseRadius * 2.5,
        height: 0.1,
        tessellation: 12
    }, this.scene);
    touchArea.visibility = 0; // Görünmez yap
    touchArea.parent = this.base;
    touchArea.isPickable = true;
    this.base.isPickable = true;
}

    updateMovement(currentX, currentY) {
        const deltaX = currentX - this.initialPointerPos.x;
        const deltaY = currentY - this.initialPointerPos.y;
        const moveVector = new BABYLON.Vector2(deltaX, deltaY);

        // Görsel topuzu sürüklenen mesafeye göre hareket ettir
        const clampedVector = moveVector.clone();
        if (moveVector.length() > this.maxPixelRadius) {
            clampedVector.normalize().scaleInPlace(this.maxPixelRadius);
        }
    this.nub.position.x = clampedVector.x / this.maxPixelRadius * (this.baseRadius / 2);
    this.nub.position.z = clampedVector.y / this.maxPixelRadius * (this.baseRadius / 2);

        // Hareketi 0-1 arasında bir güce dönüştür
        const force = Math.min(1.0, moveVector.length() / this.maxPixelRadius);
        const normalizedVector = moveVector.normalize();

        if (force > 0.1) {
            // *** EKSEN HARİTALAMA DÜZELTMESİ ***
            // Bu kod, joystick hareketini sizin klavye kontrollerinizle birebir eşler.
            // Sürükleme Yukarı/Aşağı (normalizedVector.y) -> Oyuncu Sağa/Sola (xVelocity)
            // Sürükleme Sağa/Sola (normalizedVector.x) -> Oyuncu Yukarı/Aşağı (zVelocity)
            this.movementController.setVelocity(-normalizedVector.y * force, -normalizedVector.x * force);
        } else {
            this.movementController.setVelocity(0, 0);
        }
    }
    
    resetMovement() {
        this.nub.position.x = 0;
        this.nub.position.y = 0;
        this.movementController.setVelocity(0, 0);
    }
    
adjustUIScale() {
    if (!this.uiParent) return;
    
    // Sabit bir ölçeklendirme faktörü kullan
    const baseScale = 0.1; // Bu değeri joystick boyutuna göre ayarlayın
    
    this.uiParent.scaling = new BABYLON.Vector3(baseScale, baseScale, baseScale);
}

    show() { if (this.uiParent) this.uiParent.setEnabled(true); }
    hide() { if (this.uiParent) this.uiParent.setEnabled(false); }
}