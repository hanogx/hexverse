export function createPentaHUD(scene) {
  // TODO: Port InGameUIController parts here or keep controller class usage.
}