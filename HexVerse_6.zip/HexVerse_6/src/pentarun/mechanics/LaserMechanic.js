export class LaserMechanic extends PentaMechanic { 
        constructor(scene, pentaTileController, gameManager) { 
            super(scene, pentaTileController, gameManager); 
            this.lasersNode = scene.getTransformNodeByName("lasersContainer"); 
            this.originalPentaMat = this.pentaTileController.originalMaterial; 
            this.warningMat = scene.getMaterialByName("iceBlueMat"); 
            this.laserMat = scene.getMaterialByName("laserMat"); 
            this.rotationSpeed = 0; 
            this.warningInterval = null; 
            this.activationTimeout = null; 
            this.mainInterval = null; 
        } 

        initialize() { 
            this.cleanup(); // Önceki kalıntıları temizle 
            this.mainInterval = setInterval(() => { 
                if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                    this.startWarning(); 
                } 
            }, GAME_CONSTANTS.LASER_SPAWN_INTERVAL); 
        } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }
        startWarning() { 
            this.isWarmingUp = true; 
            this.gameManager.setCoreWarning(true); 
            let isBlue = false; 
            this.warningInterval = setInterval(() => { 
                isBlue = !isBlue; 
                this.pentaTile.material = isBlue ? this.warningMat : this.originalPentaMat; 
            }, 400); 
             
            if (this.laserMat) this.laserMat.emissiveColor = new BABYLON.Color3(0.2, 0.4, 0.6); 
            this.lasersNode.setEnabled(true); 

            this.activationTimeout = setTimeout(() => { 
                clearInterval(this.warningInterval); 
                this.warningInterval = null; 
                this.isWarmingUp = false; 
                this.gameManager.setCoreWarning(false); 
                if (this.gameManager.state.isRunning) { 
                    this.activate(); 
                } 
            }, GAME_CONSTANTS.LASER_WARNING_DURATION); 
        } 

        activate() { 
            this.isActive = true; 
            this.pentaTile.material = this.warningMat; 
            if (this.laserMat) this.laserMat.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0); 
            const direction = Math.random() < 0.5 ? 1 : -1; 
            this.rotationSpeed = GAME_CONSTANTS.LASER_ROTATION_SPEED * direction; 
             
            this.activationTimeout = setTimeout(() => this.deactivate(), 5000); 
        } 

        deactivate() { 
            this.pentaTile.material = this.originalPentaMat; 
            this.lasersNode.setEnabled(false); 
            this.rotationSpeed = 0; 
            this.isActive = false; 
        } 

        update(deltaTime) { 
            if (this.rotationSpeed !== 0) { 
                this.lasersNode.rotation.y += this.rotationSpeed * deltaTime; 
            } 
        } 

        checkCollision(playerMesh) { 
            if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return; 
             
            const laserArms = this.lasersNode.getChildren(); 
            for (const arm of laserArms) { 
                const laser = arm.getChildMeshes(false)[0]; 
                if (laser && playerMesh.intersectsMesh(laser, true)) { 
                    this.gameManager.goldbergController.handleHazardHit(); 
                    break; 
                } 
            } 
        } 

        cleanup() { 
            clearInterval(this.mainInterval); 
            clearInterval(this.warningInterval); 
            clearTimeout(this.activationTimeout); 
            this.deactivate(); 
        } 
    }