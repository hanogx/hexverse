export class SolarMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 
         
        this.coneBaseDirections = []; 
        const pentaVertices = this.pentaTile.getVerticesData(BABYLON.VertexBuffer.PositionKind); 
        if (pentaVertices) { 
            for(let i = 0; i < 5; i++) { 
                const vec = new BABYLON.Vector3(pentaVertices[i*3], 0, pentaVertices[i*3+2]).normalize(); 
                this.coneBaseDirections.push(vec); 
            } 
        } 

        this.coneAngle = Math.PI / 3;  

        this.warningMat = this.scene.getMaterialByName("solarWarningMat"); 
        this.defaultWarningAlpha = this.warningMat.alpha; // Orijinal alpha değerini sakla 
        this.playableHexMat = this.scene.getMaterialByName("playableHexMat"); 

        this.activeConeDirections = [];  
        this.targetedHexes = []; 
        this.activeParticleSystems = []; 

        this.mainInterval = null; 
        this.warningInterval = null; 
        this.activationTimeout = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 12000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
         
        this.targetedHexes = []; 
        this.activeConeDirections = []; 

        const minAngleBetween = Math.PI / 3; 
        let availableDirections = [...this.coneBaseDirections]; 
         
        while (this.activeConeDirections.length < 3 && availableDirections.length > 0) { 
            const randomIndex = Math.floor(Math.random() * availableDirections.length); 
            const candidateDirection = availableDirections.splice(randomIndex, 1)[0]; 
             
            let isFarEnough = true; 
            for (const selectedDir of this.activeConeDirections) { 
                const angle = Math.acos(BABYLON.Vector3.Dot(selectedDir, candidateDirection)); 
                if (angle < minAngleBetween) { 
                    isFarEnough = false; 
                    break; 
                } 
            } 

            if (isFarEnough) { 
                this.activeConeDirections.push(candidateDirection); 
            } 
        } 

        const ground = this.scene.getTransformNodeByName("ground"); 
        const allPlayableHexes = ground.getChildMeshes().filter(m => m.isPlayable); 
         
        this.activeConeDirections.forEach(direction => { 
            allPlayableHexes.forEach(hex => { 
                if (!this.targetedHexes.includes(hex)) { 
                    const hexPos = hex.getAbsolutePosition().normalize(); 
                    const dotProduct = BABYLON.Vector3.Dot(hexPos, direction); 
                    if (dotProduct > Math.cos(this.coneAngle / 2)) { 
                        this.targetedHexes.push(hex); 
                    } 
                } 
            }); 
        }); 

        // --- YENİ: Pulse Efekti Mantığı --- 
        // Önce tüm hedeflere uyarı materyalini ata 
        this.targetedHexes.forEach(hex => { 
            if(hex && !hex.isDisposed()) hex.material = this.warningMat; 
        }); 

        // Sonra bu materyalin alpha değerini periyodik olarak değiştir 
        let pulseDirection = 1; // 1: artan, -1: azalan 
        this.warningInterval = setInterval(() => { 
            let currentAlpha = this.warningMat.alpha; 
            currentAlpha += 0.03 * pulseDirection; // Pulse hızı 

            if (currentAlpha > 0.7) { 
                currentAlpha = 0.7; 
                pulseDirection = -1; 
            } else if (currentAlpha < 0.2) { 
                currentAlpha = 0.2; 
                pulseDirection = 1; 
            } 
            this.warningMat.alpha = currentAlpha; 
        }, 50); // 50ms aralıklarla güncelleyerek akıcı bir efekt sağla 
        // --- Pulse Efekti Sonu --- 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); // Pulse interval'ini durdur 
            this.warningMat.alpha = this.defaultWarningAlpha; // Materyalin alpha'sını orijinal haline getir 

            this.isWarmingUp = false; 
            this.targetedHexes.forEach(hex => { 
                if(hex && !hex.isDisposed()) hex.material = this.playableHexMat; 
            }); 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 3000); 
    } 

    activate() { 
        this.isActive = true; 

        this.targetedHexes.forEach(hex => { 
            if (!hex || hex.isDisposed()) return; 
            const fireEffect = new BABYLON.ParticleSystem("tileFire_" + hex.uniqueId, 500, this.scene); 
            fireEffect.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene); 
            fireEffect.emitter = hex; 
            fireEffect.minEmitBox = new BABYLON.Vector3(-0.5, 0.1, -0.5); 
            fireEffect.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5); 
            fireEffect.color1 = new BABYLON.Color4(1.0, 0.5, 0, 1.0); 
            fireEffect.color2 = new BABYLON.Color4(1.0, 0.2, 0, 1.0); 
            fireEffect.colorDead = new BABYLON.Color4(0.2, 0, 0, 0.0); 
            fireEffect.minSize = 0.2; 
            fireEffect.maxSize = 0.6; 
            fireEffect.minLifeTime = 0.5; 
            fireEffect.maxLifeTime = 1.2; 
            fireEffect.emitRate = 150; 
            fireEffect.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
            fireEffect.gravity = new BABYLON.Vector3(0, 5, 0); 
            fireEffect.direction1 = new BABYLON.Vector3(-0.5, 1, -0.5); 
            fireEffect.direction2 = new BABYLON.Vector3(0.5, 1, 0.5); 
            fireEffect.minAngularSpeed = 0; 
            fireEffect.maxAngularSpeed = Math.PI; 
            fireEffect.minEmitPower = 0.5; 
            fireEffect.maxEmitPower = 1.5; 
            fireEffect.updateSpeed = 0.008; 
            fireEffect.start(); 
            this.activeParticleSystems.push(fireEffect); 
        }); 

        this.activationTimeout = setTimeout(() => this.deactivate(), 4000); 
    } 

    deactivate() { 
        this.isActive = false; 

        // GÜNCELLEME: Temizlik yaparken materyalin alpha'sını da sıfırla 
        this.warningMat.alpha = this.defaultWarningAlpha; 

        this.activeParticleSystems.forEach(ps => { 
            ps.stop(); 
            ps.dispose(); 
        }); 
        this.activeParticleSystems = []; 

        this.targetedHexes = []; 
        this.activeConeDirections = []; 
    } 

    checkCollision(playerMesh) { 
        if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return; 
         
        let hasBeenHit = false; 
        for (const hex of this.targetedHexes) { 
            if (hex && !hex.isDisposed()) { 
                const distance = BABYLON.Vector3.Distance(playerMesh.getAbsolutePosition(), hex.getAbsolutePosition()); 
                if (distance < GAME_CONSTANTS.HEX_RADIUS * 1.5) { 
                    hasBeenHit = true; 
                    break;  
                } 
            } 
        } 

        if(hasBeenHit) { 
            this.gameManager.goldbergController.handleHazardHit(); 
        } 
    } 

    cleanup() { 
        // GÜNCELLEME: Tüm zamanlayıcıları ve efektleri temizlerken materyali de sıfırla 
        clearInterval(this.mainInterval); 
        clearInterval(this.warningInterval); // Pulse interval'ini de durdurduğumuzdan emin olalım 
        clearTimeout(this.activationTimeout); 
         
        this.targetedHexes.forEach(hex => { 
            if(hex && !hex.isDisposed() && hex.material === this.warningMat) { 
                hex.material = this.playableHexMat; 
            } 
        }); 

        this.deactivate(); 
    } 
}