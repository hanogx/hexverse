export class EMWaveMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 
         
        // Ana arkların ve kürelerin materyali 
        this.arcMaterial = new BABYLON.StandardMaterial("emArcMat", scene); 
        this.arcMaterial.emissiveColor = this.scene.metadata.hexColors['em_blue'].emissiveColor.scale(1.8); 
        this.arcMaterial.disableLighting = true; 
         
        // Kılcal şimşeklerin materyali (daha ince ve parlak) 
        this.fractalMaterial = new BABYLON.StandardMaterial("emFractalMat", scene); 
        this.fractalMaterial.emissiveColor = new BABYLON.Color3(0.7, 0.8, 1.0).scale(1.5); 
        this.fractalMaterial.disableLighting = true; 

        this.glowLayer = this.scene.getGlowLayerByName("glow"); 
        this.arcsRoot = new BABYLON.TransformNode("arcsRoot", this.scene); 
         
        this.projectileSpeed = 4.0; 
        this.activeArcs = []; 

        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['em_blue']; 
         
        // Penta Tile üzerindeki şimşekler için 
        this.pentaVertices = this.pentaTile.getVerticesData(BABYLON.VertexBuffer.PositionKind); 
        this.pentaSparks = []; 
        this.lastPentaSparkTime = 0; 

        // Zamanlayıcılar 
        this.mainInterval = null; 
        this.warningTimeout = null; 
        this.warningInterval = null; 
        this.spawnerInterval = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 12000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
         
        let isPulsed = false; 
        this.warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); 
            this.warningInterval = null; 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 2500); 
    } 

    activate() { 
        this.isActive = true; 
        this.activeArcs = []; 
         
        // Saldırı boyunca Penta Tile'ı mavi yap 
        this.pentaTile.material = this.pentaPulseMaterial; 

        let setsSpawned = 0; 
        const totalSets = 4; 
         
        this.spawnerInterval = setInterval(() => { 
            if (setsSpawned >= totalSets) { 
                clearInterval(this.spawnerInterval); 
                this.spawnerInterval = null; 
                return; 
            } 
             
            const arcCount = 5; 
            const angleStep = (Math.PI * 2) / arcCount; 
            const arcWidthRadians = BABYLON.Tools.ToRadians(30); 
            const randomOffset = Math.random() * Math.PI * 2; 

            for (let i = 0; i < arcCount; i++) { 
                const centerAngle = i * angleStep + randomOffset; 
                const angle1 = centerAngle - (arcWidthRadians / 2); 
                const angle2 = centerAngle + (arcWidthRadians / 2); 
                const dir1 = new BABYLON.Vector3(Math.cos(angle1), 0, Math.sin(angle1)); 
                const dir2 = new BABYLON.Vector3(Math.cos(angle2), 0, Math.sin(angle2)); 

                const sphere1 = BABYLON.MeshBuilder.CreateSphere("emSphere", {diameter: 1.0}, this.scene); 
                sphere1.material = this.arcMaterial; 
                sphere1.position = this.pentaTile.position.clone(); 
                sphere1.direction = dir1; 
                 
                const sphere2 = sphere1.clone("emSphere2"); 
                sphere2.direction = dir2; 

                const tube = BABYLON.MeshBuilder.CreateTube("arcTube", { path: [sphere1.position, sphere2.position], radius: 0.1, updatable: true }, this.scene); 
                tube.material = this.arcMaterial; 

                sphere1.parent = this.arcsRoot; 
                sphere2.parent = this.arcsRoot; 
                tube.parent = this.arcsRoot; 
                 
                if (this.glowLayer) { 
                    this.glowLayer.addIncludedOnlyMesh(sphere1); 
                    this.glowLayer.addIncludedOnlyMesh(sphere2); 
                    this.glowLayer.addIncludedOnlyMesh(tube); 
                } 
                 
                this.activeArcs.push({ sphere1, sphere2, tube, lastFractalTime: 0 }); 
            } 
            setsSpawned++; 
        }, 1500); 
    } 

    update(deltaTime) { 
        if (!this.isActive && this.activeArcs.length === 0) return; 
         
        const now = performance.now(); 

        // YENİ: Penta Tile üzerinde şimşek efekti 
        if (this.isActive && now - this.lastPentaSparkTime > 200) { // Her 200ms'de bir 
            this.lastPentaSparkTime = now; 
            const vertexCount = this.pentaVertices.length / 3; 
            const i1 = Math.floor(Math.random() * vertexCount); 
            const i2 = Math.floor(Math.random() * vertexCount); 
             
            const p1_local = new BABYLON.Vector3(this.pentaVertices[i1*3], this.pentaVertices[i1*3+1], this.pentaVertices[i1*3+2]); 
            const p2_local = new BABYLON.Vector3(this.pentaVertices[i2*3], this.pentaVertices[i2*3+1], this.pentaVertices[i2*3+2]); 

            const p1_world = BABYLON.Vector3.TransformCoordinates(p1_local, this.pentaTile.getWorldMatrix()); 
            const p2_world = BABYLON.Vector3.TransformCoordinates(p2_local, this.pentaTile.getWorldMatrix()); 
             
            const fractalPath = generateFractalLightning(p1_world, p2_world, 1.5, 0.3); 
            const spark = BABYLON.MeshBuilder.CreateTube("pentaSpark", {path: fractalPath, radius: 0.03}, this.scene); 
            spark.material = this.fractalMaterial; 
            if (this.glowLayer) this.glowLayer.addIncludedOnlyMesh(spark); 
            this.pentaSparks.push(spark); 

            setTimeout(() => { 
                if (spark && !spark.isDisposed()){ 
                    if (this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(spark); 
                    spark.dispose(); 
                    this.pentaSparks = this.pentaSparks.filter(s => s !== spark); 
                } 
            }, 150); 
        } 

        const speed = this.projectileSpeed * deltaTime; 
         
        this.activeArcs = this.activeArcs.filter(arc => { 
            arc.sphere1.position.addInPlace(arc.sphere1.direction.scale(speed)); 
            arc.sphere2.position.addInPlace(arc.sphere2.direction.scale(speed)); 

            BABYLON.MeshBuilder.CreateTube(null, { path: [arc.sphere1.position, arc.sphere2.position], instance: arc.tube }); 
             
            if (now - arc.lastFractalTime > 150) { 
                arc.lastFractalTime = now; 
                const start = arc.sphere1.getAbsolutePosition(); 
                const end = arc.sphere2.getAbsolutePosition(); 
                const distance = BABYLON.Vector3.Distance(start, end); 
                const fractalPath = generateFractalLightning(start, end, distance * 0.4, 0.5); 
                const fractalArc = BABYLON.MeshBuilder.CreateTube("fractalArc", {path: fractalPath, radius: 0.04}, this.scene); 
                fractalArc.material = this.fractalMaterial; 
                if (this.glowLayer) this.glowLayer.addIncludedOnlyMesh(fractalArc); 
                 
                setTimeout(() => { 
                    if (fractalArc && !fractalArc.isDisposed()) { 
                       if (this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(fractalArc); 
                       fractalArc.dispose(); 
                    } 
                }, 120); 
            } 
             
            const distToCenter = BABYLON.Vector3.Distance(arc.sphere1.position, this.pentaTile.position); 
            if (distToCenter > GAME_CONSTANTS.GRID_WIDTH * 2.5) { 
                if (this.glowLayer) { 
                    this.glowLayer.removeIncludedOnlyMesh(arc.sphere1); 
                    this.glowLayer.removeIncludedOnlyMesh(arc.sphere2); 
                    this.glowLayer.removeIncludedOnlyMesh(arc.tube); 
                } 
                arc.sphere1.dispose(); arc.sphere2.dispose(); arc.tube.dispose(); 
                return false; 
            } 
            return true; 
        }); 

        if (!this.spawnerInterval && this.activeArcs.length === 0) { 
            this.deactivate(); 
        } 
    } 

    deactivate() { 
        this.isActive = false; 
        this.pentaTile.material = this.pentaOriginalMaterial; 
        this.pentaSparks.forEach(spark => { 
            if(this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(spark); 
            spark.dispose(); 
        }); 
        this.pentaSparks = []; 
    } 

// EMWaveMechanic -> checkCollision() metodunu bununla değiştirin
checkCollision(playerMesh) {
    if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return;

    const playerPosition = playerMesh.getAbsolutePosition();
    const playerRadius = 1.0; // Oyuncunun yaklaşık yarıçapı

    for (const arc of this.activeArcs) {
        const sphere1Pos = arc.sphere1.getAbsolutePosition();
        const sphere2Pos = arc.sphere2.getAbsolutePosition();

        // Kürelerle çarpışma (mesafe bazlı)
        if (BABYLON.Vector3.Distance(playerPosition, sphere1Pos) < playerRadius + 1.0 || 
            BABYLON.Vector3.Distance(playerPosition, sphere2Pos) < playerRadius + 1.0) {
            this.gameManager.goldbergController.handleHazardHit();
            return; // Hasar bir kez verildi, fonksiyondan çık
        }

        // Tüp ile çarpışma (çizgiye en yakın nokta)
        const tubeLine = sphere2Pos.subtract(sphere1Pos);
        const tubeLength = tubeLine.length();
        const tubeDir = tubeLine.normalize();

        const sphere1ToPlayer = playerPosition.subtract(sphere1Pos);
        const dotProduct = BABYLON.Vector3.Dot(sphere1ToPlayer, tubeDir);

        // Eğer en yakın nokta tüp segmenti üzerindeyse
        if (dotProduct >= 0 && dotProduct <= tubeLength) {
            const closestPoint = sphere1Pos.add(tubeDir.scale(dotProduct));
            const distToTube = BABYLON.Vector3.Distance(playerPosition, closestPoint);

            if (distToTube < playerRadius + 0.5) { // 0.5 tüpün yaklaşık yarıçapı
                this.gameManager.goldbergController.handleHazardHit();
                return;
            }
        }
    }
}

    cleanup() { 
        clearInterval(this.mainInterval); 
        clearTimeout(this.activationTimeout); 
        clearInterval(this.spawnerInterval); 
        clearInterval(this.warningInterval); 
         
        this.activeArcs.forEach(arc => { 
            if (this.glowLayer) { 
                this.glowLayer.removeIncludedOnlyMesh(arc.sphere1); 
                this.glowLayer.removeIncludedOnlyMesh(arc.sphere2); 
                this.glowLayer.removeIncludedOnlyMesh(arc.tube); 
            } 
            arc.sphere1.dispose(); arc.sphere2.dispose(); arc.tube.dispose(); 
        }); 
        this.activeArcs = []; 
         
        this.deactivate(); 
    } 
}