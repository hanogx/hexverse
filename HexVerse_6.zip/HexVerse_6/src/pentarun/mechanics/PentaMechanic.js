export class PentaMechanic { 
        constructor(scene, pentaTileController, gameManager) { 
            this.scene = scene; 
            this.pentaTile = pentaTileController.mesh; 
            this.pentaTileController = pentaTileController; 
            this.gameManager = gameManager; 
            this.isActive = false; // Is the mechanic currently in its active phase (e.g., lasers firing)? 
            this.isWarmingUp = false; // Is the mechanic in a warning/buildup phase? 
        } 
        initialize() {} 
        trigger() {}
        update(deltaTime) {} 
        cleanup() {} 
        checkCollision(playerMesh) {} 
    }