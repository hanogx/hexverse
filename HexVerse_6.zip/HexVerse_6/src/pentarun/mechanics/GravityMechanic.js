export class GravityMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 

        this.forceMagnitude = 200; 
        this.forceDirection = 0; // 1 = Çekme, -1 = İtme 
         
        this.particleSystem = null; 

        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['gravity_green']; 

        // Zamanlayıcılar 
        this.mainInterval = null; 
        this.warningTimeout = null; 
        this.warningInterval = null; 
        this.activationTimeout = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 14000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
        this.forceDirection = (Math.random() < 0.5) ? 1 : -1; 

        let isPulsed = false; 
        this.warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 3000); 
    } 

    activate() { 
        this.isActive = true; 
        this.pentaTile.material = this.pentaPulseMaterial; 

        // Parçacık sistemini oluştur 
        this.particleSystem = new BABYLON.ParticleSystem("gravityParticles", 4000, this.scene); 
        this.particleSystem.particleTexture = new BABYLON.Texture("https://playground.babylonjs.com/textures/flare.png", this.scene); 
         
        // Yerçekimini sıfırla, böylece biz kontrol ederiz 
        this.particleSystem.gravity = new BABYLON.Vector3(0, 0, 0); 

        // Parçacıkları tüm alana yayan KUTU yayıcı 
        const gridSize = GAME_CONSTANTS.GRID_WIDTH * 1.8; 
        this.particleSystem.particleEmitterType = new BABYLON.BoxParticleEmitter(); 
        this.particleSystem.minEmitBox = new BABYLON.Vector3(-gridSize, 1.2, -gridSize); 
        this.particleSystem.maxEmitBox = new BABYLON.Vector3(gridSize, 1.2, gridSize); 
         
        this.particleSystem.emitter = BABYLON.Vector3.Zero(); // Merkezden yayılsın 
         
        // Başlangıçta hareketleri yok 
        this.particleSystem.direction1 = new BABYLON.Vector3(0, 0, 0); 
        this.particleSystem.direction2 = new BABYLON.Vector3(0, 0, 0); 
        this.particleSystem.minEmitPower = 0; 
        this.particleSystem.maxEmitPower = 0; 
         
        this.particleSystem.color1 = new BABYLON.Color4(0.2, 1.0, 0.3, 1.0); 
        this.particleSystem.color2 = new BABYLON.Color4(0.5, 1.0, 0.6, 1.0); 
        this.particleSystem.colorDead = new BABYLON.Color4(0.1, 0.3, 0.1, 0.0); 
        this.particleSystem.minSize = 0.15; 
        this.particleSystem.maxSize = 0.45; 
        this.particleSystem.minLifeTime = 1.0; 
        this.particleSystem.maxLifeTime = 2.5; 
        this.particleSystem.emitRate = 1000; 
        this.particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
         
        // Güvenilir temizlik için 
        this.particleSystem.targetStopDuration = 1; 
        this.particleSystem.disposeOnStop = true; 

        this.particleSystem.start(); 
         
        // 6 saniye sonra mekaniği durdur 
        this.activationTimeout = setTimeout(() => this.deactivate(), 6000); 
    } 

    // EKSİK OLAN VE TÜM SORUNU ÇÖZECEK METOT 
    update(deltaTime) { 
        // Önce oyuncuya kuvvet uygula 
        if (this.isActive) { 
            const playerImpostor = this.gameManager.goldbergController.currentGoldberg.physicsImpostor; 
            if (playerImpostor) { 
                const playerPos = this.gameManager.goldbergController.currentGoldberg.getAbsolutePosition(); 
                const forceVector = this.pentaTile.position.subtract(playerPos); 
                forceVector.y = 0;  
                forceVector.normalize(); 
                 
                const forceToApply = forceVector.scale(this.forceMagnitude * this.forceDirection); 
                playerImpostor.applyForce(forceToApply, playerPos); 
            } 
        } 

        // Sonra parçacıkları hareket ettir 
        if (this.isActive && this.particleSystem && this.particleSystem.particles) { 
            const particleSpeed = 4.0 * deltaTime; // Hızı deltaTime ile oranla 
            const center = this.pentaTile.position; 

            for (let particle of this.particleSystem.particles) { 
                let direction; 
                if (this.forceDirection === 1) { // ÇEKME 
                    direction = center.subtract(particle.position); 
                } else { // İTME 
                    direction = particle.position.subtract(center); 
                } 
                direction.y = 0; // Hareketi yatay tut 
                 
                // Parçacığın pozisyonunu doğrudan güncelle 
                particle.position.addInPlace(direction.normalize().scale(particleSpeed)); 
            } 
        } 
    } 

    deactivate() { 
        this.isActive = false; 
        this.pentaTile.material = this.pentaOriginalMaterial; 

        if (this.particleSystem) { 
            this.particleSystem.stop(); // Sistemi durdur, disposeOnStop=true olduğu için kendi kendini imha edecek. 
            this.particleSystem = null; 
        } 
    } 

    cleanup() { 
        clearInterval(this.mainInterval); 
        clearTimeout(this.activationTimeout); 
        clearInterval(this.warningInterval); // Her ihtimale karşı 
        this.deactivate(); 
    } 
}