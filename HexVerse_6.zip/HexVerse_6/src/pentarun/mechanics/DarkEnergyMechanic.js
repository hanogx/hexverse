export class DarkEnergyMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 

        // DEĞİŞİKLİK: Artık tek bir nesne yerine bir dizi tutuyoruz. 
        this.activeBlackHoles = [];  
        this.allPlayableHexes = this.scene.getTransformNodeByName("ground").getChildMeshes().filter(m => m.isPlayable); 

        this.HEXES_TO_ABSORB = 10; 

        // Materyaller (değişiklik yok) 
        this.blackHoleMat = new BABYLON.StandardMaterial("bhMat", scene); 
        this.blackHoleMat.diffuseColor = new BABYLON.Color3(0, 0, 0); 
        this.blackHoleMat.emissiveColor = new BABYLON.Color3(0.05, 0, 0.1); 
        this.blackHoleMat.specularColor = new BABYLON.Color3(0,0,0); 

        const purpleColor = this.scene.metadata.hexColors['dark_purple'].emissiveColor; 
        this.fragmentMat = new BABYLON.StandardMaterial("fragmentMat", scene); 
        this.fragmentMat.emissiveColor = purpleColor.scale(2.0); 
        this.fragmentMat.diffuseColor = purpleColor; 
         
        this.fractalMatPurple = new BABYLON.StandardMaterial("fractalMatPurple", scene); 
        this.fractalMatPurple.emissiveColor = purpleColor.scale(1.5); 
        this.fractalMatPurple.disableLighting = true; 
         
        this.fractalMatBlack = new BABYLON.StandardMaterial("fractalMatBlack", scene); 
        this.fractalMatBlack.emissiveColor = new BABYLON.Color3(0.05, 0, 0.1); 
        this.fractalMatBlack.disableLighting = true; 

        this.glowLayer = this.scene.getGlowLayerByName("glow"); 
        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['dark_purple']; 
         
        // Bu UI elemanlarını artık birer "şablon" olarak kullanacağız 
        this.timerUITemplate = document.getElementById('destabilize-timer'); 
        this.absorbCounterUITemplate = document.getElementById('absorb-counter'); 
         
        this.mainInterval = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            // OYUN DENGESİ İÇİN BİR LİMİT KOYALIM (örn: aynı anda en fazla 3 kara delik) 
            // Bu limiti kaldırmak istersen "&& this.activeBlackHoles.length < 3" kısmını silebilirsin. 
            if (this.gameManager.state.isRunning && this.activeBlackHoles.length < 3) { 
                this.startWarning(); 
            } 
        }, 20000);  
    } 

    trigger() {
        if (this.gameManager.state.isRunning && this.activeBlackHoles.length < 3) {
            this.startWarning();
        }
    }

    startWarning() { 
        if (this.isWarmingUp) return; // Zaten bir uyarı varsa yenisini başlatma 
        this.isWarmingUp = true; 
        let isPulsed = false; 
        const warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        setTimeout(() => { 
            clearInterval(warningInterval); 
            this.pentaTile.material = this.pentaOriginalMaterial; 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) this.activate(); 
        }, 3000); 
    } 

activate() {
    const spawnMargin = 10;
    const maxDistSqr = Math.pow(GAME_CONSTANTS.GRID_WIDTH * 1.8 - spawnMargin, 2);
    
    const existingPositions = this.activeBlackHoles.map(bh => bh.core.position);
    const pentaTilePosition = this.pentaTileController.mesh.position;
    const pentaTileRadius = GAME_CONSTANTS.HEX_RADIUS * 5; // Penta tile radius
    const safeDistance = pentaTileRadius + 5; // Minimum safe distance from penta tile
    
    const potentialHexes = this.allPlayableHexes.filter(h => {
        if (!h.isEnabled() || h.getAbsolutePosition().lengthSquared() > maxDistSqr) return false;
        
        // Check distance from existing black holes
        for (const pos of existingPositions) {
            if (BABYLON.Vector3.Distance(h.getAbsolutePosition(), pos) < 10) return false;
        }
        
        // NEW: Check distance from penta tile
        const distToPenta = BABYLON.Vector3.Distance(h.getAbsolutePosition(), pentaTilePosition);
        if (distToPenta < safeDistance) return false;
        
        return true;
    });

    if (potentialHexes.length === 0) return;
    const hex = potentialHexes[Math.floor(Math.random() * potentialHexes.length)];
    if (hex) this.createBlackHoleOnHex(hex);
}
     
    createBlackHoleOnHex(hex) { 
        const startPos = this.pentaTile.position; 
        const endPos = hex.getAbsolutePosition().add(new BABYLON.Vector3(0, 0.5, 0));  

        const core = BABYLON.MeshBuilder.CreateCylinder("bhCore_" + this.activeBlackHoles.length, { diameter: GAME_CONSTANTS.HEX_RADIUS * 2 * 2, height: 0.2, tessellation: 6 }, this.scene); 
        core.position = startPos; 
        core.material = this.blackHoleMat; 
        this.glowLayer.addIncludedOnlyMesh(core); 

        // Klonlanmış UI elemanları oluştur 
        const timerUI = this.timerUITemplate.cloneNode(true); 
        const absorbUI = this.absorbCounterUITemplate.cloneNode(true); 
        document.body.appendChild(timerUI); 
        document.body.appendChild(absorbUI); 
        timerUI.style.top = `${60 + this.activeBlackHoles.length * 100}px`; 
        absorbUI.style.top = `${120 + this.activeBlackHoles.length * 100}px`; 

        const newBlackHole = { 
            id: Math.random(), 
            core: core, 
            fragments: [], 
            timer: 12.0,  
            isPermanent: false, 
            pullForce: 50, 
            lastSparkTime: 0, 
            hexesAbsorbed: 0, 
            ui: { timer: timerUI, absorb: absorbUI } 
        }; 
         
        this.activeBlackHoles.push(newBlackHole); 
        const travelAnim = new BABYLON.Animation("travel", "position", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        travelAnim.setKeys([{ frame: 0, value: startPos }, { frame: 45, value: endPos }]); 

        this.scene.beginDirectAnimation(core, [travelAnim], 0, 45, false, 1, () => { 
            const fragmentCount = 5; 
            const spawnRadius = 4.0; 
            for (let i = 0; i < fragmentCount; i++) { 
                const angle = (i / fragmentCount) * Math.PI * 2; 
                const fragment = BABYLON.MeshBuilder.CreatePolyhedron("voidFragment", {type: 3, size: 0.6}, this.scene); 
                fragment.position = core.position.add(new BABYLON.Vector3(spawnRadius * Math.cos(angle), 0, spawnRadius * Math.sin(angle))); 
                fragment.material = this.fragmentMat; 
                this.glowLayer.addIncludedOnlyMesh(fragment); 
                newBlackHole.fragments.push(fragment); 
            } 
            newBlackHole.ui.timer.style.display = 'flex'; 
        }); 
    } 

    feedBlackHole(blackHoleToFeed) { 
        if (!blackHoleToFeed || !blackHoleToFeed.isPermanent) return; 
        blackHoleToFeed.hexesAbsorbed++; 
        const remaining = this.HEXES_TO_ABSORB - blackHoleToFeed.hexesAbsorbed; 
    blackHoleToFeed.ui.absorb.querySelector('span:last-child').textContent = remaining; 

    if (blackHoleToFeed.hexesAbsorbed >= this.HEXES_TO_ABSORB) {  
        this.closeBlackHole(blackHoleToFeed, true); 
    } 
    } 
     
    closeBlackHole(bh, success) { 
        bh.ui.timer.remove(); 
        bh.ui.absorb.remove(); 

        if(bh.fragments) bh.fragments.forEach(f => { 
            if(this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(f); 
            f.dispose(); 
        }); 
         
        if (bh.core) { 
            this.glowLayer.removeIncludedOnlyMesh(bh.core); 
            const scaleAnim = new BABYLON.Animation("implode", "scaling", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
            scaleAnim.setKeys([{ frame: 0, value: bh.core.scaling }, { frame: 15, value: BABYLON.Vector3.Zero() }]); 
            this.scene.beginDirectAnimation(bh.core, [scaleAnim], 0, 15, false, 1, () => bh.core.dispose()); 
        } 
         
        this.activeBlackHoles = this.activeBlackHoles.filter(item => item.id !== bh.id); 
    } 
     
    transformToPermanent(bh) { 
        bh.isPermanent = true; 
        bh.ui.timer.style.display = 'none'; 
        bh.ui.absorb.style.display = 'flex'; 
        bh.ui.absorb.querySelector('span:last-child').textContent = `${this.HEXES_TO_ABSORB - bh.hexesAbsorbed}`; 
         
        const scaleAnim = new BABYLON.Animation("grow", "scaling", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        scaleAnim.setKeys([{ frame: 0, value: bh.core.scaling }, { frame: 60, value: new BABYLON.Vector3(2, 1, 2) }]); 
        this.scene.beginDirectAnimation(bh.core, [scaleAnim], 0, 60, false); 
         
        bh.fragments.forEach(frag => { this.glowLayer.removeIncludedOnlyMesh(frag); frag.dispose(); }); 
        bh.fragments = []; 
    } 

  update(deltaTime) { 
    if (this.activeBlackHoles.length === 0) return; 
    const player = this.gameManager.goldbergController.currentGoldberg; 
    if (!player || player.isDisposed()) return; 
    const playerPos = player.getAbsolutePosition(); 
     
    this.activeBlackHoles.forEach(bh => { 
        // Eğer kara delik kalıcı hale gelmişse: 
        if (bh.isPermanent) { 
            // 1. GERÇEK 3B MESAFE HESAPLAMASI 
            // Oyuncunun pozisyonu ile kara deliğin merkezi arasındaki gerçek 3 boyutlu vektör. 
            // .y bileşenini artık SIFIRLAMIYORUZ. 
            const pullVector3D = bh.core.position.subtract(playerPos); 
            const distance3D = pullVector3D.length(); 

            // 2. DİNAMİK OLAY UFKU YARIÇAPI 
            // Kara delik büyüdükçe ölümcül alanın da büyümesini sağlıyoruz. 
            // Bu, oynanışı görsellikle uyumlu hale getirir. 
            const baseEventHorizonRadius = 1.5; // Temel yarıçap 
            const eventHorizonRadius = baseEventHorizonRadius * bh.core.scaling.x; // Ölçekle çarp 

            // 3. ÇEKİM KUVVETİ (Hala yatay düzlemde daha iyi çalışır) 
            const pullVectorHorizontal = pullVector3D.clone(); 
            pullVectorHorizontal.y = 0; 
            if (pullVectorHorizontal.length() < 8) { 
                player.physicsImpostor.applyForce(pullVectorHorizontal.normalize().scale(bh.pullForce), playerPos); 
            } 

            // 4. YUTULMA (KAYBETME) KOŞULU 
            // Artık gerçek 3 boyutlu mesafeyi dinamik olay ufkuna göre kontrol ediyoruz. 
            if (distance3D < eventHorizonRadius) { 
                this.gameManager.endGame(false, "dark_energy"); 
            } 
         
        // Eğer kara delik henüz kalıcı değilse (bu kısım aynı kalıyor): 
        } else { 
             if(bh.fragments.length > 0){ 
                bh.timer -= deltaTime; 
                const timerSpan = bh.ui.timer.querySelector('span:last-of-type'); 
                if(timerSpan) timerSpan.textContent = bh.timer.toFixed(1) + 's'; 

                for (let j = bh.fragments.length - 1; j >= 0; j--) { 
                    const fragment = bh.fragments[j]; 
                    if (BABYLON.Vector3.Distance(playerPos, fragment.position) < 2.0) { 
                        this.collectFragment(fragment, bh.core); 
                        bh.fragments.splice(j, 1); 
                    } 
                } 

                if (bh.fragments.length === 0) { 
                    this.closeBlackHole(bh, true); 
                } else if (bh.timer <= 0) { 
                    this.transformToPermanent(bh); 
                } 
            } 
        } 
    }); 
} 

    cleanup() { 
        clearInterval(this.mainInterval); 
        this.activeBlackHoles.forEach(bh => { 
            if(bh.core) bh.core.dispose(); 
            if(bh.fragments) bh.fragments.forEach(f => f.dispose()); 
            bh.ui.timer.remove(); 
            bh.ui.absorb.remove(); 
        }); 
        this.activeBlackHoles = []; 
    } 

    collectFragment(fragment, core) { 
        this.glowLayer.removeIncludedOnlyMesh(fragment); 
        const anim = new BABYLON.Animation("fragAnim", "position", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        anim.setKeys([{ frame: 0, value: fragment.position }, { frame: 15, value: core.position.clone() }]); 
        this.scene.beginDirectAnimation(fragment, [anim], 0, 15, false, 1, () => fragment.dispose()); 
    } 

    checkCollision(playerMesh) {} 
}