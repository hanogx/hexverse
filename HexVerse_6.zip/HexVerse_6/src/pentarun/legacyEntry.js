import { SaveStore } from '../shared/SaveStore.js';


window.addEventListener("DOMContentLoaded", function() {
    try {
        const savedData = JSON.parse(localStorage.getItem('planetData'));
        if (savedData) {
            console.log('Kaydedilmiş veri yüklendi:', savedData);
            window.__planetLevel = savedData.planetLevel;
            window.__hexData = savedData.hexData;
            // Diğer verileri de buraya yükleyebilirsiniz.
        }
    } catch (e) {
        console.error("LocalStorage veri okuma hatası:", e);
    }
    // --- GLOBAL VARIABLES --- 
    let canvas, engine, scene, gameManager; 

    // --- GAME CONSTANTS --- 
    const GAME_CONSTANTS = { 
        HEX_RADIUS: 1, 
        GRID_WIDTH: 15, 
        SPACING_FACTOR: 1.2, 
        PLAYER_START_POS: new BABYLON.Vector3(-15, 10, 0), 
        PLAYER_FALL_LIMIT: -20, 
        CAMERA_X_OFFSET: -30, 
        CAMERA_Y_POSITION: 50, 
        CAMERA_Z_OFFSET: 0, 
        GRID_INFLUENCE_RADIUS: 4, 
        GRID_INFLUENCE_MAX_DEPTH: 0.8, 
        GRID_INFLUENCE_DAMPING: 0.1, 
        JOYSTICK_SIZE: 120, 
        PHYSICS_GRAVITY: new BABYLON.Vector3(0, -9.81, 0), 
        HITS_TO_WIN: 100, 
        LASER_ROTATION_SPEED: Math.PI / 8, 
        LASER_SPAWN_INTERVAL: 15000, 
        LASER_WARNING_DURATION: 3000, 
        UNSTABLE_DEBUFF_DURATION: 20000, 
        INVINCIBILITY_DURATION: 2000, 
        LASER_LENGTH: 25 
    }; 

Array.prototype.randomIndex = function() { 
        return this.length > 0 ? Math.floor(Math.random() * this.length) : -1; 
    }; 

    function setDisplayMode(mode) {
  const b = document.body;
  if (!b) return;
  b.classList.toggle('mode-select', mode === 'select');
  b.classList.toggle('mode-game',   mode === 'game');
}
// --- STAGE CONFIGURATION ---
const STAGE_CONFIG = {
    // Tekli Mekanik Aşamaları (Mevcut haliyle kalıyor)
    1:  { title: "Stage 1", mechanics: ['laser'], description: "Buz Lazerler" },
    2:  { title: "Stage 2", mechanics: ['solar'], description: "Solar Ateş" },
    3:  { title: "Stage 3", mechanics: ['em_wave'], description: "EM Dalgalar" },
    4:  { title: "Stage 4", mechanics: ['gravity'], description: "Gravitasyon İtişi" },
    5:  { title: "Stage 5", mechanics: ['dark_energy'], description: "Kara Delikler" },

    // --- YENİ: Temaları Eklenmiş Çoklu Mekanik Aşamaları ---
    6:  { 
        title: "Stage 6", 
        mechanics: ['laser', 'solar'], 
        description: "Giriş Seviyesi Kombinasyon (Buz ve Ateş)" 
    },
    7:  { 
        title: "Stage 7", 
        mechanics: ['gravity', 'em_wave'], 
        description: "Hareket Kontrolü Testi" 
    },
    8:  { 
        title: "Stage 8", 
        mechanics: ['laser', 'dark_energy'], 
        description: "Çoklu Görev Testi (Multitasking)" 
    },
    9:  { 
        title: "Stage 9", 
        mechanics: ['laser', 'solar', 'em_wave'], 
        description: "Alan Hakimiyeti Zirvesi" 
    },
    10: { 
        title: "Stage 10", 
        mechanics: ['gravity', 'solar', 'dark_energy'], 
        description: "Sinerjik Kaos" 
    },
    11: { 
        title: "Stage 11", 
        mechanics: ['laser', 'solar', 'em_wave', 'dark_energy'], 
        description: "Zihinsel Yük Testi" 
    },
    12: { 
        title: "Stage 12", 
        mechanics: ['gravity', 'laser', 'em_wave', 'dark_energy'], 
        description: "Nihai Meydan Okuma" 
    },
    13: {
        title: "CORE STAGE",
        mechanics: ['laser', 'solar', 'em_wave', 'gravity', 'dark_energy'],
        description: "Sonsuz Mod: Gezegenin Çekirdeği"
    }
}
// --- REQUIREMENTS (geçici; tablo gelince güncellenecek) ---
const STAGE_REQUIREMENTS = {
  1:{ level:1, energy:1, relic:0 },
  2:{ level:1, energy:1, relic:1 },
  3:{ level:2, energy:1, relic:1 },
  4:{ level:2, energy:2, relic:2 },
  5:{ level:3, energy:2, relic:2 },
  6:{ level:3, energy:2, relic:3 },
  7:{ level:4, energy:3, relic:3 },
  8:{ level:4, energy:3, relic:4 },
  9:{ level:5, energy:3, relic:4 },
  10:{ level:5, energy:4, relic:5 },
  11:{ level:5, energy:4, relic:5 },
  12:{ level:6, energy:4, relic:6 },
  // 13 core bu ekranda listelenmez
};
;


function generateFractalLightning(start, end, disp, detail) { 
  const points = []; 
  function subdivide(p1, p2, currentDisp) { 
    if (currentDisp < detail) { 
      points.push(p1, p2); 
    } else { 
      const mid = p1.add(p2).scale(0.5); 
      const dir  = p2.subtract(p1).normalize(); 
      // Yön vektörüne dik bir vektör bulalım (Y ekseni etrafında 90 derece döndürerek) 
      const perp = new BABYLON.Vector3(-dir.z, 0, dir.x); 
      const offset = (Math.random() - 0.5) * currentDisp; 
      mid.addInPlace(perp.scale(offset)); 
       
      subdivide(p1, mid, currentDisp / 2); 
      subdivide(mid, p2, currentDisp / 2); 
    } 
  } 
  subdivide(start, end, disp); 
  return points; 
} 
    // --- PENTA MECHANICS --- 
    class PentaMechanic { 
        constructor(scene, pentaTileController, gameManager) { 
            this.scene = scene; 
            this.pentaTile = pentaTileController.mesh; 
            this.pentaTileController = pentaTileController; 
            this.gameManager = gameManager; 
            this.isActive = false; // Is the mechanic currently in its active phase (e.g., lasers firing)? 
            this.isWarmingUp = false; // Is the mechanic in a warning/buildup phase? 
        } 
        initialize() {} 
        trigger() {}
        update(deltaTime) {} 
        cleanup() {} 
        checkCollision(playerMesh) {} 
    } 

    class LaserMechanic extends PentaMechanic { 
        constructor(scene, pentaTileController, gameManager) { 
            super(scene, pentaTileController, gameManager); 
            this.lasersNode = scene.getTransformNodeByName("lasersContainer"); 
            this.originalPentaMat = this.pentaTileController.originalMaterial; 
            this.warningMat = scene.getMaterialByName("iceBlueMat"); 
            this.laserMat = scene.getMaterialByName("laserMat"); 
            this.rotationSpeed = 0; 
            this.warningInterval = null; 
            this.activationTimeout = null; 
            this.mainInterval = null; 
        } 

        initialize() { 
            this.cleanup(); // Önceki kalıntıları temizle 
            this.mainInterval = setInterval(() => { 
                if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                    this.startWarning(); 
                } 
            }, GAME_CONSTANTS.LASER_SPAWN_INTERVAL); 
        } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }
        startWarning() { 
            this.isWarmingUp = true; 
            this.gameManager.setCoreWarning(true); 
            let isBlue = false; 
            this.warningInterval = setInterval(() => { 
                isBlue = !isBlue; 
                this.pentaTile.material = isBlue ? this.warningMat : this.originalPentaMat; 
            }, 400); 
             
            if (this.laserMat) this.laserMat.emissiveColor = new BABYLON.Color3(0.2, 0.4, 0.6); 
            this.lasersNode.setEnabled(true); 

            this.activationTimeout = setTimeout(() => { 
                clearInterval(this.warningInterval); 
                this.warningInterval = null; 
                this.isWarmingUp = false; 
                this.gameManager.setCoreWarning(false); 
                if (this.gameManager.state.isRunning) { 
                    this.activate(); 
                } 
            }, GAME_CONSTANTS.LASER_WARNING_DURATION); 
        } 

        activate() { 
            this.isActive = true; 
            this.pentaTile.material = this.warningMat; 
            if (this.laserMat) this.laserMat.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0); 
            const direction = Math.random() < 0.5 ? 1 : -1; 
            this.rotationSpeed = GAME_CONSTANTS.LASER_ROTATION_SPEED * direction; 
             
            this.activationTimeout = setTimeout(() => this.deactivate(), 5000); 
        } 

        deactivate() { 
            this.pentaTile.material = this.originalPentaMat; 
            this.lasersNode.setEnabled(false); 
            this.rotationSpeed = 0; 
            this.isActive = false; 
        } 

        update(deltaTime) { 
            if (this.rotationSpeed !== 0) { 
                this.lasersNode.rotation.y += this.rotationSpeed * deltaTime; 
            } 
        } 

        checkCollision(playerMesh) { 
            if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return; 
             
            const laserArms = this.lasersNode.getChildren(); 
            for (const arm of laserArms) { 
                const laser = arm.getChildMeshes(false)[0]; 
                if (laser && playerMesh.intersectsMesh(laser, true)) { 
                    this.gameManager.goldbergController.handleHazardHit(); 
                    break; 
                } 
            } 
        } 

        cleanup() { 
            clearInterval(this.mainInterval); 
            clearInterval(this.warningInterval); 
            clearTimeout(this.activationTimeout); 
            this.deactivate(); 
        } 
    } 

    // PENTA MECHANICS bölümünde, LaserMechanic'ten sonra 
class SolarMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 
         
        this.coneBaseDirections = []; 
        const pentaVertices = this.pentaTile.getVerticesData(BABYLON.VertexBuffer.PositionKind); 
        if (pentaVertices) { 
            for(let i = 0; i < 5; i++) { 
                const vec = new BABYLON.Vector3(pentaVertices[i*3], 0, pentaVertices[i*3+2]).normalize(); 
                this.coneBaseDirections.push(vec); 
            } 
        } 

        this.coneAngle = Math.PI / 3;  

        this.warningMat = this.scene.getMaterialByName("solarWarningMat"); 
        this.defaultWarningAlpha = this.warningMat.alpha; // Orijinal alpha değerini sakla 
        this.playableHexMat = this.scene.getMaterialByName("playableHexMat"); 

        this.activeConeDirections = [];  
        this.targetedHexes = []; 
        this.activeParticleSystems = []; 

        this.mainInterval = null; 
        this.warningInterval = null; 
        this.activationTimeout = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 12000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
         
        this.targetedHexes = []; 
        this.activeConeDirections = []; 

        const minAngleBetween = Math.PI / 3; 
        let availableDirections = [...this.coneBaseDirections]; 
         
        while (this.activeConeDirections.length < 3 && availableDirections.length > 0) { 
            const randomIndex = Math.floor(Math.random() * availableDirections.length); 
            const candidateDirection = availableDirections.splice(randomIndex, 1)[0]; 
             
            let isFarEnough = true; 
            for (const selectedDir of this.activeConeDirections) { 
                const angle = Math.acos(BABYLON.Vector3.Dot(selectedDir, candidateDirection)); 
                if (angle < minAngleBetween) { 
                    isFarEnough = false; 
                    break; 
                } 
            } 

            if (isFarEnough) { 
                this.activeConeDirections.push(candidateDirection); 
            } 
        } 

        const ground = this.scene.getTransformNodeByName("ground"); 
        const allPlayableHexes = ground.getChildMeshes().filter(m => m.isPlayable); 
         
        this.activeConeDirections.forEach(direction => { 
            allPlayableHexes.forEach(hex => { 
                if (!this.targetedHexes.includes(hex)) { 
                    const hexPos = hex.getAbsolutePosition().normalize(); 
                    const dotProduct = BABYLON.Vector3.Dot(hexPos, direction); 
                    if (dotProduct > Math.cos(this.coneAngle / 2)) { 
                        this.targetedHexes.push(hex); 
                    } 
                } 
            }); 
        }); 

        // --- YENİ: Pulse Efekti Mantığı --- 
        // Önce tüm hedeflere uyarı materyalini ata 
        this.targetedHexes.forEach(hex => { 
            if(hex && !hex.isDisposed()) hex.material = this.warningMat; 
        }); 

        // Sonra bu materyalin alpha değerini periyodik olarak değiştir 
        let pulseDirection = 1; // 1: artan, -1: azalan 
        this.warningInterval = setInterval(() => { 
            let currentAlpha = this.warningMat.alpha; 
            currentAlpha += 0.03 * pulseDirection; // Pulse hızı 

            if (currentAlpha > 0.7) { 
                currentAlpha = 0.7; 
                pulseDirection = -1; 
            } else if (currentAlpha < 0.2) { 
                currentAlpha = 0.2; 
                pulseDirection = 1; 
            } 
            this.warningMat.alpha = currentAlpha; 
        }, 50); // 50ms aralıklarla güncelleyerek akıcı bir efekt sağla 
        // --- Pulse Efekti Sonu --- 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); // Pulse interval'ini durdur 
            this.warningMat.alpha = this.defaultWarningAlpha; // Materyalin alpha'sını orijinal haline getir 

            this.isWarmingUp = false; 
            this.targetedHexes.forEach(hex => { 
                if(hex && !hex.isDisposed()) hex.material = this.playableHexMat; 
            }); 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 3000); 
    } 

    activate() { 
        this.isActive = true; 

        this.targetedHexes.forEach(hex => { 
            if (!hex || hex.isDisposed()) return; 
            const fireEffect = new BABYLON.ParticleSystem("tileFire_" + hex.uniqueId, 500, this.scene); 
            fireEffect.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene); 
            fireEffect.emitter = hex; 
            fireEffect.minEmitBox = new BABYLON.Vector3(-0.5, 0.1, -0.5); 
            fireEffect.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5); 
            fireEffect.color1 = new BABYLON.Color4(1.0, 0.5, 0, 1.0); 
            fireEffect.color2 = new BABYLON.Color4(1.0, 0.2, 0, 1.0); 
            fireEffect.colorDead = new BABYLON.Color4(0.2, 0, 0, 0.0); 
            fireEffect.minSize = 0.2; 
            fireEffect.maxSize = 0.6; 
            fireEffect.minLifeTime = 0.5; 
            fireEffect.maxLifeTime = 1.2; 
            fireEffect.emitRate = 150; 
            fireEffect.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
            fireEffect.gravity = new BABYLON.Vector3(0, 5, 0); 
            fireEffect.direction1 = new BABYLON.Vector3(-0.5, 1, -0.5); 
            fireEffect.direction2 = new BABYLON.Vector3(0.5, 1, 0.5); 
            fireEffect.minAngularSpeed = 0; 
            fireEffect.maxAngularSpeed = Math.PI; 
            fireEffect.minEmitPower = 0.5; 
            fireEffect.maxEmitPower = 1.5; 
            fireEffect.updateSpeed = 0.008; 
            fireEffect.start(); 
            this.activeParticleSystems.push(fireEffect); 
        }); 

        this.activationTimeout = setTimeout(() => this.deactivate(), 4000); 
    } 

    deactivate() { 
        this.isActive = false; 

        // GÜNCELLEME: Temizlik yaparken materyalin alpha'sını da sıfırla 
        this.warningMat.alpha = this.defaultWarningAlpha; 

        this.activeParticleSystems.forEach(ps => { 
            ps.stop(); 
            ps.dispose(); 
        }); 
        this.activeParticleSystems = []; 

        this.targetedHexes = []; 
        this.activeConeDirections = []; 
    } 

    checkCollision(playerMesh) { 
        if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return; 
         
        let hasBeenHit = false; 
        for (const hex of this.targetedHexes) { 
            if (hex && !hex.isDisposed()) { 
                const distance = BABYLON.Vector3.Distance(playerMesh.getAbsolutePosition(), hex.getAbsolutePosition()); 
                if (distance < GAME_CONSTANTS.HEX_RADIUS * 1.5) { 
                    hasBeenHit = true; 
                    break;  
                } 
            } 
        } 

        if(hasBeenHit) { 
            this.gameManager.goldbergController.handleHazardHit(); 
        } 
    } 

    cleanup() { 
        // GÜNCELLEME: Tüm zamanlayıcıları ve efektleri temizlerken materyali de sıfırla 
        clearInterval(this.mainInterval); 
        clearInterval(this.warningInterval); // Pulse interval'ini de durdurduğumuzdan emin olalım 
        clearTimeout(this.activationTimeout); 
         
        this.targetedHexes.forEach(hex => { 
            if(hex && !hex.isDisposed() && hex.material === this.warningMat) { 
                hex.material = this.playableHexMat; 
            } 
        }); 

        this.deactivate(); 
    } 
} 


class EMWaveMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 
         
        // Ana arkların ve kürelerin materyali 
        this.arcMaterial = new BABYLON.StandardMaterial("emArcMat", scene); 
        this.arcMaterial.emissiveColor = this.scene.metadata.hexColors['em_blue'].emissiveColor.scale(1.8); 
        this.arcMaterial.disableLighting = true; 
         
        // Kılcal şimşeklerin materyali (daha ince ve parlak) 
        this.fractalMaterial = new BABYLON.StandardMaterial("emFractalMat", scene); 
        this.fractalMaterial.emissiveColor = new BABYLON.Color3(0.7, 0.8, 1.0).scale(1.5); 
        this.fractalMaterial.disableLighting = true; 

        this.glowLayer = this.scene.getGlowLayerByName("glow"); 
        this.arcsRoot = new BABYLON.TransformNode("arcsRoot", this.scene); 
         
        this.projectileSpeed = 4.0; 
        this.activeArcs = []; 

        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['em_blue']; 
         
        // Penta Tile üzerindeki şimşekler için 
        this.pentaVertices = this.pentaTile.getVerticesData(BABYLON.VertexBuffer.PositionKind); 
        this.pentaSparks = []; 
        this.lastPentaSparkTime = 0; 

        // Zamanlayıcılar 
        this.mainInterval = null; 
        this.warningTimeout = null; 
        this.warningInterval = null; 
        this.spawnerInterval = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 12000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
         
        let isPulsed = false; 
        this.warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); 
            this.warningInterval = null; 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 2500); 
    } 

    activate() { 
        this.isActive = true; 
        this.activeArcs = []; 
         
        // Saldırı boyunca Penta Tile'ı mavi yap 
        this.pentaTile.material = this.pentaPulseMaterial; 

        let setsSpawned = 0; 
        const totalSets = 4; 
         
        this.spawnerInterval = setInterval(() => { 
            if (setsSpawned >= totalSets) { 
                clearInterval(this.spawnerInterval); 
                this.spawnerInterval = null; 
                return; 
            } 
             
            const arcCount = 5; 
            const angleStep = (Math.PI * 2) / arcCount; 
            const arcWidthRadians = BABYLON.Tools.ToRadians(30); 
            const randomOffset = Math.random() * Math.PI * 2; 

            for (let i = 0; i < arcCount; i++) { 
                const centerAngle = i * angleStep + randomOffset; 
                const angle1 = centerAngle - (arcWidthRadians / 2); 
                const angle2 = centerAngle + (arcWidthRadians / 2); 
                const dir1 = new BABYLON.Vector3(Math.cos(angle1), 0, Math.sin(angle1)); 
                const dir2 = new BABYLON.Vector3(Math.cos(angle2), 0, Math.sin(angle2)); 

                const sphere1 = BABYLON.MeshBuilder.CreateSphere("emSphere", {diameter: 1.0}, this.scene); 
                sphere1.material = this.arcMaterial; 
                sphere1.position = this.pentaTile.position.clone(); 
                sphere1.direction = dir1; 
                 
                const sphere2 = sphere1.clone("emSphere2"); 
                sphere2.direction = dir2; 

                const tube = BABYLON.MeshBuilder.CreateTube("arcTube", { path: [sphere1.position, sphere2.position], radius: 0.1, updatable: true }, this.scene); 
                tube.material = this.arcMaterial; 

                sphere1.parent = this.arcsRoot; 
                sphere2.parent = this.arcsRoot; 
                tube.parent = this.arcsRoot; 
                 
                if (this.glowLayer) { 
                    this.glowLayer.addIncludedOnlyMesh(sphere1); 
                    this.glowLayer.addIncludedOnlyMesh(sphere2); 
                    this.glowLayer.addIncludedOnlyMesh(tube); 
                } 
                 
                this.activeArcs.push({ sphere1, sphere2, tube, lastFractalTime: 0 }); 
            } 
            setsSpawned++; 
        }, 1500); 
    } 

    update(deltaTime) { 
        if (!this.isActive && this.activeArcs.length === 0) return; 
         
        const now = performance.now(); 

        // YENİ: Penta Tile üzerinde şimşek efekti 
        if (this.isActive && now - this.lastPentaSparkTime > 200) { // Her 200ms'de bir 
            this.lastPentaSparkTime = now; 
            const vertexCount = this.pentaVertices.length / 3; 
            const i1 = Math.floor(Math.random() * vertexCount); 
            const i2 = Math.floor(Math.random() * vertexCount); 
             
            const p1_local = new BABYLON.Vector3(this.pentaVertices[i1*3], this.pentaVertices[i1*3+1], this.pentaVertices[i1*3+2]); 
            const p2_local = new BABYLON.Vector3(this.pentaVertices[i2*3], this.pentaVertices[i2*3+1], this.pentaVertices[i2*3+2]); 

            const p1_world = BABYLON.Vector3.TransformCoordinates(p1_local, this.pentaTile.getWorldMatrix()); 
            const p2_world = BABYLON.Vector3.TransformCoordinates(p2_local, this.pentaTile.getWorldMatrix()); 
             
            const fractalPath = generateFractalLightning(p1_world, p2_world, 1.5, 0.3); 
            const spark = BABYLON.MeshBuilder.CreateTube("pentaSpark", {path: fractalPath, radius: 0.03}, this.scene); 
            spark.material = this.fractalMaterial; 
            if (this.glowLayer) this.glowLayer.addIncludedOnlyMesh(spark); 
            this.pentaSparks.push(spark); 

            setTimeout(() => { 
                if (spark && !spark.isDisposed()){ 
                    if (this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(spark); 
                    spark.dispose(); 
                    this.pentaSparks = this.pentaSparks.filter(s => s !== spark); 
                } 
            }, 150); 
        } 

        const speed = this.projectileSpeed * deltaTime; 
         
        this.activeArcs = this.activeArcs.filter(arc => { 
            arc.sphere1.position.addInPlace(arc.sphere1.direction.scale(speed)); 
            arc.sphere2.position.addInPlace(arc.sphere2.direction.scale(speed)); 

            BABYLON.MeshBuilder.CreateTube(null, { path: [arc.sphere1.position, arc.sphere2.position], instance: arc.tube }); 
             
            if (now - arc.lastFractalTime > 150) { 
                arc.lastFractalTime = now; 
                const start = arc.sphere1.getAbsolutePosition(); 
                const end = arc.sphere2.getAbsolutePosition(); 
                const distance = BABYLON.Vector3.Distance(start, end); 
                const fractalPath = generateFractalLightning(start, end, distance * 0.4, 0.5); 
                const fractalArc = BABYLON.MeshBuilder.CreateTube("fractalArc", {path: fractalPath, radius: 0.04}, this.scene); 
                fractalArc.material = this.fractalMaterial; 
                if (this.glowLayer) this.glowLayer.addIncludedOnlyMesh(fractalArc); 
                 
                setTimeout(() => { 
                    if (fractalArc && !fractalArc.isDisposed()) { 
                       if (this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(fractalArc); 
                       fractalArc.dispose(); 
                    } 
                }, 120); 
            } 
             
            const distToCenter = BABYLON.Vector3.Distance(arc.sphere1.position, this.pentaTile.position); 
            if (distToCenter > GAME_CONSTANTS.GRID_WIDTH * 2.5) { 
                if (this.glowLayer) { 
                    this.glowLayer.removeIncludedOnlyMesh(arc.sphere1); 
                    this.glowLayer.removeIncludedOnlyMesh(arc.sphere2); 
                    this.glowLayer.removeIncludedOnlyMesh(arc.tube); 
                } 
                arc.sphere1.dispose(); arc.sphere2.dispose(); arc.tube.dispose(); 
                return false; 
            } 
            return true; 
        }); 

        if (!this.spawnerInterval && this.activeArcs.length === 0) { 
            this.deactivate(); 
        } 
    } 

    deactivate() { 
        this.isActive = false; 
        this.pentaTile.material = this.pentaOriginalMaterial; 
        this.pentaSparks.forEach(spark => { 
            if(this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(spark); 
            spark.dispose(); 
        }); 
        this.pentaSparks = []; 
    } 

// EMWaveMechanic -> checkCollision() metodunu bununla değiştirin
checkCollision(playerMesh) {
    if (!this.isActive || !playerMesh || playerMesh.isDisposed()) return;

    const playerPosition = playerMesh.getAbsolutePosition();
    const playerRadius = 1.0; // Oyuncunun yaklaşık yarıçapı

    for (const arc of this.activeArcs) {
        const sphere1Pos = arc.sphere1.getAbsolutePosition();
        const sphere2Pos = arc.sphere2.getAbsolutePosition();

        // Kürelerle çarpışma (mesafe bazlı)
        if (BABYLON.Vector3.Distance(playerPosition, sphere1Pos) < playerRadius + 1.0 || 
            BABYLON.Vector3.Distance(playerPosition, sphere2Pos) < playerRadius + 1.0) {
            this.gameManager.goldbergController.handleHazardHit();
            return; // Hasar bir kez verildi, fonksiyondan çık
        }

        // Tüp ile çarpışma (çizgiye en yakın nokta)
        const tubeLine = sphere2Pos.subtract(sphere1Pos);
        const tubeLength = tubeLine.length();
        const tubeDir = tubeLine.normalize();

        const sphere1ToPlayer = playerPosition.subtract(sphere1Pos);
        const dotProduct = BABYLON.Vector3.Dot(sphere1ToPlayer, tubeDir);

        // Eğer en yakın nokta tüp segmenti üzerindeyse
        if (dotProduct >= 0 && dotProduct <= tubeLength) {
            const closestPoint = sphere1Pos.add(tubeDir.scale(dotProduct));
            const distToTube = BABYLON.Vector3.Distance(playerPosition, closestPoint);

            if (distToTube < playerRadius + 0.5) { // 0.5 tüpün yaklaşık yarıçapı
                this.gameManager.goldbergController.handleHazardHit();
                return;
            }
        }
    }
}

    cleanup() { 
        clearInterval(this.mainInterval); 
        clearTimeout(this.activationTimeout); 
        clearInterval(this.spawnerInterval); 
        clearInterval(this.warningInterval); 
         
        this.activeArcs.forEach(arc => { 
            if (this.glowLayer) { 
                this.glowLayer.removeIncludedOnlyMesh(arc.sphere1); 
                this.glowLayer.removeIncludedOnlyMesh(arc.sphere2); 
                this.glowLayer.removeIncludedOnlyMesh(arc.tube); 
            } 
            arc.sphere1.dispose(); arc.sphere2.dispose(); arc.tube.dispose(); 
        }); 
        this.activeArcs = []; 
         
        this.deactivate(); 
    } 
} 


class GravityMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 

        this.forceMagnitude = 200; 
        this.forceDirection = 0; // 1 = Çekme, -1 = İtme 
         
        this.particleSystem = null; 

        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['gravity_green']; 

        // Zamanlayıcılar 
        this.mainInterval = null; 
        this.warningTimeout = null; 
        this.warningInterval = null; 
        this.activationTimeout = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) { 
                this.startWarning(); 
            } 
        }, 14000); 
    } 

    trigger() {
        if (this.gameManager.state.isRunning && !this.isWarmingUp && !this.isActive) {
            this.startWarning();
        }
    }

    startWarning() { 
        this.isWarmingUp = true; 
        this.forceDirection = (Math.random() < 0.5) ? 1 : -1; 

        let isPulsed = false; 
        this.warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        this.activationTimeout = setTimeout(() => { 
            clearInterval(this.warningInterval); 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) { 
                this.activate(); 
            } 
        }, 3000); 
    } 

    activate() { 
        this.isActive = true; 
        this.pentaTile.material = this.pentaPulseMaterial; 

        // Parçacık sistemini oluştur 
        this.particleSystem = new BABYLON.ParticleSystem("gravityParticles", 4000, this.scene); 
        this.particleSystem.particleTexture = new BABYLON.Texture("https://playground.babylonjs.com/textures/flare.png", this.scene); 
         
        // Yerçekimini sıfırla, böylece biz kontrol ederiz 
        this.particleSystem.gravity = new BABYLON.Vector3(0, 0, 0); 

        // Parçacıkları tüm alana yayan KUTU yayıcı 
        const gridSize = GAME_CONSTANTS.GRID_WIDTH * 1.8; 
        this.particleSystem.particleEmitterType = new BABYLON.BoxParticleEmitter(); 
        this.particleSystem.minEmitBox = new BABYLON.Vector3(-gridSize, 1.2, -gridSize); 
        this.particleSystem.maxEmitBox = new BABYLON.Vector3(gridSize, 1.2, gridSize); 
         
        this.particleSystem.emitter = BABYLON.Vector3.Zero(); // Merkezden yayılsın 
         
        // Başlangıçta hareketleri yok 
        this.particleSystem.direction1 = new BABYLON.Vector3(0, 0, 0); 
        this.particleSystem.direction2 = new BABYLON.Vector3(0, 0, 0); 
        this.particleSystem.minEmitPower = 0; 
        this.particleSystem.maxEmitPower = 0; 
         
        this.particleSystem.color1 = new BABYLON.Color4(0.2, 1.0, 0.3, 1.0); 
        this.particleSystem.color2 = new BABYLON.Color4(0.5, 1.0, 0.6, 1.0); 
        this.particleSystem.colorDead = new BABYLON.Color4(0.1, 0.3, 0.1, 0.0); 
        this.particleSystem.minSize = 0.15; 
        this.particleSystem.maxSize = 0.45; 
        this.particleSystem.minLifeTime = 1.0; 
        this.particleSystem.maxLifeTime = 2.5; 
        this.particleSystem.emitRate = 1000; 
        this.particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
         
        // Güvenilir temizlik için 
        this.particleSystem.targetStopDuration = 1; 
        this.particleSystem.disposeOnStop = true; 

        this.particleSystem.start(); 
         
        // 6 saniye sonra mekaniği durdur 
        this.activationTimeout = setTimeout(() => this.deactivate(), 6000); 
    } 

    // EKSİK OLAN VE TÜM SORUNU ÇÖZECEK METOT 
    update(deltaTime) { 
        // Önce oyuncuya kuvvet uygula 
        if (this.isActive) { 
            const playerImpostor = this.gameManager.goldbergController.currentGoldberg.physicsImpostor; 
            if (playerImpostor) { 
                const playerPos = this.gameManager.goldbergController.currentGoldberg.getAbsolutePosition(); 
                const forceVector = this.pentaTile.position.subtract(playerPos); 
                forceVector.y = 0;  
                forceVector.normalize(); 
                 
                const forceToApply = forceVector.scale(this.forceMagnitude * this.forceDirection); 
                playerImpostor.applyForce(forceToApply, playerPos); 
            } 
        } 

        // Sonra parçacıkları hareket ettir 
        if (this.isActive && this.particleSystem && this.particleSystem.particles) { 
            const particleSpeed = 4.0 * deltaTime; // Hızı deltaTime ile oranla 
            const center = this.pentaTile.position; 

            for (let particle of this.particleSystem.particles) { 
                let direction; 
                if (this.forceDirection === 1) { // ÇEKME 
                    direction = center.subtract(particle.position); 
                } else { // İTME 
                    direction = particle.position.subtract(center); 
                } 
                direction.y = 0; // Hareketi yatay tut 
                 
                // Parçacığın pozisyonunu doğrudan güncelle 
                particle.position.addInPlace(direction.normalize().scale(particleSpeed)); 
            } 
        } 
    } 

    deactivate() { 
        this.isActive = false; 
        this.pentaTile.material = this.pentaOriginalMaterial; 

        if (this.particleSystem) { 
            this.particleSystem.stop(); // Sistemi durdur, disposeOnStop=true olduğu için kendi kendini imha edecek. 
            this.particleSystem = null; 
        } 
    } 

    cleanup() { 
        clearInterval(this.mainInterval); 
        clearTimeout(this.activationTimeout); 
        clearInterval(this.warningInterval); // Her ihtimale karşı 
        this.deactivate(); 
    } 
} 


class DarkEnergyMechanic extends PentaMechanic { 
    constructor(scene, pentaTileController, gameManager) { 
        super(scene, pentaTileController, gameManager); 

        // DEĞİŞİKLİK: Artık tek bir nesne yerine bir dizi tutuyoruz. 
        this.activeBlackHoles = [];  
        this.allPlayableHexes = this.scene.getTransformNodeByName("ground").getChildMeshes().filter(m => m.isPlayable); 

        this.HEXES_TO_ABSORB = 10; 

        // Materyaller (değişiklik yok) 
        this.blackHoleMat = new BABYLON.StandardMaterial("bhMat", scene); 
        this.blackHoleMat.diffuseColor = new BABYLON.Color3(0, 0, 0); 
        this.blackHoleMat.emissiveColor = new BABYLON.Color3(0.05, 0, 0.1); 
        this.blackHoleMat.specularColor = new BABYLON.Color3(0,0,0); 

        const purpleColor = this.scene.metadata.hexColors['dark_purple'].emissiveColor; 
        this.fragmentMat = new BABYLON.StandardMaterial("fragmentMat", scene); 
        this.fragmentMat.emissiveColor = purpleColor.scale(2.0); 
        this.fragmentMat.diffuseColor = purpleColor; 
         
        this.fractalMatPurple = new BABYLON.StandardMaterial("fractalMatPurple", scene); 
        this.fractalMatPurple.emissiveColor = purpleColor.scale(1.5); 
        this.fractalMatPurple.disableLighting = true; 
         
        this.fractalMatBlack = new BABYLON.StandardMaterial("fractalMatBlack", scene); 
        this.fractalMatBlack.emissiveColor = new BABYLON.Color3(0.05, 0, 0.1); 
        this.fractalMatBlack.disableLighting = true; 

        this.glowLayer = this.scene.getGlowLayerByName("glow"); 
        this.pentaOriginalMaterial = this.pentaTile.material; 
        this.pentaPulseMaterial = this.scene.metadata.hexColors['dark_purple']; 
         
        // Bu UI elemanlarını artık birer "şablon" olarak kullanacağız 
        this.timerUITemplate = document.getElementById('destabilize-timer'); 
        this.absorbCounterUITemplate = document.getElementById('absorb-counter'); 
         
        this.mainInterval = null; 
    } 

    initialize() { 
        this.cleanup(); 
        this.mainInterval = setInterval(() => { 
            // OYUN DENGESİ İÇİN BİR LİMİT KOYALIM (örn: aynı anda en fazla 3 kara delik) 
            // Bu limiti kaldırmak istersen "&& this.activeBlackHoles.length < 3" kısmını silebilirsin. 
            if (this.gameManager.state.isRunning && this.activeBlackHoles.length < 3) { 
                this.startWarning(); 
            } 
        }, 20000);  
    } 

    trigger() {
        if (this.gameManager.state.isRunning && this.activeBlackHoles.length < 3) {
            this.startWarning();
        }
    }

    startWarning() { 
        if (this.isWarmingUp) return; // Zaten bir uyarı varsa yenisini başlatma 
        this.isWarmingUp = true; 
        let isPulsed = false; 
        const warningInterval = setInterval(() => { 
            isPulsed = !isPulsed; 
            this.pentaTile.material = isPulsed ? this.pentaPulseMaterial : this.pentaOriginalMaterial; 
        }, 400); 

        setTimeout(() => { 
            clearInterval(warningInterval); 
            this.pentaTile.material = this.pentaOriginalMaterial; 
            this.isWarmingUp = false; 
            if (this.gameManager.state.isRunning) this.activate(); 
        }, 3000); 
    } 

activate() {
    const spawnMargin = 10;
    const maxDistSqr = Math.pow(GAME_CONSTANTS.GRID_WIDTH * 1.8 - spawnMargin, 2);
    
    const existingPositions = this.activeBlackHoles.map(bh => bh.core.position);
    const pentaTilePosition = this.pentaTileController.mesh.position;
    const pentaTileRadius = GAME_CONSTANTS.HEX_RADIUS * 5; // Penta tile radius
    const safeDistance = pentaTileRadius + 5; // Minimum safe distance from penta tile
    
    const potentialHexes = this.allPlayableHexes.filter(h => {
        if (!h.isEnabled() || h.getAbsolutePosition().lengthSquared() > maxDistSqr) return false;
        
        // Check distance from existing black holes
        for (const pos of existingPositions) {
            if (BABYLON.Vector3.Distance(h.getAbsolutePosition(), pos) < 10) return false;
        }
        
        // NEW: Check distance from penta tile
        const distToPenta = BABYLON.Vector3.Distance(h.getAbsolutePosition(), pentaTilePosition);
        if (distToPenta < safeDistance) return false;
        
        return true;
    });

    if (potentialHexes.length === 0) return;
    const hex = potentialHexes[Math.floor(Math.random() * potentialHexes.length)];
    if (hex) this.createBlackHoleOnHex(hex);
}
     
    createBlackHoleOnHex(hex) { 
        const startPos = this.pentaTile.position; 
        const endPos = hex.getAbsolutePosition().add(new BABYLON.Vector3(0, 0.5, 0));  

        const core = BABYLON.MeshBuilder.CreateCylinder("bhCore_" + this.activeBlackHoles.length, { diameter: GAME_CONSTANTS.HEX_RADIUS * 2 * 2, height: 0.2, tessellation: 6 }, this.scene); 
        core.position = startPos; 
        core.material = this.blackHoleMat; 
        this.glowLayer.addIncludedOnlyMesh(core); 

        // Klonlanmış UI elemanları oluştur 
        const timerUI = this.timerUITemplate.cloneNode(true); 
        const absorbUI = this.absorbCounterUITemplate.cloneNode(true); 
        document.body.appendChild(timerUI); 
        document.body.appendChild(absorbUI); 
        timerUI.style.top = `${60 + this.activeBlackHoles.length * 100}px`; 
        absorbUI.style.top = `${120 + this.activeBlackHoles.length * 100}px`; 

        const newBlackHole = { 
            id: Math.random(), 
            core: core, 
            fragments: [], 
            timer: 12.0,  
            isPermanent: false, 
            pullForce: 50, 
            lastSparkTime: 0, 
            hexesAbsorbed: 0, 
            ui: { timer: timerUI, absorb: absorbUI } 
        }; 
         
        this.activeBlackHoles.push(newBlackHole); 
        const travelAnim = new BABYLON.Animation("travel", "position", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        travelAnim.setKeys([{ frame: 0, value: startPos }, { frame: 45, value: endPos }]); 

        this.scene.beginDirectAnimation(core, [travelAnim], 0, 45, false, 1, () => { 
            const fragmentCount = 5; 
            const spawnRadius = 4.0; 
            for (let i = 0; i < fragmentCount; i++) { 
                const angle = (i / fragmentCount) * Math.PI * 2; 
                const fragment = BABYLON.MeshBuilder.CreatePolyhedron("voidFragment", {type: 3, size: 0.6}, this.scene); 
                fragment.position = core.position.add(new BABYLON.Vector3(spawnRadius * Math.cos(angle), 0, spawnRadius * Math.sin(angle))); 
                fragment.material = this.fragmentMat; 
                this.glowLayer.addIncludedOnlyMesh(fragment); 
                newBlackHole.fragments.push(fragment); 
            } 
            newBlackHole.ui.timer.style.display = 'flex'; 
        }); 
    } 

    feedBlackHole(blackHoleToFeed) { 
        if (!blackHoleToFeed || !blackHoleToFeed.isPermanent) return; 
        blackHoleToFeed.hexesAbsorbed++; 
        const remaining = this.HEXES_TO_ABSORB - blackHoleToFeed.hexesAbsorbed; 
    blackHoleToFeed.ui.absorb.querySelector('span:last-child').textContent = remaining; 

    if (blackHoleToFeed.hexesAbsorbed >= this.HEXES_TO_ABSORB) {  
        this.closeBlackHole(blackHoleToFeed, true); 
    } 
    } 
     
    closeBlackHole(bh, success) { 
        bh.ui.timer.remove(); 
        bh.ui.absorb.remove(); 

        if(bh.fragments) bh.fragments.forEach(f => { 
            if(this.glowLayer) this.glowLayer.removeIncludedOnlyMesh(f); 
            f.dispose(); 
        }); 
         
        if (bh.core) { 
            this.glowLayer.removeIncludedOnlyMesh(bh.core); 
            const scaleAnim = new BABYLON.Animation("implode", "scaling", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
            scaleAnim.setKeys([{ frame: 0, value: bh.core.scaling }, { frame: 15, value: BABYLON.Vector3.Zero() }]); 
            this.scene.beginDirectAnimation(bh.core, [scaleAnim], 0, 15, false, 1, () => bh.core.dispose()); 
        } 
         
        this.activeBlackHoles = this.activeBlackHoles.filter(item => item.id !== bh.id); 
    } 
     
    transformToPermanent(bh) { 
        bh.isPermanent = true; 
        bh.ui.timer.style.display = 'none'; 
        bh.ui.absorb.style.display = 'flex'; 
        bh.ui.absorb.querySelector('span:last-child').textContent = `${this.HEXES_TO_ABSORB - bh.hexesAbsorbed}`; 
         
        const scaleAnim = new BABYLON.Animation("grow", "scaling", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        scaleAnim.setKeys([{ frame: 0, value: bh.core.scaling }, { frame: 60, value: new BABYLON.Vector3(2, 1, 2) }]); 
        this.scene.beginDirectAnimation(bh.core, [scaleAnim], 0, 60, false); 
         
        bh.fragments.forEach(frag => { this.glowLayer.removeIncludedOnlyMesh(frag); frag.dispose(); }); 
        bh.fragments = []; 
    } 

  update(deltaTime) { 
    if (this.activeBlackHoles.length === 0) return; 
    const player = this.gameManager.goldbergController.currentGoldberg; 
    if (!player || player.isDisposed()) return; 
    const playerPos = player.getAbsolutePosition(); 
     
    this.activeBlackHoles.forEach(bh => { 
        // Eğer kara delik kalıcı hale gelmişse: 
        if (bh.isPermanent) { 
            // 1. GERÇEK 3B MESAFE HESAPLAMASI 
            // Oyuncunun pozisyonu ile kara deliğin merkezi arasındaki gerçek 3 boyutlu vektör. 
            // .y bileşenini artık SIFIRLAMIYORUZ. 
            const pullVector3D = bh.core.position.subtract(playerPos); 
            const distance3D = pullVector3D.length(); 

            // 2. DİNAMİK OLAY UFKU YARIÇAPI 
            // Kara delik büyüdükçe ölümcül alanın da büyümesini sağlıyoruz. 
            // Bu, oynanışı görsellikle uyumlu hale getirir. 
            const baseEventHorizonRadius = 1.5; // Temel yarıçap 
            const eventHorizonRadius = baseEventHorizonRadius * bh.core.scaling.x; // Ölçekle çarp 

            // 3. ÇEKİM KUVVETİ (Hala yatay düzlemde daha iyi çalışır) 
            const pullVectorHorizontal = pullVector3D.clone(); 
            pullVectorHorizontal.y = 0; 
            if (pullVectorHorizontal.length() < 8) { 
                player.physicsImpostor.applyForce(pullVectorHorizontal.normalize().scale(bh.pullForce), playerPos); 
            } 

            // 4. YUTULMA (KAYBETME) KOŞULU 
            // Artık gerçek 3 boyutlu mesafeyi dinamik olay ufkuna göre kontrol ediyoruz. 
            if (distance3D < eventHorizonRadius) { 
                this.gameManager.endGame(false, "dark_energy"); 
            } 
         
        // Eğer kara delik henüz kalıcı değilse (bu kısım aynı kalıyor): 
        } else { 
             if(bh.fragments.length > 0){ 
                bh.timer -= deltaTime; 
                const timerSpan = bh.ui.timer.querySelector('span:last-of-type'); 
                if(timerSpan) timerSpan.textContent = bh.timer.toFixed(1) + 's'; 

                for (let j = bh.fragments.length - 1; j >= 0; j--) { 
                    const fragment = bh.fragments[j]; 
                    if (BABYLON.Vector3.Distance(playerPos, fragment.position) < 2.0) { 
                        this.collectFragment(fragment, bh.core); 
                        bh.fragments.splice(j, 1); 
                    } 
                } 

                if (bh.fragments.length === 0) { 
                    this.closeBlackHole(bh, true); 
                } else if (bh.timer <= 0) { 
                    this.transformToPermanent(bh); 
                } 
            } 
        } 
    }); 
} 

    cleanup() { 
        clearInterval(this.mainInterval); 
        this.activeBlackHoles.forEach(bh => { 
            if(bh.core) bh.core.dispose(); 
            if(bh.fragments) bh.fragments.forEach(f => f.dispose()); 
            bh.ui.timer.remove(); 
            bh.ui.absorb.remove(); 
        }); 
        this.activeBlackHoles = []; 
    } 

    collectFragment(fragment, core) { 
        this.glowLayer.removeIncludedOnlyMesh(fragment); 
        const anim = new BABYLON.Animation("fragAnim", "position", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
        anim.setKeys([{ frame: 0, value: fragment.position }, { frame: 15, value: core.position.clone() }]); 
        this.scene.beginDirectAnimation(fragment, [anim], 0, 15, false, 1, () => fragment.dispose()); 
    } 

    checkCollision(playerMesh) {} 
} 


    const PENTA_MECHANICS = { 
        'laser': LaserMechanic, 'solar': SolarMechanic, 'em_wave': EMWaveMechanic, 
        'gravity': GravityMechanic, 'dark_energy': DarkEnergyMechanic 
    }; 


    // --- GAME CLASSES --- 

    class GameManager { 
        constructor() { 
            this.scene = scene; 
            this.pentaTileController = null; 
            this.goldbergController = null; 
            this.joystickController = null; 
            this.cameraController = null; 
            this.activeMechanics = []; 
            this.currentStageId = null; 

            this.ui = { 
                stageSelectScreen: document.getElementById('stageSelectScreen'), 
                startScreen: document.getElementById('startScreen'), 
                endScreen: document.getElementById('endScreen'), 
                hud: document.getElementById('hud'), 
                renderCanvas: document.getElementById('renderCanvas'), 
                restartButton: document.getElementById('restartButton'), 
                hudLabel: document.getElementById('hudLabel'),
                hitsDisplay: document.getElementById('hitsDisplay'), 
                timeDisplay: document.getElementById('timeDisplay'), 
                endGameMessage: document.getElementById('endGameMessage'), 
                unstableTimer: document.getElementById('unstable-timer') 
            }; 

this.state = {
    isRunning: false,
    gameTime: 0,
    spawnInterval: null,
    gameTimeInterval: null,

    // --- YENİ: OLAY YÖNETİCİSİ DEĞİŞKENLERİ ---
    eventQueue: [],          // Aktif edilecek mekaniklerin sırası
    eventIndex: 0,           // Sıradaki hangi mekaniğin çalışacağı
    nextEventTimer: 0,       // Bir sonraki mekaniğe ne kadar kaldığı
    isMultiMechanicStage: false, // Bu aşama çoklu mekanik mi?

    isEndlessMode: false, // Sonsuz modda mıyız?
    score: 0,
    isCoreWarning: false,
    availableMechanics: []    

};

            
            // --- URL param: core modu mu? ---
            try {
              const _params = new URLSearchParams(window.location.search);
              this.isCoreMode = (_params.get('mode') === 'core');
            } catch(e) {
              this.isCoreMode = false;
            }
this.setupEventListeners(); 
            this.createStageButtons(); 
        } 

setControllers(penta, goldberg, joystick, camera, uiController) {
    this.pentaTileController = penta;
    this.goldbergController   = goldberg;
    this.joystickController    = joystick;
    this.cameraController      = camera;
    this.uiController          = uiController;  
}

 // Oyuncu verisi okuma (level/energy/relic)
getPlayerStats() {
  try {
// Asıl kaynaklar (SaveStore / dev seed)
const S = (window.SS && typeof SS.get === 'function') ? SS : { get: (_k, d)=>d };
const lvl   = Number(S.get('goldberg.level', 1));
const eng   = Number(S.get('currency.energy', S.get('dev.energy', 0)));
const relic = Number(S.get('currency.pentaRelic', S.get('dev.pentaRelic', 0)));

    // Eski/opsiyonel kaynaklar (geri uyum)
    const savedData = JSON.parse(localStorage.getItem('planetData') || '{}');
    const extra     = JSON.parse(localStorage.getItem('playerStats') || '{}');

    return {
      level: Number(extra.level ?? savedData.planetLevel ?? lvl),
      energy: Number(extra.energy ?? eng),
      relic: Number(extra.relic ?? relic),
    };
  } catch (e) {
    // En kötü senaryoda bile kilitler testte açılsın
    return { level: 10, energy: 500, relic: 10 };
  }
}



/* >>> PENTA SELECT UI (HexRun ile aynı kart dili) >>> */
createStageButtons() {
  const container = document.getElementById('stage-buttons-container');
  if (!container) return;

  // HexRun ile aynı liste düzeni
  container.classList.remove('hx-grid');
  container.classList.add('hx-list');
  container.innerHTML = '';

  const player = this.getPlayerStats();
  let ids = Object.keys(STAGE_CONFIG).map(n => parseInt(n,10)).sort((a,b)=>a-b);
  if (this.isCoreMode) { ids = [13]; } else { ids = ids.filter(id => id !== 13); }

  ids.forEach((id) => {
    const conf = STAGE_CONFIG[id];
    const req  = (typeof STAGE_REQUIREMENTS !== 'undefined' && STAGE_REQUIREMENTS[id]) 
                  ? STAGE_REQUIREMENTS[id] 
                  : { level:1, energy:1, relic:0 };

    const hasLevel  = Number(player.level)  >= Number(req.level);
    const hasEnergy = Number(player.energy) >= Number(req.energy);
    const hasRelic  = Number(player.relic  ?? player.relics ?? 0) >= Number(req.relic);
    const canEnter  = hasLevel && hasEnergy && hasRelic;

    const displayName = (conf?.title || `Stage ${id}`).replace(/^Stage\s+/i, 'Penta Stage ');

    const card = document.createElement('div');
    card.className = `hx-card select-item ${canEnter ? '' : 'locked'}`;
    card.dataset.stageId = String(id);

    // HexRun görünümü: head + meta + enter bar
    card.innerHTML = `
      <div class="head">
        <div class="name">${displayName}</div>
        <div class="count"> </div>
      </div>

      <div class="meta">
        <span class="req ${hasLevel ? '' : 'missing'}"><i class="dot lv"></i>Lv ${req.level}</span>
        <span class="req ${hasEnergy ? '' : 'missing'}"><i class="dot energy"></i>${req.energy}</span>
        <span class="req ${hasRelic ? '' : 'missing'}"><i class="dot relic"></i>Penta Relic ${req.relic}</span>
      </div>

      <div class="hx-bar enter">ENTER</div>
    `;

    const go = () => {
      if (!canEnter) return;
      this.ui.stageSelectScreen.style.display = 'none';
      this.startGame(id);
    };

    card.querySelector('.enter')?.addEventListener('click', (e) => { e.stopPropagation(); go(); });
    card.addEventListener('click', (e) => {
      if (e.target && e.target.closest && e.target.closest('.enter')) return;
      go();
    });

    container.appendChild(card);
  });
}



/* <<< PENTA SELECT UI <<< */
// === UI eventleri ===
setupEventListeners() {
  const back1 = document.getElementById('hubButton');
  back1?.addEventListener('click', () => { document.getElementById('backInRunPenta')?.remove(); window.location.href = 'index.html'; });

  const back2 = document.getElementById('hubButtonEnd');
  back2?.addEventListener('click', () => { document.getElementById('backInRunPenta')?.remove(); window.location.href = 'index.html'; });

  const restart = document.getElementById('restartButton');
  restart?.addEventListener('click', () => {
    this.ui.endScreen.style.display = 'none';
    this.ui.stageSelectScreen.style.display = 'flex';
    document.getElementById('backInRunPenta')?.remove();
  });
}


// --- GameManager sınıfı içine eklenecek yeni bir metod ---

handleOrientationChange() {
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const isLandscape = width > height;
    
    // UI elemanlarını yeniden konumlandır
    if (this.joystickController) this.joystickController.adjustUIScale();
    if (this.uiController) this.uiController.adjustUIScale();
    
    // Kamera ayarlarını güncelle
    if (this.cameraController) {
        if (isLandscape) {
            // Yatay ekran için kamera ayarları
            GAME_CONSTANTS.CAMERA_X_OFFSET = -30;
            GAME_CONSTANTS.CAMERA_Y_POSITION = 50;
        } else {
            // Dikey ekran için kamera ayarları
            GAME_CONSTANTS.CAMERA_X_OFFSET = -20;
            GAME_CONSTANTS.CAMERA_Y_POSITION = 40;
        }
        this.cameraController.reset();
    }
}

updateComboSlotAppearance() {
if (!this.ui.comboSlotButtons) return;
    const stageId = parseInt(this.currentStageId);
    let unlockedCount = 0;

    if (stageId >= 10) {
        unlockedCount = 3;
    } else if (stageId >= 6) {
        unlockedCount = 2;
    } else {
        unlockedCount = 1;
    }

    // Butonların üzerinden geç ve durumlarını ayarla
    this.ui.comboSlotButtons.forEach((button, index) => {
        if (index < unlockedCount) {
            // ---- AÇIK VE BOŞ SLOT STİLİ ----
            button.isEnabled = true;
            button.background = "rgba(100, 100, 100, 0.5)"; // Yarı şeffaf gri
            button.alpha = 1.0; // Tamamen görünür
        } else {
            // ---- KİLİTLİ SLOT STİLİ ----
            button.isEnabled = false;
            button.background = "#222"; // Koyu renk
            button.alpha = 0.4; // Soluk ve sönük görünmesi için
        }
    });
}

    setCoreWarning(isWarning) {
        this.state.isCoreWarning = isWarning;
    }


    requestUIUpdate() {
        if (!this.uiController) return;
        
        const stageId = parseInt(this.currentStageId);
        let unlockedSlots = 0;
        
        // Stage'e göre açık slot sayısını belirleme
        if (stageId >= 10) unlockedSlots = 3;
        else if (stageId >= 6) unlockedSlots = 2;
        else unlockedSlots = 1;
        
        const gameState = {
            unlockedSlots: unlockedSlots,
            storedCombos: this.goldbergController.storedCombos,
            comboSequence: this.goldbergController.comboSequence
        };
        
        this.uiController.updateAppearance(gameState);
    }


startGame(stageId) {
        this.currentStageId = stageId;
        this.state.isEndlessMode = (this.currentStageId == 13);
        
        const pentagon = this.scene.getMeshByName("pentaTile");
        const icosahedron = this.scene.getMeshByName("icosahedronCore");

        if (this.state.isEndlessMode) {
            pentagon.setEnabled(false);
            icosahedron.setEnabled(true);
            this.pentaTileController.setActiveMesh(icosahedron);
        } else {
            pentagon.setEnabled(true);
            icosahedron.setEnabled(false);
            this.pentaTileController.setActiveMesh(pentagon);
        }

        this.ui.stageSelectScreen.style.display = 'none';
        this.ui.endScreen.style.display = 'none';
        this.ui.renderCanvas.style.display = 'block';
        this.ui.hud.style.display = 'block';
        // In-run Back (seçim ekranından bağımsız)
        (function(){
          let back = document.getElementById('backInRunPenta');
          if (!back) {
            back = document.createElement('button');
            back.id = 'backInRunPenta';
            back.className = 'hx-btn ghost sm';
            back.textContent = 'Back';
            back.style.cssText = 'position:fixed;top:12px;left:12px;z-index:900';
            back.addEventListener('click', () => {
              try {
                // Oyun UI’larını kapat, seçim ekranını aç
                document.getElementById('renderCanvas').style.display = 'none';
                document.getElementById('hud').style.display = 'none';
                document.getElementById('endScreen').style.display = 'none';
                document.getElementById('stageSelectScreen').style.display = 'flex';
              } finally {
                document.getElementById('backInRunPenta')?.remove();
              }
            });
            document.body.appendChild(back);
          }
        })();

        if (this.uiController) this.uiController.show();
        if (this.joystickController) this.joystickController.show(); // 3D Joystick'i göster
        engine.resize();

        if (this.ui.unstableTimer) this.ui.unstableTimer.style.display = 'none';

        this.state.isRunning = true;
        this.state.gameTime = 0;
        
        this.pentaTileController.reset();
        this.goldbergController.reset();
        this.cameraController.reset();
        this.updateHUD();
        
        this.requestUIUpdate();

        if (this.state.spawnInterval) clearInterval(this.state.spawnInterval);
        this.state.spawnInterval = setInterval(() => {
            if (this.state.isRunning) this.spawnNewHex();
        }, 1500);

        if (this.state.gameTimeInterval) clearInterval(this.state.gameTimeInterval);
        this.state.gameTimeInterval = setInterval(() => {
            if (this.state.isRunning) {
                this.state.gameTime++;
                this.updateHUD();
            }
        }, 1000);

        this.activeMechanics.forEach(m => m.cleanup());
        this.activeMechanics = [];
        this.state.eventQueue = [];
        this.state.isMultiMechanicStage = false;

        const stageConf = STAGE_CONFIG[this.currentStageId];
        if (stageConf) {
            this.activeMechanics = [];
            this.state.availableMechanics = [];
            stageConf.mechanics.forEach(mechKey => {
                const MechanicClass = PENTA_MECHANICS[mechKey];
                if (MechanicClass) {
                    this.activeMechanics.push(new MechanicClass(this.scene, this.pentaTileController, this));
                }
            });

        if (this.state.isEndlessMode) {
            // Sonsuz modda başlangıçta bazı mekanikleri kullanılabilir yap
            const laserMechanic = this.activeMechanics.find(m => m instanceof LaserMechanic);
            const solarMechanic = this.activeMechanics.find(m => m instanceof SolarMechanic);
            
            if (laserMechanic) this.state.availableMechanics.push(laserMechanic);
            if (solarMechanic) this.state.availableMechanics.push(solarMechanic);
            
            // Başlangıç zamanlayıcısını ayarla
            this.state.nextEventTimer = 5; // 5 saniye sonra ilk mekanik tetiklensin
        } else {
                const mainMechanicsQueue = [];
                this.activeMechanics.forEach(mechanic => {
                    if (mechanic instanceof GravityMechanic) {
                        mechanic.initialize();
                    } else {
                        mainMechanicsQueue.push(mechanic);
                    }
                });
                
                if (this.activeMechanics.length > 1 && mainMechanicsQueue.length > 0) {
                    this.state.isMultiMechanicStage = true;
                    this.state.eventQueue = mainMechanicsQueue.sort(() => Math.random() - 0.5);
                    this.state.eventIndex = 0;
                    this.state.nextEventTimer = 7;
                } else if (mainMechanicsQueue.length === 1) {
                    mainMechanicsQueue[0].initialize();
                }
            }
        }
    }

    endGame(isWin, cause = "fall") {
        if (!this.state.isRunning) return;
        this.state.isRunning = false;
        clearInterval(this.state.spawnInterval);
        clearInterval(this.state.gameTimeInterval);
        
        this.activeMechanics.forEach(m => m.cleanup());
        this.activeMechanics = [];

        if (this.goldbergController) this.goldbergController.reset();
        this.pentaTileController.resetMaterial();

        this.ui.hud.style.display = 'none';
        if (this.uiController) this.uiController.hide();
        if (this.joystickController) this.joystickController.hide(); // 3D Joystick'i gizle

        if (document.getElementById('destabilize-timer')) document.getElementById('destabilize-timer').style.display = 'none';
        if (document.getElementById('unstable-timer')) document.getElementById('unstable-timer').style.display = 'none';

        const endScreenTitle = this.ui.endScreen.querySelector('h1');
        if (isWin) {
            endScreenTitle.textContent = `PENTA STAGE ${this.currentStageId} TAMAMLANDI!`;
        } else {
            let causeMessage = "DÜŞTÜN!";
            if (cause === "hazard") causeMessage = "ENERJİ AŞIRI YÜKLENDİ!";
            if (cause === "dark_energy") causeMessage = "HİÇLİK TARAFINDAN YUTULDUN!";
            endScreenTitle.textContent = causeMessage;
        }
        this.ui.endGameMessage.textContent = `Süren: ${this.state.gameTime}s`;
        this.ui.endScreen.style.display = 'flex';
    }

updateHUD() {
    // Zaman her iki modda da güncellenir.
    this.ui.timeDisplay.textContent = this.state.gameTime + "s";

    if (this.state.isEndlessMode) {
        // Sonsuz modda: Etiketi "Skor:" yap ve skoru göster.
        this.ui.hudLabel.textContent = "Skor:";
        this.ui.hitsDisplay.textContent = this.state.score;
    } else {
        // Normal modda: Etiketi "Hedef:" yap ve kalan hedefi göster.
        this.ui.hudLabel.textContent = "Hedef:";
        this.ui.hitsDisplay.textContent = this.pentaTileController.getHitsNeeded();
    }
}

update() {
    // Oyun çalışmıyorsa hiçbir şey yapma.
    if (!this.state.isRunning) return;

    const deltaTime = engine.getDeltaTime() / 1000;
    const gameTime = this.state.gameTime;

    // 1. Tüm aktif mekaniklerin kendi iç güncellemelerini (rotasyon, parçacık hareketi vs.) her zaman çalıştır.
    this.activeMechanics.forEach(m => m.update(deltaTime));

    // 2. OYUN MODUNA GÖRE OLAY YÖNETİCİSİNİ ÇALIŞTIR
    // ==========================================================

    if (this.state.isEndlessMode) {
        // --- A) SONSUZ MOD: 3 FAZLI ZORLUK YÖNETİCİSİ ---

        // Faz geçişlerini oyun zamanına göre kontrol et.
        // 45. saniyede Faz 2'ye geçilir ve yeni mekanikler havuza eklenir.
        if (gameTime >= 45 && this.state.availableMechanics.length < 4) {
            const emWave = this.activeMechanics.find(m => m instanceof EMWaveMechanic);
            const darkEnergy = this.activeMechanics.find(m => m instanceof DarkEnergyMechanic);
            
            // Mekaniğin daha önce eklenmediğinden emin olarak havuza ekle.
            if (emWave && !this.state.availableMechanics.includes(emWave)) {
                this.state.availableMechanics.push(emWave);
            }
            if (darkEnergy && !this.state.availableMechanics.includes(darkEnergy)) {
                this.state.availableMechanics.push(darkEnergy);
            }
            console.log("Endless Mode Phase 2 Started. Available mechanics:", this.state.availableMechanics.map(m => m.constructor.name));
        }

        // Mekanik tetikleme zamanlayıcısını geri say.
        this.state.nextEventTimer -= deltaTime;
        if (this.state.nextEventTimer <= 0) {
            // Süre dolduğunda, o anki "kullanılabilir" havuzdan rastgele bir mekanik seç ve tetikle.
            if (this.state.availableMechanics.length > 0) {
                const randomIndex = Math.floor(Math.random() * this.state.availableMechanics.length);
                const randomMechanic = this.state.availableMechanics[randomIndex];
                randomMechanic.trigger();
            }

            // Bir sonraki mekanik için bekleme süresini mevcut faza göre hesapla.
            let interval;
            if (gameTime < 45) { // Faz 1
                interval = 12 + Math.random() * 3; // 12-15 saniye aralıkla
            } else if (gameTime < 180) { // Faz 2
                const progress = (gameTime - 45) / (180 - 45); // 0-1 arası ilerleme
                interval = 12 - (progress * 8); // 12sn'den 4sn'ye kademeli düşüş
            } else { // Faz 3
                interval = 3 + Math.random(); // 3-4 saniye aralıkla
            }
            this.state.nextEventTimer = Math.max(3, interval); // Güvenlik için minimum 3 saniye
        }

        // Çekirdek üzerindeki şimşek efektini sürekli çalıştır.
        const coreMesh = this.scene.getMeshByName("icosahedronCore");
        if (coreMesh) {
            spawnCoreArcs(coreMesh, this.scene);
        }

    } else if (this.state.isMultiMechanicStage) {
        // --- B) NORMAL ÇOKLU AŞAMA (6-12): BASİT SIRALI YÖNETİCİ ---
        // Bu, sizin mevcut kodunuzdur ve normal aşamalar için çalışmaya devam eder.
        this.state.nextEventTimer -= deltaTime;
        if (this.state.nextEventTimer <= 0) {
            const mechanicToTrigger = this.state.eventQueue[this.state.eventIndex];
            if (mechanicToTrigger) {
                mechanicToTrigger.trigger();
            }
            this.state.eventIndex = (this.state.eventIndex + 1) % this.state.eventQueue.length;
            this.state.nextEventTimer = 8 + Math.random() * 4;
        }
    }

    // ==========================================================
    // 3. OYUNCU DÜŞME KONTROLÜ (Her zaman çalışır)
    // ==========================================================
    if (this.goldbergController.currentGoldberg && this.goldbergController.currentGoldberg.position.y < GAME_CONSTANTS.PLAYER_FALL_LIMIT) {
        this.endGame(false, "fall");
    }
}

checkMechanicCollisions() {
    if (!this.goldbergController.currentGoldberg || this.goldbergController.currentGoldberg.isDisposed()) return;
    
    this.activeMechanics.forEach(m => m.checkCollision(this.goldbergController.currentGoldberg));
}

// GameManager sınıfı içinde... 

spawnNewHex() {
    const ground = this.scene.getTransformNodeByName("ground");
    if (!ground) return;
    const hexColors = this.scene.metadata.hexColors;
    const playableHexMaterial = this.scene.getMaterialByName("playableHexMat");
    if (!hexColors || !playableHexMaterial) return;

    // 1. Sahnedeki tüm uygun hex'leri ve kara delikleri BİR KEZ al.
    const playableHexes = ground.getChildMeshes().filter(m => m.isPlayable && !m.specialColor && m.isEnabled());
    const darkEnergyMechanic = this.activeMechanics.find(m => m instanceof DarkEnergyMechanic);
    const permanentBlackHoles = darkEnergyMechanic ? darkEnergyMechanic.activeBlackHoles.filter(bh => bh.isPermanent) : [];

    // Spawn edilecek tile sayısı. En az bu kadar boş hex olmalı.
    const SPAWN_COUNT = 2;
    if (playableHexes.length < SPAWN_COUNT) return;

    // Oyuncuya sunulacak farklı renkleri hazırla ve karıştır.
    let availableColors = Object.keys(hexColors).sort(() => Math.random() - 0.5);

    // 2. Üç adet tile spawn etmek için döngüye gir.
    for (let i = 0; i < SPAWN_COUNT; i++) {
        // Döngünün her adımında listeden rastgele bir hex seç.
        const hexIndex = Math.floor(Math.random() * playableHexes.length);
        const chosenHex = playableHexes[hexIndex];
        
        // Seçilen hex'i listeden çıkar ki bir daha seçilmesin.
        playableHexes.splice(hexIndex, 1);

        let isSwallowed = false;

        // 3. Kara delik mekaniği aktifse, bu hex'in yutulup yutulmayacağını kontrol et.
        if (permanentBlackHoles.length > 0) {
            let closestBH = null;
            let minDistance = Infinity;
            permanentBlackHoles.forEach(bh => {
                const distance = BABYLON.Vector3.Distance(chosenHex.getAbsolutePosition(), bh.core.position);
                if (distance < minDistance) {
                    minDistance = distance;
                    closestBH = bh;
                }
            });

            const pullRadius = (GAME_CONSTANTS.HEX_RADIUS * 2 * 2) * closestBH.core.scaling.x * 2.5;

            // Eğer hex, en yakın kara deliğin çekim alanındaysa...
            if (minDistance < pullRadius) {
                isSwallowed = true; // Bu hex'in yutulacağını işaretle.

                // Orijinal kodunuzdaki "kara deliğe yem olma" animasyonunu burada çalıştır.
                const swallowedColorName = Object.keys(hexColors)[Math.floor(Math.random() * Object.keys(hexColors).length)];
                chosenHex.material = hexColors[swallowedColorName];
                chosenHex.specialColor = swallowedColorName; // Geçici olarak işaretle

                setTimeout(() => {
                    if (chosenHex && !chosenHex.isDisposed() && chosenHex.specialColor) {
                        const colorName = chosenHex.specialColor;
                        chosenHex.material = playableHexMaterial;
                        delete chosenHex.specialColor;

                        const flyingHex = chosenHex.clone("flyingHex_bh_" + Math.random());
                        flyingHex.material = this.scene.metadata.hexColors[colorName];
                        flyingHex.isPlayable = false;
                        flyingHex.setParent(null);
                        flyingHex.position = chosenHex.getAbsolutePosition();
                        createTrailParticles(flyingHex, this.scene.metadata.hexColors[colorName].diffuseColor, this.scene);

                        const frameRate = 60;
                        const animDuration = frameRate * 2.5;
                        const positionAnim = new BABYLON.Animation("hexFlyToBH", "position", frameRate, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
                        const midPosition = BABYLON.Vector3.Lerp(flyingHex.position, closestBH.core.position, 0.5);
                        midPosition.y += 4;
                        positionAnim.setKeys([
                            { frame: 0, value: flyingHex.position },
                            { frame: animDuration / 2, value: midPosition },
                            { frame: animDuration, value: closestBH.core.position.clone() }
                        ]);

                        const animGroup = this.scene.beginDirectAnimation(flyingHex, [positionAnim], 0, animDuration, false);
                        animGroup.onAnimationEnd = () => {
                            darkEnergyMechanic.feedBlackHole(closestBH);
                            createImpactParticles(flyingHex.position, this.scene.metadata.hexColors[colorName].diffuseColor, this.scene);
                            flyingHex.dispose();
                        };
                    }
                }, 500); // Yutulmadan önce yarım saniye görünür kalsın.
            }
        }
        
        // 4. Eğer hex yutulmadıysa, oyuncu için normal "Seçim Paketi" spawn'ını yap.
        if (!isSwallowed) {
            if (availableColors.length === 0) continue; // Renk kalmadıysa bu adımı atla.

            const colorName = availableColors.pop(); // Sıradaki farklı rengi al.
            chosenHex.material = hexColors[colorName];
            chosenHex.specialColor = colorName;

            setTimeout(() => {
                if (chosenHex && !chosenHex.isDisposed() && chosenHex.specialColor) {
                    chosenHex.material = playableHexMaterial;
                    delete chosenHex.specialColor;
                }
            }, 12000); // Oyuncunun toplaması için 12 saniye süre.
        }
    }
}
}

    class PentaTileController { 
        constructor(mesh) { 
            this.mesh = mesh; 
            this.scene = mesh.getScene(); 
            this.originalMaterial = mesh.material; 
            this.hitsNeeded = GAME_CONSTANTS.HITS_TO_WIN; 
        } 

    setActiveMesh(newMesh) {
        this.mesh = newMesh;
    }

  reset() {
        // Skoru ve hedefi sıfırla
        this.hitsNeeded = GAME_CONSTANTS.HITS_TO_WIN;
        if (gameManager) { // gameManager'ın var olduğundan emin ol
             gameManager.state.score = 0;
        }
    }


        resetMaterial() { 
            this.mesh.material = this.originalMaterial; 
        } 

 takeHit(isCombo) {
        const damage = isCombo ? 6 : 1;
        let isWin = false;

        if (gameManager.state.isEndlessMode) {
            // Sonsuz moddaysak, hedefi düşürmek yerine skoru artır.
            gameManager.state.score += damage;
            // Sonsuz modda oyun asla bitmez.
            isWin = false; 
        } else {
            // Normal moddaysak, hedefi düşür.
            this.hitsNeeded = Math.max(0, this.hitsNeeded - damage);
            isWin = this.hitsNeeded <= 0;
        }

        const flash = new BABYLON.HighlightLayer("hl_" + Math.random(), this.scene);
        flash.addMesh(this.mesh, isCombo ? new BABYLON.Color3(1, 0.7, 0) : BABYLON.Color3.White());
        setTimeout(() => { flash.dispose(); }, isCombo ? 400 : 150);
        
        return isWin;
    }
        getHitsNeeded() { return this.hitsNeeded; } 
    } 

    class MovementController { 
        constructor() { this.speed = GAME_CONSTANTS.HEX_RADIUS * 50 * GAME_CONSTANTS.SPACING_FACTOR; this.xVelocity = 0; this.zVelocity = 0; this.moveDirections = { forward: false, backward: false, left: false, right: false }; } 
        setVelocity(xVel, zVel) { this.xVelocity = xVel; this.zVelocity = zVel; } 
        startMove(direction) { this.moveDirections[direction] = true; } 
        stopMove(direction) { this.moveDirections[direction] = false; } 
    } 

// =========================================================================================
// YENİ 3D JOYSTICK KONTROLCÜSÜ
// =========================================================================================
   class Joystick3DController {
    constructor(scene, movementController) {
        this.scene = scene;
        this.movementController = movementController;
        this.camera = null;
        this.uiParent = null; 
        this.base = null;     
        this.nub = null;      

        this.isDragging = false;
        this.pointerId = -1;
        
        this.baseRadius = 7; 
        this.maxPixelRadius = 100;

        // Ekran yönünü takip etmek için yeni değişkenler
        this.isLandscape = true;
        this.lastScreenWidth = 0;
        this.lastScreenHeight = 0;
        
        // Joystick için ergonomik konumlar
        this.landscapePosition = new BABYLON.Vector3(1.5, -2.5, 12);
        this.portraitPosition = new BABYLON.Vector3(1.0, -1.8, 12);

        this.initialPointerPos = new BABYLON.Vector2(0, 0);
    }

    createUI(camera) {
        this.camera = camera;
        if (this.uiParent) this.uiParent.dispose();

        // İlk yükleme için ekran boyutunu kaydet
        this.lastScreenWidth = engine.getRenderWidth();
        this.lastScreenHeight = engine.getRenderHeight();
        this.isLandscape = this.lastScreenWidth > this.lastScreenHeight;          

// Ekran yönüne göre ilk konumlandırma
        this.updatePositionForOrientation();

        this.uiParent = new BABYLON.TransformNode("JoystickUIParent", this.scene);
        this.uiParent.parent = this.camera;
        this.uiParent.position = new BABYLON.Vector3(1.5, -2.5, 12);

        const baseMaterial = new BABYLON.PBRMaterial("joyBaseMat", this.scene);
        baseMaterial.metallic = 0.3;
        baseMaterial.roughness = 0.7;
        baseMaterial.albedoColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        baseMaterial.alpha = 0.5;

        const nubMaterial = new BABYLON.PBRMaterial("joyNubMat", this.scene);
        nubMaterial.metallic = 0.8;
        nubMaterial.roughness = 0.4;
        nubMaterial.albedoColor = new BABYLON.Color3(0.9, 0.1, 0.1);
        nubMaterial.emissiveColor = new BABYLON.Color3(0.5, 0.05, 0.05);

        this.base = BABYLON.MeshBuilder.CreateCylinder("joystickBase", { height: 0.2, diameter: this.baseRadius * 1.5, tessellation: 6 }, this.scene);
        this.base.material = baseMaterial;
        this.base.parent = this.uiParent;
        this.base.rotation.x = Math.PI / 2;

        this.nub = BABYLON.MeshBuilder.CreateCylinder("joystickNub", { height: 0.5, diameter: 5, tessellation: 6 }, this.scene);
        this.nub.material = nubMaterial;
        this.nub.parent = this.base;
        this.nub.position.z = -0.5;

        this.scene.onPointerObservable.add((pointerInfo) => {
            switch (pointerInfo.type) {
                case BABYLON.PointerEventTypes.POINTERDOWN:
                    if (!gameManager.state.isRunning || this.isDragging) return;
                    
                    const pickResult = this.scene.pick(this.scene.pointerX, this.scene.pointerY, (mesh) => mesh === this.base);
                    if (pickResult.hit) {
                        this.isDragging = true;
                        this.pointerId = pointerInfo.event.pointerId;
                        this.initialPointerPos.set(this.scene.pointerX, this.scene.pointerY);
                        this.updateMovement(this.scene.pointerX, this.scene.pointerY);
                    }
                    break;
                case BABYLON.PointerEventTypes.POINTERUP:
                case BABYLON.PointerEventTypes.POINTEROUT:
                    if (pointerInfo.event.pointerId === this.pointerId) {
                        this.isDragging = false;
                        this.pointerId = -1;
                        this.resetMovement();
                    }
                    break;
                case BABYLON.PointerEventTypes.POINTERMOVE:
                    if (this.isDragging && pointerInfo.event.pointerId === this.pointerId) {
                        this.updateMovement(this.scene.pointerX, this.scene.pointerY);
                    }
                    break;
            }
        });

        this.adjustUIScale();
        window.addEventListener('resize', () => this.adjustUIScale());
        this.hide();
    }

updatePositionForOrientation() {
    if (!this.uiParent) return;
    
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const isLandscape = width > height;
    
    if (isLandscape) {
        // Yatay ekran - joystick sağ alt köşede
        this.uiParent.position = new BABYLON.Vector3(1.5, -2.5, 12);
    } else {
        // Dikey ekran - joystick alt orta-sağda
        this.uiParent.position = new BABYLON.Vector3(1.0, -1.8, 12);
    }
}

increaseTouchArea() {
    // Dokunmatik alanı genişlet
    const touchArea = BABYLON.MeshBuilder.CreateCylinder("touchArea", {
        diameter: this.baseRadius * 2.5,
        height: 0.1,
        tessellation: 12
    }, this.scene);
    touchArea.visibility = 0; // Görünmez yap
    touchArea.parent = this.base;
    touchArea.isPickable = true;
    this.base.isPickable = true;
}

    updateMovement(currentX, currentY) {
        const deltaX = currentX - this.initialPointerPos.x;
        const deltaY = currentY - this.initialPointerPos.y;
        const moveVector = new BABYLON.Vector2(deltaX, deltaY);

        // Görsel topuzu sürüklenen mesafeye göre hareket ettir
        const clampedVector = moveVector.clone();
        if (moveVector.length() > this.maxPixelRadius) {
            clampedVector.normalize().scaleInPlace(this.maxPixelRadius);
        }
    this.nub.position.x = clampedVector.x / this.maxPixelRadius * (this.baseRadius / 2);
    this.nub.position.z = clampedVector.y / this.maxPixelRadius * (this.baseRadius / 2);

        // Hareketi 0-1 arasında bir güce dönüştür
        const force = Math.min(1.0, moveVector.length() / this.maxPixelRadius);
        const normalizedVector = moveVector.normalize();

        if (force > 0.1) {
            // *** EKSEN HARİTALAMA DÜZELTMESİ ***
            // Bu kod, joystick hareketini sizin klavye kontrollerinizle birebir eşler.
            // Sürükleme Yukarı/Aşağı (normalizedVector.y) -> Oyuncu Sağa/Sola (xVelocity)
            // Sürükleme Sağa/Sola (normalizedVector.x) -> Oyuncu Yukarı/Aşağı (zVelocity)
            this.movementController.setVelocity(-normalizedVector.y * force, -normalizedVector.x * force);
        } else {
            this.movementController.setVelocity(0, 0);
        }
    }
    
    resetMovement() {
        this.nub.position.x = 0;
        this.nub.position.y = 0;
        this.movementController.setVelocity(0, 0);
    }
    
adjustUIScale() {
    if (!this.uiParent) return;
    
    // Sabit bir ölçeklendirme faktörü kullan
    const baseScale = 0.1; // Bu değeri joystick boyutuna göre ayarlayın
    
    this.uiParent.scaling = new BABYLON.Vector3(baseScale, baseScale, baseScale);
}

    show() { if (this.uiParent) this.uiParent.setEnabled(true); }
    hide() { if (this.uiParent) this.uiParent.setEnabled(false); }
}

class InGameUIController {
    constructor(scene) {
        this.scene = scene;
        this.uiParent = null;
        this.slotMeshes = [];
        this.indicatorMeshes = [];
        this.camera = null;

        this.isLandscape = true;
        this.lastScreenWidth = 0;
        this.lastScreenHeight = 0;
        
        // UI elemanları için ergonomik konumlar
        this.landscapePositions = {
            uiParent: new BABYLON.Vector3(-1.1, -1.4, 10),
            indicatorParent: new BABYLON.Vector3(-4, 2, 0),
            slotParent: new BABYLON.Vector3(-4, -2, 0)
        };
        
        this.portraitPositions = {
            uiParent: new BABYLON.Vector3(-0.8, -0.8, 10),
            indicatorParent: new BABYLON.Vector3(-3, 2.5, 0),
            slotParent: new BABYLON.Vector3(-3, -3, 0)
        };
    }

    createUI(camera) {
        this.camera = camera;
        
        // Önceki UI elemanlarını temizle
        if (this.uiParent) {
            this.uiParent.dispose();
            this.slotMeshes = [];
            this.indicatorMeshes = [];
        }

        // İlk yükleme için ekran boyutunu kaydet
        this.lastScreenWidth = engine.getRenderWidth();
        this.lastScreenHeight = engine.getRenderHeight();
        this.isLandscape = this.lastScreenWidth > this.lastScreenHeight;
        
        // Ekran yönüne göre ilk konumlandırma
        this.updatePositionsForOrientation();

        // UI için ana konteyner oluştur
        this.uiParent = new BABYLON.TransformNode("UIParent", this.scene);
        this.uiParent.parent = camera;
        
        // UI'ı kameranın önünde sabit bir konuma yerleştir
        this.uiParent.position = new BABYLON.Vector3(-1.1, -1.4, 10);
        
        // ===== İNDİKATÖRLER =====
        // Kombo göstergesi için panel
        const indicatorParent = new BABYLON.TransformNode("IndicatorParent", this.scene);
        indicatorParent.parent = this.uiParent;
        indicatorParent.position = new BABYLON.Vector3(-4, 2, 0);
        
        // İndikatörler için PBR materyal
        const indicatorMaterial = new BABYLON.PBRMaterial("indicatorPBRMat", this.scene);
        indicatorMaterial.metallic = 0.2;
        indicatorMaterial.roughness = 0.5;
        indicatorMaterial.albedoColor = new BABYLON.Color3(0.4, 0.4, 0.4);
        indicatorMaterial.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        indicatorMaterial.alpha = 0.4;
        
        // İndikatör altıgenlerini oluştur - 3D görünüm için
        for (let i = 0; i < 3; i++) {
            // Ana indikatör
            const indicatorHex = BABYLON.MeshBuilder.CreateCylinder(
                "indicatorHex_" + i, 
                { height: 0.3, diameter: 2, tessellation: 6 },
                this.scene
            );
            indicatorHex.parent = indicatorParent;
            indicatorHex.position.x = i * 2;
            
            // İndikatörleri hafif açılandır
            indicatorHex.rotation.x = Math.PI / 2 - Math.PI / 12;
            indicatorHex.rotation.y = -Math.PI / 18;
            
            indicatorHex.material = indicatorMaterial.clone("indicatorMat_" + i);
            
            // İndikatör kapağı (3D görünüm için)
            const indicatorCap = BABYLON.MeshBuilder.CreateCylinder(
                "indicatorCap_" + i, 
                { height: 0.1, diameter: 1.8, tessellation: 6 },
                this.scene
            );
            indicatorCap.parent = indicatorHex;
            indicatorCap.position.y = 0.2;
            
            // Kapak için materyal
            const capMaterial = indicatorMaterial.clone("indicatorCapMat_" + i);
            capMaterial.emissiveColor = new BABYLON.Color3(0.15, 0.15, 0.15);
            indicatorCap.material = capMaterial;
            
            this.indicatorMeshes.push(indicatorHex);
        }
        
        // ===== SLOT BUTONLARI =====
        // Slot butonları için panel
        const slotParent = new BABYLON.TransformNode("SlotParent", this.scene);
        slotParent.parent = this.uiParent;
        slotParent.position = new BABYLON.Vector3(-4, -2, 0);
        
        // Slot butonları için PBR materyal
        const slotMaterial = new BABYLON.PBRMaterial("slotPBRMat", this.scene);
        slotMaterial.metallic = 0.3;
        slotMaterial.roughness = 0.4;
        slotMaterial.albedoColor = new BABYLON.Color3(0.3, 0.3, 0.3);
        slotMaterial.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1); // Daha düşük emisyon
        slotMaterial.alpha = 0.6;
        
        // Glow layer referansı
        const glowLayer = this.scene.getGlowLayerByName("glow");
        
        // Slot butonlarını oluştur
        for (let i = 0; i < 3; i++) {
            // Ana buton
            const hexSlot = BABYLON.MeshBuilder.CreateCylinder(
                "hexSlot_" + i, 
                { height: 1, diameter: 5, tessellation: 6 },
                this.scene
            );
            hexSlot.parent = slotParent;
            hexSlot.position.y = -i * 5;
            
            // Butonları hafif açılandır
            hexSlot.rotation.x = Math.PI / 2 - Math.PI / 12;
            hexSlot.rotation.y = -Math.PI / 18;
            
            hexSlot.material = slotMaterial.clone("slotMat_" + i);
            
            // Butonun üst kapağı (3D görünüm için)
            const hexCap = BABYLON.MeshBuilder.CreateCylinder(
                "hexCap_" + i, 
                { height: 0.2, diameter: 4.5, tessellation: 6 },
                this.scene
            );
            hexCap.parent = hexSlot;
            hexCap.position.y = 0.6;
            
            // Kapak için daha parlak materyal
            const capMaterial = slotMaterial.clone("capMat_" + i);
            capMaterial.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.2);
            hexCap.material = capMaterial;
            
            // Slot indeksini mesh'e ekle
            hexSlot.slotIndex = i;
            hexCap.slotIndex = i; // Kapağa da slot indeksi ekle
            
            // Tıklama olayını ekle (hem buton hem kapak için)
            const setupClickAction = (mesh) => {
                mesh.actionManager = new BABYLON.ActionManager(this.scene);
                mesh.actionManager.registerAction(
                    new BABYLON.ExecuteCodeAction(
                        BABYLON.ActionManager.OnPickTrigger,
                        (evt) => {
                            const clickedIndex = evt.source.slotIndex;
                            const targetMesh = this.slotMeshes[clickedIndex];
                            
                            // Tıklama animasyonu
                            const originalScale = targetMesh.scaling.clone();
                            const clickAnimation = new BABYLON.Animation(
                                "clickAnimation",
                                "scaling",
                                30,
                                BABYLON.Animation.ANIMATIONTYPE_VECTOR3
                            );
                            
                            const keys = [
                                { frame: 0, value: originalScale },
                                { frame: 5, value: originalScale.scale(0.8) },
                                { frame: 10, value: originalScale }
                            ];
                            
                            clickAnimation.setKeys(keys);
                            targetMesh.animations = [clickAnimation];
                            this.scene.beginAnimation(targetMesh, 0, 10, false);
                            
                            // Combo'yu ateşle
                            gameManager.goldbergController.fireCombo(clickedIndex);
                        }
                    )
                );
            };
            
            setupClickAction(hexSlot);
            setupClickAction(hexCap);
            
            this.slotMeshes.push(hexSlot);
            
            // Başlangıçta glow efekti EKLEME - sadece dolu slotlar için eklenecek
        }
        
        // UI'ı başlangıçta göster
        this.show();
        
        // Hover efekti için pointer gözlemcisi ekle
        this.scene.onPointerObservable.add((pointerInfo) => {
            if (pointerInfo.type === BABYLON.PointerEventTypes.POINTERMOVE) {
                const pickResult = this.scene.pick(
                    this.scene.pointerX, 
                    this.scene.pointerY,
                    (mesh) => {
                        // Hem butonları hem de kapakları kontrol et
                        return this.slotMeshes.includes(mesh) || 
                               (mesh.parent && this.slotMeshes.includes(mesh.parent));
                    }
                );
                
                // Tüm slotları normal haline getir
                this.slotMeshes.forEach(mesh => {
                    if (mesh.isPickable) {
                        mesh.scaling = new BABYLON.Vector3(1, 1, 1);
                    }
                });
                
                // Eğer bir slot veya kapak üzerindeyse, slotu büyüt
                if (pickResult.hit && pickResult.pickedMesh) {
                    let targetMesh;
                    
                    if (this.slotMeshes.includes(pickResult.pickedMesh)) {
                        // Doğrudan slot tıklandı
                        targetMesh = pickResult.pickedMesh;
                    } else if (pickResult.pickedMesh.parent && this.slotMeshes.includes(pickResult.pickedMesh.parent)) {
                        // Kapak tıklandı, parent'ı slot
                        targetMesh = pickResult.pickedMesh.parent;
                    }
                    
                    if (targetMesh && targetMesh.isPickable) {
                        targetMesh.scaling = new BABYLON.Vector3(1.1, 1.1, 1.1);
                    }
                }
            }
        });
        
        // Ekran boyutuna göre UI ölçeğini ayarla
        this.adjustUIScale();
        
        // Ekran boyutu değiştiğinde UI ölçeğini yeniden ayarla
        window.addEventListener('resize', () => {
            this.adjustUIScale();
        });
    }
    
updatePositionsForOrientation() {
    if (!this.uiParent) return;
    
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const isLandscape = width > height;
    
    if (isLandscape) {
        // Yatay ekran konumları
        this.uiParent.position = new BABYLON.Vector3(-1.1, -1.4, 10);
    } else {
        // Dikey ekran konumları
        this.uiParent.position = new BABYLON.Vector3(-0.8, -0.8, 10);
    }
}

adjustUIScale() {
    if (!this.uiParent) return;
    
    // Sabit bir ölçeklendirme faktörü kullan
    const baseScale = 0.1; // Bu değeri UI boyutuna göre ayarlayın
    
    this.uiParent.scaling = new BABYLON.Vector3(baseScale, baseScale, baseScale);
}

    updateAppearance(gameState) {
        if (!this.slotMeshes.length) return;
        
        const { unlockedSlots, storedCombos, comboSequence } = gameState;
        const hexColors = this.scene.metadata.hexColors;
        const glowLayer = this.scene.getGlowLayerByName("glow");
        
        // Slotların görünümünü güncelle
        this.slotMeshes.forEach((slotMesh, index) => {
            const comboInSlot = storedCombos[index];
            
            // Slot butonunun kapağını bul
            const capMesh = slotMesh.getChildren()[0];
            
            // Önce glow'u kaldır
            if (glowLayer) {
                glowLayer.removeIncludedOnlyMesh(slotMesh);
                if (capMesh) glowLayer.removeIncludedOnlyMesh(capMesh);
            }
            
            if (index < unlockedSlots) {
                // Açık slot
                slotMesh.isPickable = true;
                slotMesh.isVisible = true;
                
                if (comboInSlot) {
                    // Dolu slot
                    const color = hexColors[comboInSlot];
                    
                    // Ana buton
                    slotMesh.material.albedoColor = color.diffuseColor.scale(0.7);
                    slotMesh.material.emissiveColor = color.emissiveColor.scale(0.5);
                    slotMesh.material.alpha = 0.8;
                    
                    // Kapak
                    if (capMesh) {
                        capMesh.material.albedoColor = color.diffuseColor.scale(0.9);
                        capMesh.material.emissiveColor = color.emissiveColor.scale(0.7);
                        capMesh.material.alpha = 0.9;
                    }
                    
                    // Sadece dolu slotlara glow efekti ekle
                    if (glowLayer) {
                        glowLayer.addIncludedOnlyMesh(slotMesh);
                        if (capMesh) glowLayer.addIncludedOnlyMesh(capMesh);
                    }
                } else {
                    // Boş slot
                    slotMesh.material.albedoColor = new BABYLON.Color3(0.3, 0.3, 0.3);
                    slotMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    slotMesh.material.alpha = 0.6;
                    
                    // Kapak
                    if (capMesh) {
                        capMesh.material.albedoColor = new BABYLON.Color3(0.4, 0.4, 0.4);
                        capMesh.material.emissiveColor = new BABYLON.Color3(0.15, 0.15, 0.15);
                        capMesh.material.alpha = 0.7;
                    }
                }
            } else {
                // Kilitli slot
                slotMesh.isPickable = false;
                slotMesh.isVisible = true;
                slotMesh.material.albedoColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                slotMesh.material.emissiveColor = new BABYLON.Color3(0.05, 0.05, 0.05);
                slotMesh.material.alpha = 0.3;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = new BABYLON.Color3(0.15, 0.15, 0.15);
                    capMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    capMesh.material.alpha = 0.4;
                }
            }
        });
        
        // Göstergenin görünümünü güncelle
        this.indicatorMeshes.forEach((mesh, index) => {
            const colorName = comboSequence[index];
            const capMesh = mesh.getChildren()[0]; // İndikatör kapağı
            
            if (colorName) {
                mesh.isVisible = true;
                const color = hexColors[colorName];
                
                // Ana indikatör
                mesh.material.albedoColor = color.diffuseColor.scale(0.6);
                mesh.material.emissiveColor = color.emissiveColor.scale(1.0);
                mesh.material.alpha = 0.7;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = color.diffuseColor.scale(0.8);
                    capMesh.material.emissiveColor = color.emissiveColor.scale(1.2);
                    capMesh.material.alpha = 0.8;
                }
            } else {
                // Boş gösterge
                mesh.isVisible = true;
                mesh.material.albedoColor = new BABYLON.Color3(0.2, 0.2, 0.2);
                mesh.material.emissiveColor = new BABYLON.Color3(0.05, 0.05, 0.05);
                mesh.material.alpha = 0.3;
                
                // Kapak
                if (capMesh) {
                    capMesh.material.albedoColor = new BABYLON.Color3(0.25, 0.25, 0.25);
                    capMesh.material.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
                    capMesh.material.alpha = 0.4;
                }
            }
        });
    }
    
    show() {
        if (this.uiParent) {
            this.uiParent.setEnabled(true);
        }
    }
    
    hide() {
        if (this.uiParent) {
            this.uiParent.setEnabled(false);
        }
    }
}


    class GoldbergController { 
        constructor(scene, movementController) { 
            this.scene = scene; 
            this.movementController = movementController; 
            this.currentGoldberg = null; 
            this.defaultMaterial = null; 
            this.glowLayer = null; 
            this.comboSequence = []; 
            this.storedCombos = [null, null, null]; 
            this.indicatorPanel = null; 
            this.unstableTimerUI = document.getElementById('unstable-timer'); 
            this.unstableTimeText = document.getElementById('unstable-time'); 
            this.isUnstable = false; 
            this.isInvincible = false; 
            this.unstableTimeout = null; 
            this.invincibilityTimeout = null; 
            this.unstableTimerInterval = null; 
            this.unstableAura = null; 
            this.speedMultiplier = 1.0;
        } 
        create() { 
            if (this.currentGoldberg) this.currentGoldberg.dispose(); 
            this.currentGoldberg = BABYLON.MeshBuilder.CreateGoldberg("goldberg", { m: 3, n: 0, size: 1.0 }, this.scene); 
            this.defaultMaterial = new BABYLON.StandardMaterial("goldbergMat", this.scene); 
            const color = new BABYLON.Color3(0.6, 0.8, 1); 
            this.defaultMaterial.diffuseColor = color; 
            this.defaultMaterial.emissiveColor = color.scale(0.3); 
            this.currentGoldberg.material = this.defaultMaterial; 
            this.glowLayer = new BABYLON.HighlightLayer("playerGlow", this.scene); 
            this.unstableAura = createUnstableAura(this.currentGoldberg, this.scene); 
            this.reset(); 
            return this.currentGoldberg; 
        } 
        reset() { 
            if (!this.currentGoldberg) return; 
            this.clearAllCombos(); 
            this.isUnstable = false; 
            this.isInvincible = false; 
            clearTimeout(this.unstableTimeout); 
            clearTimeout(this.invincibilityTimeout); 
            clearInterval(this.unstableTimerInterval); 
            if(this.unstableTimerUI) this.unstableTimerUI.style.display = 'none'; 
            this.currentGoldberg.visibility = 1; 
            if (this.unstableAura) { this.unstableAura.stop(); } 
            this.currentGoldberg.position.copyFrom(GAME_CONSTANTS.PLAYER_START_POS); 
            this.currentGoldberg.rotationQuaternion = BABYLON.Quaternion.Identity(); 
            if (this.currentGoldberg.physicsImpostor) this.currentGoldberg.physicsImpostor.dispose(); 
            this.currentGoldberg.physicsImpostor = new BABYLON.PhysicsImpostor(this.currentGoldberg, BABYLON.PhysicsImpostor.SphereImpostor, { mass: 0.5, restitution: 0.1, friction: 0.9 }, this.scene); 
            this.currentGoldberg.physicsImpostor.setLinearVelocity(BABYLON.Vector3.Zero()); 
            this.currentGoldberg.physicsImpostor.setAngularVelocity(BABYLON.Vector3.Zero()); 
        } 
        handleHazardHit() { 
    if (this.isInvincible) return; 
    if (this.isUnstable) { 
        if (this.unstableAura) this.unstableAura.stop(); 
        if (this.currentGoldberg) this.currentGoldberg.dispose(); 
        // gameManager.endGame'deki "laser" sebebini "hazard" gibi daha genel bir şeye çevirebiliriz. 
        gameManager.endGame(false, "hazard");  
        return; 
    } 
            this.isUnstable = true; 
            if (this.unstableAura) { this.unstableAura.start(); } 
            this.unstableTimerUI.style.display = 'flex'; 
            const endTime = Date.now() + GAME_CONSTANTS.UNSTABLE_DEBUFF_DURATION; 
            this.unstableTimerInterval = setInterval(() => { 
                const remaining = Math.max(0, endTime - Date.now()); 
                this.unstableTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`; 
            }, 100);      

     this.unstableTimeout = setTimeout(() => { 
                this.isUnstable = false; 
                if (this.unstableAura) { this.unstableAura.stop(); } 
                clearInterval(this.unstableTimerInterval); 
                this.unstableTimerUI.style.display = 'none'; 
            }, GAME_CONSTANTS.UNSTABLE_DEBUFF_DURATION); 
            this.isInvincible = true; 
            const invincibilityInterval = setInterval(() => { 
                if (this.currentGoldberg) this.currentGoldberg.visibility = this.currentGoldberg.visibility === 1 ? 0.5 : 1; 
            }, 150); 
            this.invincibilityTimeout = setTimeout(() => { 
                this.isInvincible = false; 
                clearInterval(invincibilityInterval); 
                if (this.currentGoldberg) this.currentGoldberg.visibility = 1; 
            }, GAME_CONSTANTS.INVINCIBILITY_DURATION); 
        } 


   chargeCombo(colorName) {
        // 1. Rengi sıraya ve görsel göstergeye ekle
        this.comboSequence.push(colorName);
        
        // 2. Eğer sıra 3'ten uzunsa, en eskisini at
        if (this.comboSequence.length > 3) {
            this.comboSequence.shift();
        }
        
        // 3. Eğer 3 renk olduysa, kombo kontrolü yap
        if (this.comboSequence.length === 3) {
            const [c1, c2, c3] = this.comboSequence;
            if (c1 === c2 && c2 === c3) {
                // Kombo başarılı! Boş bir slot bul ve doldur.
                this.storeReadyCombo(c1);
            }
        }
        
        // UI'ı güncelle
        gameManager.requestUIUpdate();
    }

        activateGlow() { 
            const hexColors = this.scene.metadata.hexColors; 
            this.currentGoldberg.material = hexColors[this.comboReadyColor]; 
            this.glowLayer.addMesh(this.currentGoldberg, hexColors[this.comboReadyColor].emissiveColor.scale(2)); 
        const slotButton = gameManager.ui.comboSlotButtons[0]; // Şimdilik ilk slot
        if(slotButton) {
            slotButton.background = hexColors[this.comboReadyColor].emissiveColor.toHexString();
            slotButton.isEnabled = true; // Tıklanabilir yap
        }
        } 

    updateVisualIndicator() {
        if (!this.indicatorPanel) return;

        // Önce paneli temizle
        [...this.indicatorPanel.children].forEach(child => this.indicatorPanel.removeControl(child));

        // Sonra mevcut sıraya göre yeniden doldur
        this.comboSequence.forEach(colorName => {
            const indicatorHex = new BABYLON.GUI.Button(); // Buton olarak yaparsak tıklanabilir olur ama şimdilik sadece görsel
            indicatorHex.width = "20px";
            indicatorHex.height = "23px";
            indicatorHex.thickness = 0;
            indicatorHex.background = this.scene.metadata.hexColors[colorName].emissiveColor.toHexString();
            // CSS'teki altıgen maskesini buna da uygulayabiliriz
            // indicatorHex.domElement.className = "hexagon-mask"; // Bu çalışmaz, PNG gerekir. Şimdilik kare kalabilir.
            indicatorHex.paddingLeft = "2px";
            indicatorHex.paddingRight = "2px";
            this.indicatorPanel.addControl(indicatorHex);
        });
    }

    storeReadyCombo(comboColor) {
        const emptySlotIndex = this.storedCombos.indexOf(null);
        if (emptySlotIndex !== -1) {
            this.storedCombos[emptySlotIndex] = comboColor;
            this.comboSequence = []; // Sırayı temizle
            gameManager.requestUIUpdate(); // UI'ı güncelle
        }
    }

fireCombo(slotIndex) {
    const comboColor = this.storedCombos[slotIndex];
    if (!comboColor) return;
    
    // Combo slotunu hemen boşalt
    this.storedCombos[slotIndex] = null;
    gameManager.requestUIUpdate();
    
    // Bazı combo'ların etkilerini hemen aktifleştir
    if (comboColor === 'em_blue') {
        this.activateShield(); // Kalkanı hemen aktifleştir
    } else if (comboColor === 'gravity_green') {
        this.activateSpeedBoost(); // Hız artışını hemen aktifleştir
    }
    
    // Sonra atış animasyonunu başlat
    this.fireComboProjectile(comboColor);
}


fireComboProjectile(comboColor) {
    const playerMesh = this.currentGoldberg;
    const centralPentagonMesh = gameManager.pentaTileController.mesh;
    
    // Küre yerine altıgen tile oluştur
    const projectile = BABYLON.MeshBuilder.CreateCylinder("comboTile", { 
        diameter: 2.0, 
        height: 0.5, 
        tessellation: 6 // 6 kenarlı (altıgen)
    }, this.scene);
    
    // Altıgen tile'ı doğru yönlendir (üst yüzey yukarı baksın)
    projectile.rotation.x = Math.PI / 2;
    
    projectile.material = this.scene.metadata.hexColors[comboColor];
    projectile.position = playerMesh.position.clone().add(new BABYLON.Vector3(0, 1, 0));
    
    // Renk bazlı özel efektler
    switch (comboColor) {
        case 'ice_blue':
            this.addIceEffects(projectile);
            break;
        case 'solar_orange':
            this.addFireEffects(projectile);
            break;
        case 'em_blue':
            this.addElectricEffects(projectile);
            break;
        case 'gravity_green':
            this.addGravityEffects(projectile);
            break;
        case 'dark_purple':
            this.addDarkEnergyEffects(projectile);
            break;
    }
    
    // Temel parçacık izi (tüm renkler için)
    const trailPS = new BABYLON.ParticleSystem("comboTrail", 2000, this.scene);
    trailPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    trailPS.emitter = projectile;
    trailPS.minEmitBox = new BABYLON.Vector3(-0.2, -0.2, -0.2);
    trailPS.maxEmitBox = new BABYLON.Vector3(0.2, 0.2, 0.2);
    trailPS.color1 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.2).toColor4(1);
    trailPS.color2 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(0.7).toColor4(1);
    trailPS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0);
    trailPS.minSize = 0.2;
    trailPS.maxSize = 0.5;
    trailPS.minLifeTime = 0.2;
    trailPS.maxLifeTime = 0.6;
    trailPS.emitRate = 400;
    trailPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    trailPS.gravity = new BABYLON.Vector3(0, 0, 0);
    trailPS.direction1 = new BABYLON.Vector3(-0.5, -0.5, -0.5);
    trailPS.direction2 = new BABYLON.Vector3(0.5, 0.5, 0.5);
    trailPS.minEmitPower = 0.5;
    trailPS.maxEmitPower = 1.5;
    trailPS.updateSpeed = 0.01;
    trailPS.targetStopDuration = 0.2;
    trailPS.disposeOnStop = true;
    trailPS.start();
    
    // Animasyon
    const frameRate = 60;
    const animDuration = frameRate * 1.2;
    
    const positionAnim = new BABYLON.Animation("comboAnim", "position", frameRate, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
    
    // Yüksek kavis
    const midPoint = BABYLON.Vector3.Lerp(projectile.position, centralPentagonMesh.getAbsolutePosition(), 0.5);
    midPoint.y += 8;
    
    positionAnim.setKeys([
        { frame: 0, value: projectile.position },
        { frame: animDuration / 2, value: midPoint },
        { frame: animDuration, value: centralPentagonMesh.getAbsolutePosition() }
    ]);
    
    // Dönme animasyonu - altıgen için daha uygun bir dönme
    const rotationAnim = new BABYLON.Animation("rotateAnim", "rotation.y", frameRate, BABYLON.Animation.ANIMATIONTYPE_FLOAT);
    rotationAnim.setKeys([
        { frame: 0, value: projectile.rotation.y },
        { frame: animDuration, value: projectile.rotation.y + Math.PI * 4 } // 2 tam tur dön
    ]);
    
    // Animasyonu başlat
    const animatable = this.scene.beginDirectAnimation(projectile, [positionAnim, rotationAnim], 0, animDuration, false);
    
    // Animasyon bittiğinde
    animatable.onAnimationEnd = () => {
        // Çarpışma efekti
        this.createComboImpactEffect(projectile.position, comboColor);
        
        // Renk bazlı özel yetenekler
        switch (comboColor) {
            case 'ice_blue':
                // Penta Tile mekaniklerini interrupt et
                this.interruptPentaMechanics();
                break;
                
            case 'solar_orange':
                // Güçlü vuruş: 9 tile etkisi
                this.createSolarImpact(projectile.position);
                
                // 9 tile vuruş etkisi (normal 6 yerine)
                for (let i = 0; i < 3; i++) { // 3 ekstra vuruş
                    gameManager.pentaTileController.takeHit(false);
                }
                break;
                
            case 'em_blue':
                // Kalkan koruması
                this.activateShield();
                break;
                
            case 'gravity_green':
                // Hareket hızını artır
                this.activateSpeedBoost();
                break;
                
            case 'dark_purple':
                // Çekim alanı
                this.activateAttractionField();
                break;
        }
        
        // Penta Tile'a hasar ver (tüm renkler için temel hasar)
        const isWin = gameManager.pentaTileController.takeHit(true);
        gameManager.updateHUD();
        
        // Mermiyi temizle
        projectile.dispose();
        
        if (isWin) gameManager.endGame(true);
    };
}

createComboImpactEffect(position, comboColor) {
    // Temel patlama parçacıkları
    const explosionPS = new BABYLON.ParticleSystem("comboExplosion", 1000, this.scene);
    explosionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    explosionPS.emitter = position;
    explosionPS.minEmitBox = new BABYLON.Vector3(-0.2, -0.2, -0.2);
    explosionPS.maxEmitBox = new BABYLON.Vector3(0.2, 0.2, 0.2);
    explosionPS.color1 = this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.5).toColor4(1);
    explosionPS.color2 = this.scene.metadata.hexColors[comboColor].diffuseColor.toColor4(1);
    explosionPS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0);
    explosionPS.minSize = 0.3;
    explosionPS.maxSize = 0.8;
    explosionPS.minLifeTime = 0.3;
    explosionPS.maxLifeTime = 0.8;
    explosionPS.emitRate = 1000;
    explosionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    explosionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    explosionPS.direction1 = new BABYLON.Vector3(-2, 0, -2);
    explosionPS.direction2 = new BABYLON.Vector3(2, 2, 2);
    explosionPS.minEmitPower = 1;
    explosionPS.maxEmitPower = 3;
    explosionPS.updateSpeed = 0.01;
    explosionPS.targetStopDuration = 0.3;
    explosionPS.disposeOnStop = true;
    explosionPS.start();
    
    // Dalgalı halka efekti
    const ringMesh = BABYLON.MeshBuilder.CreateDisc("impactRing", {radius: 0.1, tessellation: 36}, this.scene);
    ringMesh.position = position.clone();
    ringMesh.rotation.x = Math.PI / 2;
    
    const ringMat = new BABYLON.StandardMaterial("ringMat", this.scene);
    ringMat.emissiveColor = this.scene.metadata.hexColors[comboColor].emissiveColor.scale(2);
    ringMat.disableLighting = true;
    ringMat.alpha = 0.7;
    ringMesh.material = ringMat;
    
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(ringMesh);
    
    // Halkanın büyüme ve kaybolma animasyonu
    const ringScaleAnim = new BABYLON.Animation("ringScale", "scaling", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
    ringScaleAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 30, value: new BABYLON.Vector3(15, 15, 15) }
    ]);
    
    const ringAlphaAnim = new BABYLON.Animation("ringAlpha", "material.alpha", 60, BABYLON.Animation.ANIMATIONTYPE_FLOAT);
    ringAlphaAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 30, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(ringMesh, [ringScaleAnim, ringAlphaAnim], 0, 30, false, 1, () => {
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(ringMesh);
        ringMesh.dispose();
    });
    
    // Penta Tile'da parlama efekti
    const pentaTile = gameManager.pentaTileController.mesh;
    const flash = new BABYLON.HighlightLayer("comboFlash", this.scene);
    flash.addMesh(pentaTile, this.scene.metadata.hexColors[comboColor].diffuseColor.scale(1.5));
    
    // Parlama efektini kademeli olarak kaldır
    setTimeout(() => {
        flash.dispose();
    }, 500);
}


    clearAllCombos() {
        this.comboSequence = [];
        this.storedCombos = [null, null, null];
        if (gameManager) {
            gameManager.requestUIUpdate();
        }
    }

update() {
    if (!this.currentGoldberg || !this.currentGoldberg.physicsImpostor) return;

    // Temel hız ve maksimum hız
    const baseSpeed = 8; // Bu değeri ayarlayarak oyuncunun temel hızını belirleyin.
    const maxVelocity = 12;

    // Joystick'ten gelen girdiyi al
    let inputX = this.movementController.xVelocity;
    let inputZ = this.movementController.zVelocity;

    // Klavye girdilerini de aynı şekilde al (eğer kullanılıyorsa)
    if (this.movementController.moveDirections.forward) { inputZ = 1; }
    if (this.movementController.moveDirections.backward) { inputZ = -1; }
    if (this.movementController.moveDirections.left) { inputX = -1; }
    if (this.movementController.moveDirections.right) { inputX = 1; }

    // Girdi vektörünü oluştur ve normalize et (köşegen hareketin daha hızlı olmasını engellemek için)
    const inputVector = new BABYLON.Vector3(inputX, 0, inputZ);
    if (inputVector.length() > 0) {
        inputVector.normalize();
    }

    // Son hızı hesapla (temel hız * çarpan)
    const finalSpeed = baseSpeed * this.speedMultiplier;

    // Yeni hızı ayarla
    const currentVelocity = this.currentGoldberg.physicsImpostor.getLinearVelocity();
    const newVelocity = new BABYLON.Vector3(
        inputVector.x * finalSpeed,
        currentVelocity.y, // Y eksenindeki hızı (zıplama/düşme) koru
        inputVector.z * finalSpeed
    );

    // Maksimum hızı uygula
    if (newVelocity.length() > maxVelocity * this.speedMultiplier) {
        newVelocity.normalize().scaleInPlace(maxVelocity * this.speedMultiplier);
    }

    this.currentGoldberg.physicsImpostor.setLinearVelocity(newVelocity);
}

 
showNotification(message, color) {
    // Bildirim elementi
    const notification = document.createElement('div');
    notification.style.position = 'absolute';
    notification.style.top = '100px';
    notification.style.left = '50%';
    notification.style.transform = 'translateX(-50%)';
    notification.style.backgroundColor = `rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 0.2)`;
    notification.style.border = `2px solid rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 0.7)`;
    notification.style.color = 'white';
    notification.style.padding = '10px 20px';
    notification.style.borderRadius = '8px';
    notification.style.fontFamily = "'Segoe UI', sans-serif";
    notification.style.fontSize = '1.2rem';
    notification.style.fontWeight = 'bold';
    notification.style.textShadow = `0 0 5px rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 1.0)`;
    notification.style.zIndex = '1000';
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s ease-in-out';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Bildirim animasyonu
    setTimeout(() => {
        notification.style.opacity = '1';
        
        setTimeout(() => {
            notification.style.opacity = '0';
            
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 2000);
    }, 0);
}

// Kamera titreşimi
shakeCamera(intensity, duration) {
    const camera = this.scene.activeCamera;
    const originalPosition = camera.position.clone();
    
    let shakeIntensity = intensity || 0.3;
    const shakeInterval = setInterval(() => {
        if (shakeIntensity <= 0.01) {
            clearInterval(shakeInterval);
            camera.position = originalPosition;
            return;
        }
        
        camera.position = originalPosition.add(
            new BABYLON.Vector3(
                (Math.random() - 0.5) * shakeIntensity,
                (Math.random() - 0.5) * shakeIntensity,
                (Math.random() - 0.5) * shakeIntensity
            )
        );
        
        shakeIntensity *= 0.85; // Titreşim giderek azalır
    }, 16); // ~60fps
    
    setTimeout(() => {
        clearInterval(shakeInterval);
        camera.position = originalPosition;
    }, duration || 500);
}

// 1. Buz Efektleri
addIceEffects(projectile) {
    // Buz materyali
    const iceMat = new BABYLON.PBRMaterial("iceMat", this.scene);
    iceMat.albedoColor = new BABYLON.Color3(0.8, 0.9, 1.0);
    iceMat.metallic = 0.1;
    iceMat.roughness = 0.1;
    iceMat.alpha = 0.8;
    projectile.material = iceMat;
    
    // Buz kristalleri - altıgenin kenarlarında
    const crystalCount = 6; // Altıgenin 6 kenarı
    for (let i = 0; i < crystalCount; i++) {
        const crystal = BABYLON.MeshBuilder.CreatePolyhedron("iceFragment", {
            type: 3, // Oktahedron
            size: 0.3
        }, this.scene);
        
       // Kristal materyali (daha parlak)
        const crystalMat = new BABYLON.StandardMaterial("iceCrystalMat" + i, this.scene);
        crystalMat.diffuseColor = new BABYLON.Color3(0.8, 0.95, 1.0);
        crystalMat.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0); // Parlaklık
        crystalMat.alpha = 0.8;
        crystal.material = crystalMat;
        
        // Kristalleri altıgenin kenarlarına yerleştir
        crystal.parent = projectile;
        
        // Altıgenin kenarlarına yerleştir
        const angle = (i / crystalCount) * Math.PI * 2;
        const radius = 1.0; // Altıgenin yarıçapı
        crystal.position.x = Math.cos(angle) * radius;
        crystal.position.z = Math.sin(angle) * radius;
        crystal.position.y = 0.3; // Altıgenin üstünde
        
        // Glow efekti
        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(crystal);
    }
    
    // Buz parçacıkları
    const icePS = new BABYLON.ParticleSystem("iceParticles", 600, this.scene);
    icePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    icePS.emitter = projectile;
    icePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    icePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    icePS.color1 = new BABYLON.Color4(0.8, 0.9, 1.0, 1.0);
    icePS.color2 = new BABYLON.Color4(0.5, 0.8, 1.0, 1.0);
    icePS.colorDead = new BABYLON.Color4(0.5, 0.8, 1.0, 0.0);
    icePS.minSize = 0.1;
    icePS.maxSize = 0.3;
    icePS.minLifeTime = 0.2;
    icePS.maxLifeTime = 0.6;
    icePS.emitRate = 300;
    icePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    icePS.gravity = new BABYLON.Vector3(0, -0.1, 0);
    icePS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    icePS.direction2 = new BABYLON.Vector3(1, 1, 1);
    icePS.minEmitPower = 0.5;
    icePS.maxEmitPower = 1.5;
    icePS.start();
    
    // Mermi yok edildiğinde parçacıkları da temizle
    projectile.onDisposeObservable.add(() => {
        icePS.dispose();
    });
}

interruptPentaMechanics() {
    let wasInterrupted = false;
    let interruptedMechanic = null;

    // 1. İptal edilecek mekaniği bul
    for (const mechanic of gameManager.activeMechanics) {
        if (mechanic.isWarmingUp || mechanic.isActive) {
            interruptedMechanic = mechanic;
            break; // Sadece bir mekaniği interrupt edebiliriz, ilk bulduğumuzda döngüden çık.
        }
    }

    // Eğer iptal edilecek bir mekanik bulunduysa...
    if (interruptedMechanic) {
        wasInterrupted = true;
        console.log(`Interrupting and CANCELLING mechanic: ${interruptedMechanic.constructor.name}`);

        // 2. MEKANİĞİ TAMAMEN DURDUR VE TEMİZLE
        // Kendi iç zamanlayıcılarını ve durumlarını temizle.
        if (interruptedMechanic.warningInterval) {
            clearInterval(interruptedMechanic.warningInterval);
            interruptedMechanic.warningInterval = null;
        }
        if (interruptedMechanic.activationTimeout) {
            clearTimeout(interruptedMechanic.activationTimeout);
            interruptedMechanic.activationTimeout = null;
        }
        if (interruptedMechanic.spawnerInterval) {
            clearInterval(interruptedMechanic.spawnerInterval);
            interruptedMechanic.spawnerInterval = null;
        }

        // Mekaniği "deaktif" duruma getirerek tüm görsel efektlerini temizlemesini sağla.
        interruptedMechanic.deactivate();

        // Durum bayraklarını (flag) manuel olarak sıfırla.
        interruptedMechanic.isWarmingUp = false;
        interruptedMechanic.isActive = false;

        // Penta Tile materyalini orijinal haline getir.
        gameManager.pentaTileController.resetMaterial();

        // 3. OYUN YÖNETİCİSİNİN SIRASINI İLERLET (EN KRİTİK ADIM)
        // Bu, mekaniğin "ertelenmesini" değil, "iptal edilmesini" sağlar.
        
        // Eğer oyun çoklu mekanik aşamasındaysa, sıradaki mekaniğe geç.
        if (gameManager.state.isMultiMechanicStage) {
            gameManager.state.eventIndex = (gameManager.state.eventIndex + 1) % gameManager.state.eventQueue.length;
            console.log(`Event index advanced. Next mechanic will be: ${gameManager.state.eventQueue[gameManager.state.eventIndex].constructor.name}`);
        }

        // Hem çoklu aşama hem de sonsuz mod için, bir sonraki olaya kadar oyuncuya zaman ver.
        if (gameManager.state.isMultiMechanicStage || gameManager.state.isEndlessMode) {
            gameManager.state.nextEventTimer = 8 + Math.random() * 4; // 8-12 saniye sonra yeni mekanik gelsin.
            console.log(`Next event timer reset. New event in ${gameManager.state.nextEventTimer.toFixed(1)}s`);
        }
        
        // 4. GÖRSEL EFEKTLERİ GÖSTER
        this.createFreezeEffect(gameManager.pentaTileController.mesh);
        this.showNotification("MEKANİK İPTAL EDİLDİ!", new BABYLON.Color3(0.4, 0.8, 1.0));
    }
}

// Donma efekti - Buz mavisi renginde
// GoldbergController sınıfına ekleyin
createFreezeEffect(targetMesh) {
    // Orijinal materyali sakla
    const originalMaterial = targetMesh.material;
    
    // Donma materyali (daha parlak)
    const freezeMaterial = new BABYLON.StandardMaterial("freezeMat", this.scene);
    freezeMaterial.diffuseColor = new BABYLON.Color3(0.6, 0.8, 1.0);
    freezeMaterial.emissiveColor = new BABYLON.Color3(0.3, 0.5, 0.8); // Parlaklık
    freezeMaterial.alpha = 0.95;
    freezeMaterial.specularPower = 128;
    targetMesh.material = freezeMaterial;   

 // Buz kristalleri
    const crystalParent = new BABYLON.TransformNode("crystalParent", this.scene);
    crystalParent.position = targetMesh.position.clone();

    for (let i = 0; i < 8; i++) {
        const crystal = BABYLON.MeshBuilder.CreatePolyhedron("freezeCrystalEffect" + i, { type: 3, size: 0.8 + Math.random() * 0.5 }, this.scene);

        // Kristal materyali (daha parlak)
        const crystalMat = new BABYLON.StandardMaterial("freezeCrystalEffectMat" + i, this.scene);
        crystalMat.diffuseColor = new BABYLON.Color3(0.8, 0.95, 1.0);
        crystalMat.emissiveColor = new BABYLON.Color3(0.6, 0.85, 1.0); // Yüksek parlaklık
        crystalMat.alpha = 0.8;
        crystal.material = crystalMat;
        
        crystal.parent = crystalParent;
        
        // Rastgele pozisyon
        const angle = Math.random() * Math.PI * 2;
        const radius = 3 + Math.random() * 2;
        const height = Math.random() * 3;
        
        crystal.position.x = Math.cos(angle) * radius;
        crystal.position.z = Math.sin(angle) * radius;
        crystal.position.y = height;
        
        // Rastgele rotasyon
        crystal.rotation = new BABYLON.Vector3(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        
        // Glow efekti
        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(crystal);
    }
    
    // Buz buğusu
    const frostPS = new BABYLON.ParticleSystem("frostPS", 1000, this.scene);
    frostPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    frostPS.emitter = targetMesh.position;
    frostPS.minEmitBox = new BABYLON.Vector3(-3, 0, -3);
    frostPS.maxEmitBox = new BABYLON.Vector3(3, 3, 3);
    frostPS.color1 = new BABYLON.Color4(0.7, 0.8, 1.0, 0.2); // Buz mavisi
    frostPS.color2 = new BABYLON.Color4(0.5, 0.7, 1.0, 0.2); // Buz mavisi
    frostPS.colorDead = new BABYLON.Color4(0.4, 0.6, 1.0, 0.0); // Buz mavisi
    frostPS.minSize = 0.3;
    frostPS.maxSize = 0.8;
    frostPS.minLifeTime = 1.0;
    frostPS.maxLifeTime = 2.0;
    frostPS.emitRate = 300;
    frostPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ADD;
    frostPS.gravity = new BABYLON.Vector3(0, 0.05, 0);
    frostPS.minEmitPower = 0.2;
    frostPS.maxEmitPower = 0.5;
    frostPS.start();
    
    // 3 saniye sonra efekti kaldır
    setTimeout(() => {
        targetMesh.material = originalMaterial;
        crystalParent.dispose();
        frostPS.stop();
    }, 3000);
}


// Alev efektleri ekle
addFireEffects(projectile) {
    // Alev materyali
    const fireMat = new BABYLON.StandardMaterial("fireMat", this.scene);
    fireMat.diffuseColor = new BABYLON.Color3(1.0, 0.3, 0.0);
    fireMat.emissiveColor = new BABYLON.Color3(0.8, 0.2, 0.0);
    projectile.material = fireMat;
    
    // Alev parçacıkları
    const firePS = new BABYLON.ParticleSystem("fireParticles", 1000, this.scene);
    firePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    firePS.emitter = projectile;
    firePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    firePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    firePS.color1 = new BABYLON.Color4(1.0, 0.5, 0.0, 1.0);
    firePS.color2 = new BABYLON.Color4(1.0, 0.2, 0.0, 1.0);
    firePS.colorDead = new BABYLON.Color4(0.5, 0.0, 0.0, 0.0);
    firePS.minSize = 0.3;
    firePS.maxSize = 0.8;
    firePS.minLifeTime = 0.1;
    firePS.maxLifeTime = 0.3;
    firePS.emitRate = 600;
    firePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    firePS.gravity = new BABYLON.Vector3(0, 0, 0);
    firePS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    firePS.direction2 = new BABYLON.Vector3(1, 1, 1);
    firePS.minEmitPower = 1;
    firePS.maxEmitPower = 3;
    firePS.updateSpeed = 0.01;
    firePS.start();
    
    // Duman parçacıkları
    const smokePS = new BABYLON.ParticleSystem("smokeParticles", 300, this.scene);
    smokePS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    smokePS.emitter = projectile;
    smokePS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    smokePS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    smokePS.color1 = new BABYLON.Color4(0.3, 0.3, 0.3, 0.4);
    smokePS.color2 = new BABYLON.Color4(0.2, 0.2, 0.2, 0.3);
    smokePS.colorDead = new BABYLON.Color4(0.1, 0.1, 0.1, 0.0);
    smokePS.minSize = 0.5;
    smokePS.maxSize = 1.0;
    smokePS.minLifeTime = 0.5;
    smokePS.maxLifeTime = 1.0;
    smokePS.emitRate = 200;
    smokePS.blendMode = BABYLON.ParticleSystem.BLENDMODE_STANDARD;
    smokePS.gravity = new BABYLON.Vector3(0, 0.5, 0);
    smokePS.minEmitPower = 0.5;
    smokePS.maxEmitPower = 1.5;
    smokePS.start();
    
    // Işık efekti
    const light = new BABYLON.PointLight("fireLight", BABYLON.Vector3.Zero(), this.scene);
    light.parent = projectile;
    light.diffuse = new BABYLON.Color3(1, 0.5, 0);
    light.intensity = 1.5;
    light.range = 10;
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        firePS.dispose();
        smokePS.dispose();
        light.dispose();
    });
}

// Solar çarpışma efekti
createSolarImpact(position) {
    // Büyük patlama dalgası
    const explosionPS = new BABYLON.ParticleSystem("solarExplosion", 3000, this.scene);
    explosionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    explosionPS.emitter = position;
    explosionPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.5, -0.5);
    explosionPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.5, 0.5);
    explosionPS.color1 = new BABYLON.Color4(1.0, 0.5, 0.0, 1.0);
    explosionPS.color2 = new BABYLON.Color4(1.0, 0.2, 0.0, 1.0);
    explosionPS.colorDead = new BABYLON.Color4(0.5, 0.0, 0.0, 0.0);
    explosionPS.minSize = 0.5;
    explosionPS.maxSize = 1.5;
    explosionPS.minLifeTime = 0.3;
    explosionPS.maxLifeTime = 0.8;
    explosionPS.emitRate = 3000;
    explosionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    explosionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    explosionPS.direction1 = new BABYLON.Vector3(-5, -5, -5);
    explosionPS.direction2 = new BABYLON.Vector3(5, 5, 5);
    explosionPS.minEmitPower = 3;
    explosionPS.maxEmitPower = 8;
    explosionPS.updateSpeed = 0.01;
    explosionPS.targetStopDuration = 0.2;
    explosionPS.disposeOnStop = true;
    explosionPS.start();
    
    // Şok dalgası
    const shockwave = BABYLON.MeshBuilder.CreateDisc("shockwave", {
        radius: 0.1,
        tessellation: 64
    }, this.scene);
    
    shockwave.position = position.clone();
    shockwave.rotation.x = Math.PI / 2;
    
    const shockwaveMat = new BABYLON.StandardMaterial("shockwaveMat", this.scene);
    shockwaveMat.emissiveColor = new BABYLON.Color3(1.0, 0.5, 0.0);
    shockwaveMat.diffuseColor = new BABYLON.Color3(1.0, 0.3, 0.0);
    shockwaveMat.alpha = 0.7;
    shockwaveMat.disableLighting = true;
    shockwave.material = shockwaveMat;
    
    // Şok dalgası animasyonu
    const shockwaveAnim = new BABYLON.Animation(
        "shockwaveAnim",
        "scaling",
        60,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    shockwaveAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 30, value: new BABYLON.Vector3(30, 30, 1) }
    ]);
    
    const shockwaveAlphaAnim = new BABYLON.Animation(
        "shockwaveAlphaAnim",
        "material.alpha",
        60,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    shockwaveAlphaAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 30, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(shockwave, [shockwaveAnim, shockwaveAlphaAnim], 0, 30, false, 1, () => {
        shockwave.dispose();
    });
    
    // Ekrana bildirim
    this.showNotification("GÜÇLÜ VURUŞ! +3 HASAR", new BABYLON.Color3(1.0, 0.5, 0.0));
    
    // Ekran titreşimi
    this.shakeCamera(0.5, 500);
}

// Elektrik efektleri ekle
addElectricEffects(projectile) {
    // Elektrik materyali
    const electricMat = new BABYLON.StandardMaterial("electricMat", this.scene);
    electricMat.diffuseColor = new BABYLON.Color3(0.3, 0.3, 1.0);
    electricMat.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.8);
    projectile.material = electricMat;
    
    // Elektrik parçacıkları
    const electricPS = new BABYLON.ParticleSystem("electricParticles", 800, this.scene);
    electricPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    electricPS.emitter = projectile;
    electricPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    electricPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    electricPS.color1 = new BABYLON.Color4(0.4, 0.4, 1.0, 1.0);
    electricPS.color2 = new BABYLON.Color4(0.6, 0.6, 1.0, 1.0);
    electricPS.colorDead = new BABYLON.Color4(0.3, 0.3, 0.8, 0.0);
    electricPS.minSize = 0.1;
    electricPS.maxSize = 0.3;
    electricPS.minLifeTime = 0.05;
    electricPS.maxLifeTime = 0.2;
    electricPS.emitRate = 400;
    electricPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    electricPS.gravity = new BABYLON.Vector3(0, 0, 0);
    electricPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    electricPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    electricPS.minEmitPower = 1;
    electricPS.maxEmitPower = 3;
    electricPS.updateSpeed = 0.01;
    electricPS.start();
    
    // Sürekli şimşek arkları oluştur
    const createLightningArcs = () => {
        if (projectile.isDisposed()) return;
        
        // Altıgenin kenarlarından şimşekler
        const arcCount = 2 + Math.floor(Math.random() * 2); // 2-3 ark
        
        for (let i = 0; i < arcCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const radius = 1.0; // Altıgenin yarıçapı
            
            const startPoint = new BABYLON.Vector3(
                projectile.position.x + Math.cos(angle) * radius,
                projectile.position.y,
                projectile.position.z + Math.sin(angle) * radius
            );
            
            const endAngle = angle + (Math.random() * Math.PI / 2 - Math.PI / 4);
            const endDistance = 1.5 + Math.random() * 1.5;
            
            const endPoint = new BABYLON.Vector3(
                startPoint.x + Math.cos(endAngle) * endDistance,
                startPoint.y + (Math.random() - 0.5) * endDistance,
                startPoint.z + Math.sin(endAngle) * endDistance
            );
            
            const arcPoints = generateFractalLightning(startPoint, endPoint, 0.5, 0.1);
            const arc = BABYLON.MeshBuilder.CreateTube("electricArc", {
                path: arcPoints,
                radius: 0.05,
                updatable: false
            }, this.scene);
            
            const arcMat = new BABYLON.StandardMaterial("arcMat", this.scene);
            arcMat.emissiveColor = new BABYLON.Color3(0.6, 0.6, 1.0);
            arcMat.disableLighting = true;
            arc.material = arcMat;
            
            // Glow efekti
            const glowLayer = this.scene.getGlowLayerByName("glow");
            if (glowLayer) glowLayer.addIncludedOnlyMesh(arc);
            
            // Kısa süre sonra arkı yok et
            setTimeout(() => {
                if (glowLayer) glowLayer.removeIncludedOnlyMesh(arc);
                arc.dispose();
            }, 100 + Math.random() * 100);
        }
        
        // Yeni arklar oluşturmaya devam et
        setTimeout(createLightningArcs, 100 + Math.random() * 150);
    };
    
    createLightningArcs();
    
    // Işık efekti
    const light = new BABYLON.PointLight("electricLight", BABYLON.Vector3.Zero(), this.scene);
    light.parent = projectile;
    light.diffuse = new BABYLON.Color3(0.4, 0.4, 1.0);
    light.intensity = 1.5;
    light.range = 10;
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        electricPS.dispose();
        light.dispose();
    });
}


// Kalkan aktivasyonu (devam)
activateShield() {
    // Kalkan süresi
    const shieldDuration = 5000; // 5 saniye
    
    // Kalkan mesh'i
    const shield = BABYLON.MeshBuilder.CreateSphere("shield", {
        diameter: 4,
        segments: 16
    }, this.scene);
    
    // Kalkan materyali
    const shieldMat = new BABYLON.StandardMaterial("shieldMat", this.scene);
    shieldMat.diffuseColor = new BABYLON.Color3(0.4, 0.4, 1.0);
    shieldMat.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.8);
    shieldMat.alpha = 0.3;
    shield.material = shieldMat;
    
    // Kalkanı oyuncuya bağla
    shield.parent = this.currentGoldberg;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(shield);
    
    // Kalkan dalgalanma animasyonu
    const pulseAnim = new BABYLON.Animation(
        "shieldPulse",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    pulseAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(shield, 0, 30, true);
    
    // Elektrik parçacıkları
    const shieldPS = new BABYLON.ParticleSystem("shieldParticles", 200, this.scene);
    shieldPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    shieldPS.emitter = shield;
    shieldPS.minEmitBox = new BABYLON.Vector3(-1.5, -1.5, -1.5);
    shieldPS.maxEmitBox = new BABYLON.Vector3(1.5, 1.5, 1.5);
    shieldPS.color1 = new BABYLON.Color4(0.4, 0.4, 1.0, 1.0);
    shieldPS.color2 = new BABYLON.Color4(0.6, 0.6, 1.0, 1.0);
    shieldPS.colorDead = new BABYLON.Color4(0.3, 0.3, 0.8, 0.0);
    shieldPS.minSize = 0.1;
    shieldPS.maxSize = 0.3;
    shieldPS.minLifeTime = 0.2;
    shieldPS.maxLifeTime = 0.5;
    shieldPS.emitRate = 50;
    shieldPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    shieldPS.minEmitPower = 0.1;
    shieldPS.maxEmitPower = 0.3;
    shieldPS.updateSpeed = 0.01;
    shieldPS.start();
    
    // Kalkan aktif olduğu sürece oyuncuyu hasardan koru
    this.isShielded = true;
    
    // Ekrana bildirim
    this.showNotification("KALKAN AKTİF! 5 SANİYE KORUMA", new BABYLON.Color3(0.4, 0.4, 1.0));
    
    // Kalkan süresini gösteren UI
    const shieldTimerUI = document.createElement('div');
    shieldTimerUI.className = 'hud-timer';
    shieldTimerUI.style.top = '180px';
    shieldTimerUI.style.backgroundColor = 'rgba(50, 50, 255, 0.2)';
    shieldTimerUI.style.borderColor = 'rgba(100, 100, 255, 0.7)';
    
    shieldTimerUI.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
        </svg>
        <span>KALKAN: </span>
        <span id="shield-time">5.0s</span>
    `;
    
    document.body.appendChild(shieldTimerUI);
    
    // Kalkan süresini geri say
    const startTime = Date.now();
    const endTime = startTime + shieldDuration;
    
    const shieldInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const shieldTimeText = document.getElementById('shield-time');
        if (shieldTimeText) {
            shieldTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);
    
    // Kalkan süresinin sonunda
    setTimeout(() => {
        this.isShielded = false;
        
        // Kalkan kaybolma animasyonu
        const fadeAnim = new BABYLON.Animation(
            "shieldFade",
            "material.alpha",
            30,
            BABYLON.Animation.ANIMATIONTYPE_FLOAT
        );
        
        fadeAnim.setKeys([
            { frame: 0, value: 0.3 },
            { frame: 30, value: 0 }
        ]);
        
        this.scene.beginDirectAnimation(shield, [fadeAnim], 0, 30, false, 1, () => {
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(shield);
            shield.dispose();
            shieldPS.stop();
        });
        
        // UI'ı temizle
        clearInterval(shieldInterval);
        shieldTimerUI.remove();
        
        // Bildirim
        this.showNotification("KALKAN DEVRE DIŞI", new BABYLON.Color3(0.4, 0.4, 1.0));
    }, shieldDuration);
    
    // handleHazardHit metodunu geçici olarak değiştir
    const originalHandleHazardHit = this.handleHazardHit;
    this.handleHazardHit = function() {
        if (this.isShielded) {
            // Kalkan aktifken hasar almaz
            this.showNotification("HASAR ENGELLENDİ!", new BABYLON.Color3(0.4, 0.4, 1.0));
            
            // Kalkan dalgası efekti
            const shieldImpact = BABYLON.MeshBuilder.CreateSphere("shieldImpact", {
                diameter: 4.2,
                segments: 16
            }, this.scene);
            
            const impactMat = new BABYLON.StandardMaterial("impactMat", this.scene);
            impactMat.diffuseColor = new BABYLON.Color3(0.4, 0.4, 1.0);
            impactMat.emissiveColor = new BABYLON.Color3(0.6, 0.6, 1.0);
            impactMat.alpha = 0.5;
            shieldImpact.material = impactMat;
            
            shieldImpact.parent = this.currentGoldberg;
            
            // Dalgalanma ve kaybolma animasyonu
            const impactAnim = new BABYLON.Animation(
                "impactAnim",
                "scaling",
                30,
                BABYLON.Animation.ANIMATIONTYPE_VECTOR3
            );
            
            impactAnim.setKeys([
                { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
                { frame: 15, value: new BABYLON.Vector3(1.3, 1.3, 1.3) }
            ]);
            
            const impactFadeAnim = new BABYLON.Animation(
                "impactFadeAnim",
                "material.alpha",
                30,
                BABYLON.Animation.ANIMATIONTYPE_FLOAT
            );
            
            impactFadeAnim.setKeys([
                { frame: 0, value: 0.5 },
                { frame: 15, value: 0 }
            ]);
            
            this.scene.beginDirectAnimation(shieldImpact, [impactAnim, impactFadeAnim], 0, 15, false, 1, () => {
                shieldImpact.dispose();
            });
            
            return;
        }
        
        // Kalkan yoksa normal hasar alma
        originalHandleHazardHit.call(this);
    };
    
    // Kalkan süresi bittiğinde orijinal fonksiyonu geri yükle
    setTimeout(() => {
        this.handleHazardHit = originalHandleHazardHit;
    }, shieldDuration);
}

// Yerçekimi efektleri ekle
addGravityEffects(projectile) {
    // Yerçekimi materyali
    const gravityMat = new BABYLON.StandardMaterial("gravityMat", this.scene);
    gravityMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
    gravityMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
    projectile.material = gravityMat;
    
    // Yerçekimi parçacıkları
    const gravityPS = new BABYLON.ParticleSystem("gravityParticles", 600, this.scene);
    gravityPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    gravityPS.emitter = projectile;
    gravityPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    gravityPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    gravityPS.color1 = new BABYLON.Color4(0.2, 1.0, 0.3, 1.0);
    gravityPS.color2 = new BABYLON.Color4(0.5, 1.0, 0.6, 1.0);
    gravityPS.colorDead = new BABYLON.Color4(0.1, 0.3, 0.1, 0.0);
    gravityPS.minSize = 0.1;
    gravityPS.maxSize = 0.4;
    gravityPS.minLifeTime = 0.2;
    gravityPS.maxLifeTime = 0.6;
    gravityPS.emitRate = 300;
    gravityPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    gravityPS.gravity = new BABYLON.Vector3(0, 0, 0);
    gravityPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    gravityPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    gravityPS.minEmitPower = 1;
    gravityPS.maxEmitPower = 2;
    gravityPS.updateSpeed = 0.01;
    gravityPS.start();
    
    // Kalkan efekti
    const shield = BABYLON.MeshBuilder.CreateSphere("gravityShield", {
        diameter: 3,
        segments: 16
    }, this.scene);
    
    const shieldMat = new BABYLON.StandardMaterial("shieldMat", this.scene);
    shieldMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
    shieldMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
    shieldMat.alpha = 0.3;
    shield.material = shieldMat;
    
    shield.parent = projectile;   

 // Kalkan dalgalanma animasyonu
    const shieldAnim = new BABYLON.Animation(
        "shieldAnim",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    shieldAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(shield, 0, 30, true);
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(shield);
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        gravityPS.dispose();
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(shield);
        shield.dispose();
    });
}

// Hız artışı aktivasyonu
// GoldbergController sınıfı içinde...

activateSpeedBoost() {
    const boostDuration = 10000; // 10 saniye

    // Eğer zaten bir hız artışı aktifse, mevcut zamanlayıcıyı temizle ki süre sıfırlansın.
    if (this.speedBoostTimeout) {
        clearTimeout(this.speedBoostTimeout);
    }

    // Hız çarpanını 2.0 yap.
    this.speedMultiplier = 2.0;

    // --- Görsel Efektler ve UI (Bu kısım aynı kalabilir) ---

    // Eğer aura zaten varsa, tekrar oluşturma. Sadece varlığını kontrol et.
    let speedAura = this.scene.getMeshByName("speedAura");
    if (!speedAura) {
        // Hız efekti
        const speedTrail = new BABYLON.ParticleSystem("speedTrail", 300, this.scene);
        speedTrail.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
        speedTrail.emitter = this.currentGoldberg;
        // ... (speedTrail ayarları)
        speedTrail.start();
        this.speedTrailEffect = speedTrail; // Efekti daha sonra durdurmak için sakla

        // Oyuncuya hız aura'sı ekle
        speedAura = BABYLON.MeshBuilder.CreateSphere("speedAura", { diameter: 2.5, segments: 16 }, this.scene);
        const auraMat = new BABYLON.StandardMaterial("auraMat", this.scene);
        auraMat.diffuseColor = new BABYLON.Color3(0.2, 0.8, 0.3);
        auraMat.emissiveColor = new BABYLON.Color3(0.1, 0.5, 0.2);
        auraMat.alpha = 0.3;
        speedAura.material = auraMat;
        speedAura.parent = this.currentGoldberg;

        const glowLayer = this.scene.getGlowLayerByName("glow");
        if (glowLayer) glowLayer.addIncludedOnlyMesh(speedAura);

        const auraAnim = new BABYLON.Animation("auraAnim", "scaling", 30, BABYLON.Animation.ANIMATIONTYPE_VECTOR3);
        auraAnim.setKeys([{ frame: 0, value: new BABYLON.Vector3(1, 1, 1) }, { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) }, { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }]);
        this.scene.beginAnimation(speedAura, 0, 30, true);
    }

    // Ekrana bildirim
    this.showNotification("HIZ ARTIŞI! 10 SANİYE", new BABYLON.Color3(0.2, 0.8, 0.3));

    // Hız süresini gösteren UI (Eğer zaten varsa, tekrar oluşturma)
    let speedTimerUI = document.getElementById('speed-timer-container');
    if (!speedTimerUI) {
        speedTimerUI = document.createElement('div');
        speedTimerUI.id = 'speed-timer-container';
        speedTimerUI.className = 'hud-timer';
        // ... (UI stil ayarları)
        speedTimerUI.innerHTML = `... HIZ: <span id="speed-time">10.0s</span> ...`;
        document.body.appendChild(speedTimerUI);
    }
    
    // Hız süresini geri say
    const endTime = Date.now() + boostDuration;
    if (this.speedInterval) clearInterval(this.speedInterval);
    this.speedInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const speedTimeText = document.getElementById('speed-time');
        if (speedTimeText) {
            speedTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);

    // Hız artışı süresinin sonunda çalışacak olan zamanlayıcı
    this.speedBoostTimeout = setTimeout(() => {
        // Hız çarpanını normale döndür
        this.speedMultiplier = 1.0;

        // Efektleri temizle
        if (this.speedTrailEffect) {
            this.speedTrailEffect.stop();
            this.speedTrailEffect = null;
        }
        
        const aura = this.scene.getMeshByName("speedAura");
        if (aura) {
            const glowLayer = this.scene.getGlowLayerByName("glow");
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(aura);
            aura.dispose();
        }

        // UI'ı temizle
        clearInterval(this.speedInterval);
        if (speedTimerUI) speedTimerUI.remove();

        // Bildirim
        this.showNotification("HIZ ARTIŞI SONA ERDİ", new BABYLON.Color3(0.2, 0.8, 0.3));
    }, boostDuration);
}

// Karanlık enerji efektleri ekle
addDarkEnergyEffects(projectile) {
    // Karanlık enerji materyali
    const darkMat = new BABYLON.StandardMaterial("darkMat", this.scene);
    darkMat.diffuseColor = new BABYLON.Color3(0.5, 0.1, 0.8);
    darkMat.emissiveColor = new BABYLON.Color3(0.3, 0.0, 0.5);
    projectile.material = darkMat;
    
    // Karanlık enerji parçacıkları
    const darkPS = new BABYLON.ParticleSystem("darkParticles", 600, this.scene);
    darkPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    darkPS.emitter = projectile;
    darkPS.minEmitBox = new BABYLON.Vector3(-0.5, -0.1, -0.5);
    darkPS.maxEmitBox = new BABYLON.Vector3(0.5, 0.1, 0.5);
    darkPS.color1 = new BABYLON.Color4(0.7, 0.2, 1.0, 1.0);
    darkPS.color2 = new BABYLON.Color4(0.5, 0.1, 0.8, 1.0);
    darkPS.colorDead = new BABYLON.Color4(0.3, 0.0, 0.5, 0.0);
    darkPS.minSize = 0.1;
    darkPS.maxSize = 0.4;
    darkPS.minLifeTime = 0.2;
    darkPS.maxLifeTime = 0.6;
    darkPS.emitRate = 300;
    darkPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    darkPS.gravity = new BABYLON.Vector3(0, 0, 0);
    darkPS.direction1 = new BABYLON.Vector3(-1, -1, -1);
    darkPS.direction2 = new BABYLON.Vector3(1, 1, 1);
    darkPS.minEmitPower = 1;
    darkPS.maxEmitPower = 2;
    darkPS.updateSpeed = 0.01;
    darkPS.start();
    
    // Karanlık enerji halkası
    const darkRing = BABYLON.MeshBuilder.CreateTorus("darkRing", {
        diameter: 3,
        thickness: 0.4,
        tessellation: 32
    }, this.scene);
    
    const ringMat = new BABYLON.StandardMaterial("darkRingMat", this.scene);
    ringMat.emissiveColor = new BABYLON.Color3(0.5, 0.1, 0.8);
    ringMat.alpha = 0.7;
    ringMat.disableLighting = true;
    darkRing.material = ringMat;
    
    darkRing.parent = projectile;
    darkRing.rotation.x = Math.PI / 2;
    
    // Dönme animasyonu
    const ringAnim = new BABYLON.Animation(
        "ringRotation",
        "rotation.z",
        30,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    ringAnim.setKeys([
        { frame: 0, value: 0 },
        { frame: 30, value: Math.PI * 2 }
    ]);
    
    this.scene.beginAnimation(darkRing, 0, 30, true);
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(darkRing);
    
    // Mermi yok edildiğinde efektleri de temizle
    projectile.onDisposeObservable.add(() => {
        darkPS.dispose();
        darkRing.dispose();
    });
}

// Çekim alanı aktivasyonu (devam)
activateAttractionField() {
    // Çekim alanı süresi
    const attractionDuration = 15000; // 15 saniye
    
    // Orijinal toplama çapını sakla
    const originalPickupRadius = 2.5; // Varsayılan değer
    
    // Yeni toplama çapı
    const enhancedPickupRadius = 6.0;
    
    // Çekim alanı görsel efekti
    const attractionField = BABYLON.MeshBuilder.CreateSphere("attractionField", {
        diameter: enhancedPickupRadius * 2,
        segments: 16
    }, this.scene);
    
    const fieldMat = new BABYLON.StandardMaterial("fieldMat", this.scene);
    fieldMat.diffuseColor = new BABYLON.Color3(0.7, 0.2, 1.0);
    fieldMat.emissiveColor = new BABYLON.Color3(0.4, 0.1, 0.6);
    fieldMat.alpha = 0.15;
    attractionField.material = fieldMat;
    
    attractionField.parent = this.currentGoldberg;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(attractionField);
    
    // Alan dalgalanma animasyonu
    const fieldAnim = new BABYLON.Animation(
        "fieldAnim",
        "scaling",
        30,
        BABYLON.Animation.ANIMATIONTYPE_VECTOR3
    );
    
    fieldAnim.setKeys([
        { frame: 0, value: new BABYLON.Vector3(1, 1, 1) },
        { frame: 15, value: new BABYLON.Vector3(1.1, 1.1, 1.1) },
        { frame: 30, value: new BABYLON.Vector3(1, 1, 1) }
    ]);
    
    this.scene.beginAnimation(attractionField, 0, 30, true);
    
    // Çekim parçacıkları
    const attractionPS = new BABYLON.ParticleSystem("attractionPS", 50, this.scene);
    attractionPS.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", this.scene);
    attractionPS.emitter = this.currentGoldberg;
    attractionPS.minEmitBox = new BABYLON.Vector3(-enhancedPickupRadius, 0, -enhancedPickupRadius);
    attractionPS.maxEmitBox = new BABYLON.Vector3(enhancedPickupRadius, 0, enhancedPickupRadius);
    attractionPS.color1 = new BABYLON.Color4(0.7, 0.2, 1.0, 0.5);
    attractionPS.color2 = new BABYLON.Color4(0.5, 0.1, 0.8, 0.5);
    attractionPS.colorDead = new BABYLON.Color4(0.3, 0.0, 0.5, 0.0);
    attractionPS.minSize = 0.1;
    attractionPS.maxSize = 0.3;
    attractionPS.minLifeTime = 0.5;
    attractionPS.maxLifeTime = 1.0;
    attractionPS.emitRate = 20;
    attractionPS.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    attractionPS.gravity = new BABYLON.Vector3(0, 0, 0);
    attractionPS.minEmitPower = 0;
    attractionPS.maxEmitPower = 0;
    attractionPS.updateSpeed = 0.01;
    
    // Özel güncelleme fonksiyonu - parçacıkları oyuncuya doğru hareket ettir
    attractionPS.updateFunction = (particles) => {
        for (let i = 0; i < particles.length; i++) {
            const particle = particles[i];
            const directionToPlayer = this.currentGoldberg.position.subtract(particle.position);
            const distance = directionToPlayer.length();
            
            if (distance < 0.5) {
                particle.age = particle.lifeTime; // Parçacığı yok et
                continue;
            }
            
            // Parçacığı oyuncuya doğru hareket ettir
            const speed = 0.05 + (1.0 - distance / enhancedPickupRadius) * 0.1;
            particle.direction = directionToPlayer.normalize().scale(speed);
            particle.position.addInPlace(particle.direction);
        }
    };
    
    attractionPS.start();
    
    // Ekrana bildirim
    this.showNotification("ÇEKİM ALANI AKTİF! 15 SANİYE", new BABYLON.Color3(0.7, 0.2, 1.0));
    
    // Çekim alanı süresini gösteren UI
    const attractionTimerUI = document.createElement('div');
    attractionTimerUI.className = 'hud-timer';
    attractionTimerUI.style.top = '180px';
    attractionTimerUI.style.backgroundColor = 'rgba(150, 50, 255, 0.2)';
    attractionTimerUI.style.borderColor = 'rgba(200, 100, 255, 0.7)';
    
    attractionTimerUI.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M8 12h8"></path>
            <path d="M12 8v8"></path>
        </svg>
        <span>ÇEKİM ALANI: </span>
        <span id="attraction-time">15.0s</span>
    `;
    
    document.body.appendChild(attractionTimerUI);
    
    // Çekim alanı süresini geri say
    const startTime = Date.now();
    const endTime = startTime + attractionDuration;
    
    const attractionInterval = setInterval(() => {
        const remaining = Math.max(0, endTime - Date.now());
        const attractionTimeText = document.getElementById('attraction-time');
        if (attractionTimeText) {
            attractionTimeText.textContent = `${(remaining / 1000).toFixed(1)}s`;
        }
    }, 100);
    
    // Çekim alanı aktif olduğu sürece hex toplama mesafesini artır
    this.hasAttractionField = true;
    this.attractionFieldRadius = enhancedPickupRadius;
    
    // Yeni bir hex toplama fonksiyonu ekle
    const hexPickupObserver = this.scene.onBeforeRenderObservable.add(() => {
        if (!gameManager.state.isRunning) return;
        
        const playerMesh = this.currentGoldberg;
        const ground = this.scene.getTransformNodeByName("ground");
        
        if (ground) {
            ground.getChildMeshes().forEach(hex => {
                if (hex.isPlayable && hex.specialColor) {
                    const dist = BABYLON.Vector3.Distance(playerMesh.position, hex.getAbsolutePosition());
                    const pickupRadius = this.hasAttractionField ? this.attractionFieldRadius : originalPickupRadius;
                    
                    if (dist < pickupRadius) {
                        // Hex'i topla
                        createFlyingHexAnimation(hex, gameManager.pentaTileController.mesh.position, this.scene, gameManager, true);
                        
                        // Çekim efekti
                        if (this.hasAttractionField && dist > originalPickupRadius) {
                            this.createAttractionEffect(hex.getAbsolutePosition());
                        }
                    }
                }
            });
        }
    });
    
    // Çekim alanı süresinin sonunda
    setTimeout(() => {
        this.hasAttractionField = false;
        
        // Alan kaybolma animasyonu
        const fadeAnim = new BABYLON.Animation(
            "fieldFade",
            "material.alpha",
            30,
            BABYLON.Animation.ANIMATIONTYPE_FLOAT
        );
        
        fadeAnim.setKeys([
            { frame: 0, value: 0.15 },
            { frame: 30, value: 0 }
        ]);
        
        this.scene.beginDirectAnimation(attractionField, [fadeAnim], 0, 30, false, 1, () => {
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(attractionField);
            attractionField.dispose();
            attractionPS.stop();
        });
        
        // UI'ı temizle
        clearInterval(attractionInterval);
        attractionTimerUI.remove();
        
        // Bildirim
        this.showNotification("ÇEKİM ALANI SONA ERDİ", new BABYLON.Color3(0.7, 0.2, 1.0));
        
        // Eklenen observer'ı kaldır
        this.scene.onBeforeRenderObservable.remove(hexPickupObserver);
    }, attractionDuration);
}

// Çekim efekti
createAttractionEffect(hexPosition) {
    // Hex'ten oyuncuya doğru çekim çizgisi
    const points = [];
    const startPoint = hexPosition.clone();
    const endPoint = this.currentGoldberg.position.clone();
    
    // Hafif kavisli bir çizgi oluştur
    const midPoint = BABYLON.Vector3.Lerp(startPoint, endPoint, 0.5);
    midPoint.y += 1 + Math.random();
    
    // Bezier eğrisi için noktalar
    for (let i = 0; i <= 10; i++) {
        const t = i / 10;
        const point = new BABYLON.Vector3(
            (1-t)*(1-t)*startPoint.x + 2*(1-t)*t*midPoint.x + t*t*endPoint.x,
            (1-t)*(1-t)*startPoint.y + 2*(1-t)*t*midPoint.y + t*t*endPoint.y,
            (1-t)*(1-t)*startPoint.z + 2*(1-t)*t*midPoint.z + t*t*endPoint.z
        );
        points.push(point);
    }
    
    // Çekim çizgisi
    const attractionLine = BABYLON.MeshBuilder.CreateTube("attractionLine", {
        path: points,
        radius: 0.05,
        updatable: false
    }, this.scene);
    
    const lineMat = new BABYLON.StandardMaterial("lineMat", this.scene);
    lineMat.emissiveColor = new BABYLON.Color3(0.7, 0.2, 1.0);
    lineMat.alpha = 0.7;
    lineMat.disableLighting = true;
    attractionLine.material = lineMat;
    
    // Glow efekti
    const glowLayer = this.scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(attractionLine);
    
    // Çizgi kaybolma animasyonu
    const fadeAnim = new BABYLON.Animation(
        "lineFade",
        "material.alpha",
        30,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT
    );
    
    fadeAnim.setKeys([
        { frame: 0, value: 0.7 },
        { frame: 15, value: 0 }
    ]);
    
    this.scene.beginDirectAnimation(attractionLine, [fadeAnim], 0, 15, false, 1, () => {
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(attractionLine);
        attractionLine.dispose();
    });
}

    } 

    class CameraController { 
        constructor(t, e) { this.scene = t; this.targetMesh = e; this.camera = null; this.cameraTarget = new BABYLON.Vector3.Zero; this.initCamera(); } 
        initCamera() { this.camera = new BABYLON.FreeCamera("GameCamera", BABYLON.Vector3.Zero(), this.scene); this.camera.inputs.clear(); this.reset(); } 
        reset() { this.update(); } 
        update() { if (!this.targetMesh || !this.camera) return; this.camera.position.x = this.targetMesh.position.x + GAME_CONSTANTS.CAMERA_X_OFFSET; this.camera.position.y = GAME_CONSTANTS.CAMERA_Y_POSITION; this.camera.position.z = this.targetMesh.position.z + GAME_CONSTANTS.CAMERA_Z_OFFSET; this.cameraTarget.copyFrom(this.targetMesh.position); this.camera.setTarget(this.cameraTarget); } 
    } 

    // --- HELPER FUNCTIONS (No changes needed here) --- 


    function createTrailParticles(emitter, particleColor, scene) { 
        const particleSystem = new BABYLON.ParticleSystem("particles", 2000, scene); 
        particleSystem.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", scene); 
        particleSystem.emitter = emitter; 
        particleSystem.minEmitBox = new BABYLON.Vector3(-0.2, 0, -0.2); 
        particleSystem.maxEmitBox = new BABYLON.Vector3(0.2, 0, 0.2); 
        particleSystem.color1 = particleColor.toColor4(1); 
        particleSystem.color2 = particleColor.scale(0.5).toColor4(1); 
        particleSystem.colorDead = new BABYLON.Color4(0, 0, 0, 0.0); 
        particleSystem.minSize = 0.1; 
        particleSystem.maxSize = 0.4; 
        particleSystem.minLifeTime = 0.2; 
        particleSystem.maxLifeTime = 0.8; 
        particleSystem.emitRate = 400; 
        particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
        particleSystem.gravity = new BABYLON.Vector3(0, 0, 0); 
        particleSystem.targetStopDuration = 0.2; 
        particleSystem.disposeOnStop = true; 
        particleSystem.start(); 
        emitter.onDisposeObservable.add(() => { particleSystem.stop(); }); 
    } 

    function createImpactParticles(position, particleColor, scene) { 
        const particleSystem = new BABYLON.ParticleSystem("impactParticles", 500, scene); 
        particleSystem.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", scene); 
        particleSystem.emitter = position; 
        particleSystem.minEmitBox = new BABYLON.Vector3(-0.1, -0.1, -0.1); 
        particleSystem.maxEmitBox = new BABYLON.Vector3(0.1, 0.1, 0.1); 
        particleSystem.color1 = particleColor.toColor4(1.5); 
        particleSystem.color2 = particleColor.scale(0.8).toColor4(1); 
        particleSystem.colorDead = new BABYLON.Color4(0, 0, 0, 0.0); 
        particleSystem.minSize = 0.2; 
        particleSystem.maxSize = 0.6; 
        particleSystem.minLifeTime = 0.2; 
        particleSystem.maxLifeTime = 0.5; 
        particleSystem.emitRate = 500; 
        particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
        particleSystem.direction1 = new BABYLON.Vector3(-2, 2, -2); 
        particleSystem.direction2 = new BABYLON.Vector3(2, 2, 2); 
        particleSystem.minEmitPower = 1; 
        particleSystem.maxEmitPower = 4; 
        particleSystem.targetStopDuration = 0.2; 
        particleSystem.disposeOnStop = true; 
        particleSystem.start(); 
    } 

    function createBoundaryHexagons(scene) { 
        const boundaryHexConfigs = { 
'A': { centerX: -41.5, centerZ: 0, angle: Math.PI / 2, diameter: 53, color: new BABYLON.Color3(.6, .8, 1) }, 
'B': { centerX: -13, centerZ: 39, angle: -Math.PI / 10, diameter: 53, color: new BABYLON.Color3(1, .6, 0) }, 
'C': { centerX: 33, centerZ: 25, angle: Math.PI / 3.5, diameter: 53.5, color: new BABYLON.Color3(0, .6, 1) }, 
'D': { centerX: 33, centerZ: -25, angle: -Math.PI / 3.5, diameter: 53.5, color: new BABYLON.Color3(.2, 1, .2) }, 
'E': { centerX: -13, centerZ: -39, angle: Math.PI / 10, diameter: 53, color: new BABYLON.Color3(.5, 0, .5) } 
}; 

        const boundaryContainer = new BABYLON.TransformNode("boundaryContainer", scene); 
        for (const key in boundaryHexConfigs) { const config = boundaryHexConfigs[key], hexWall = BABYLON.MeshBuilder.CreateCylinder(`boundaryHex_${key}`, { diameter: config.diameter, height: 4, tessellation: 6 }, scene), material = new BABYLON.StandardMaterial(`boundaryMat_${key}`, scene); material.diffuseColor = config.color, material.emissiveColor = config.color.scale(.3), material.alpha = .25, hexWall.material = material, hexWall.position = new BABYLON.Vector3(config.centerX, 2, config.centerZ), hexWall.rotation.y = config.angle, hexWall.parent = boundaryContainer } 
        return boundaryContainer; 
    } 

    function createGridBoundaryWalls(scene, pentagonPoints) { 
        const wallContainer = new BABYLON.TransformNode("wallContainer", scene); 
        for (let i = 0; i < pentagonPoints.length; i++) { 
            const p1 = pentagonPoints[i]; 
            const p2 = pentagonPoints[(i + 1) % pentagonPoints.length]; 
            const wallLength = Math.sqrt(Math.pow(p2[0] - p1[0], 2) + Math.pow(p2[1] - p1[1], 2)); 
            const wallCenter = new BABYLON.Vector3((p1[0] + p2[0]) / 2, 5, (p1[1] + p2[1]) / 2); 
            const wallAngle = Math.atan2(p2[1] - p1[1], p2[0] - p1[0]); 
            const wall = BABYLON.MeshBuilder.CreateBox(`invisibleWall_${i}`, { width: wallLength, height: 10, depth: 0.5 }, scene); 
            wall.position = wallCenter; 
            wall.rotation.y = -wallAngle; 
            wall.visibility = 0; 
            wall.physicsImpostor = new BABYLON.PhysicsImpostor(wall, BABYLON.PhysicsImpostor.BoxImpostor, { mass: 0, restitution: 0.1, friction: 0.9 }, scene); 
            wall.parent = wallContainer; 
        } 
        return wallContainer; 
    } 
   
 function createHexGrid(scene, pentagonPoints) { 
        const ground = new BABYLON.TransformNode("ground", scene); 
        ground.rotation.y = -Math.PI / 2; 
        const tileThickness = 1; 
        const playableHexMaterial = new BABYLON.StandardMaterial("playableHexMat", scene); 
        playableHexMaterial.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.2); 
        const gridW = GAME_CONSTANTS.GRID_WIDTH; 
        for (let q = -gridW; q <= gridW; q++) { 
            for (let r = -gridW; r <= gridW; r++) { 
                const x = GAME_CONSTANTS.HEX_RADIUS * 1.5 * GAME_CONSTANTS.SPACING_FACTOR * q; 
                const z = GAME_CONSTANTS.HEX_RADIUS * Math.sqrt(3) * GAME_CONSTANTS.SPACING_FACTOR * (r + q / 2); 
                if (isPointInPolygon(x, z, pentagonPoints)) { 
                    const hex = BABYLON.MeshBuilder.CreateCylinder("hex_" + q + "_" + r, { diameter: GAME_CONSTANTS.HEX_RADIUS * 2, height: tileThickness, tessellation: 6 }, scene); 
                    hex.rotation.y = Math.PI / 2 + Math.PI / 6; 
                    hex.parent = ground; 
                    hex.isPlayable = true; 
                    hex.material = playableHexMaterial; 
                    hex.position.set(x, tileThickness / 2, z); 
                } 
            } 
        } 
        const groundMesh = BABYLON.MeshBuilder.CreateBox("groundMesh", { width: gridW * 5, height: 0.5, depth: gridW * 5 }, scene); 
        groundMesh.position.y = -0.25; 
        groundMesh.visibility = 0; 
        groundMesh.physicsImpostor = new BABYLON.PhysicsImpostor(groundMesh, BABYLON.PhysicsImpostor.BoxImpostor, { mass: 0, restitution: 0.1 }, scene); 
        return ground; 
    } 


    function updateHexGridDeformation(ground, playerPos) { ground.getChildMeshes().forEach(hex => { if (hex.isPlayable) { const hexAbsPos = hex.getAbsolutePosition();
const dx = playerPos.x - hexAbsPos.x; const dz = playerPos.z - hexAbsPos.z;
const dist = Math.sqrt(dx * dx + dz * dz); const influenceRadius = GAME_CONSTANTS.GRID_INFLUENCE_RADIUS;
 if (dist < influenceRadius) { const factor = Math.pow(1 - (dist / influenceRadius), 2); const targetY = 0.5 - GAME_CONSTANTS.GRID_INFLUENCE_MAX_DEPTH * factor;
 hex.position.y = BABYLON.Scalar.Lerp(hex.position.y, targetY, 0.2); } else { const originalY = 0.5; hex.position.y += (originalY - hex.position.y) * GAME_CONSTANTS.GRID_INFLUENCE_DAMPING;
 } 
} 
}); 
} 


function createPentagonTile(scene) {
    // Pentagon mesh'ini oluştur - çapı büyütülmüş hali
    const pentagon = BABYLON.MeshBuilder.CreateCylinder("pentaTile", { 
        diameter: GAME_CONSTANTS.HEX_RADIUS * 8, // Çapı büyütüldü (5'ten 8'e)
        height: 4, 
        tessellation: 5 
    }, scene);
    
    // Pentagon materyalini oluştur
    const pentaMaterial = new BABYLON.StandardMaterial("pentaMat", scene);
    pentaMaterial.diffuseColor = new BABYLON.Color3(0.8, 0.2, 0.2);
    pentaMaterial.emissiveColor = new BABYLON.Color3(0.2, 0.0, 0.0);
    pentagon.material = pentaMaterial;
    
    // Konumunu ve rotasyonunu ayarla
    pentagon.position = new BABYLON.Vector3(0, 0.7, 0);
    pentagon.rotation.y = 0;
    
    // MeshImpostor kullanarak gerçek geometriye dayalı fizik ekle
    pentagon.physicsImpostor = new BABYLON.PhysicsImpostor(pentagon, BABYLON.PhysicsImpostor.MeshImpostor, { 
        mass: 0, 
        restitution: 0.2,
        friction: 0.1
    }, scene);
    
    // Üst yüzeyi eğimli hale getir (tırmanmayı engellemek için)
    const positions = pentagon.getVerticesData(BABYLON.VertexBuffer.PositionKind);
    const indices = pentagon.getIndices();
    const normals = pentagon.getVerticesData(BABYLON.VertexBuffer.NormalKind);
    
    if (positions && indices && normals) {
        // Üst yüzeydeki noktaları bul ve dışa doğru eğ
        for (let i = 0; i < positions.length; i += 3) {
            if (positions[i+1] > 2) { // Üst yüzeydeki noktalar (y > 2)
                const dir = new BABYLON.Vector3(positions[i], 0, positions[i+2]).normalize();
                positions[i] += dir.x * 1.5;  // X koordinatını dışa doğru it
                positions[i+2] += dir.z * 1.5; // Z koordinatını dışa doğru it
            }
        }
        
        // Mesh'i güncelle
        pentagon.updateVerticesData(BABYLON.VertexBuffer.PositionKind, positions);
        BABYLON.VertexData.ComputeNormals(positions, indices, normals);
        pentagon.updateVerticesData(BABYLON.VertexBuffer.NormalKind, normals);
    }
    
    return pentagon;
}


// createIcosahedronCore fonksiyonunu tamamen bununla değiştirin.
function createIcosahedronCore(scene) {
    // 1. Mesh'i oluştur
    const core = BABYLON.MeshBuilder.CreatePolyhedron("icosahedronCore", { type: 3, size: 2.8 }, scene);
    core.physicsImpostor = new BABYLON.PhysicsImpostor(core, BABYLON.PhysicsImpostor.SphereImpostor, { mass: 0 }, scene);
    core.position = new BABYLON.Vector3(0, 0.7, 0);

    // 2. DIŞ KABUK (Icosahedron) için materyal
    const coreMaterial = new BABYLON.StandardMaterial("coreMat", scene);
    coreMaterial.diffuseColor = new BABYLON.Color3(0.2, 0, 0);
    coreMaterial.emissiveColor = new BABYLON.Color3(0.3, 0, 0);
    coreMaterial.alpha = 0.4; // Varsayılan şeffaflık
    coreMaterial.specularPower = 64;
    core.material = coreMaterial;

    // YENİ - Adım 1: Dış kabuğa kalıcı glow ekle
    const glowLayer = scene.getGlowLayerByName("glow");
    if (glowLayer) {
        glowLayer.addIncludedOnlyMesh(core);
    }

    // 3. İÇ KÜRE'yi oluştur
    const innerSphere = BABYLON.MeshBuilder.CreateSphere("coreSphere", { diameter: 3.5, segments: 32 }, scene);
    innerSphere.parent = core;

    const sphereMaterial = new BABYLON.StandardMaterial("sphereMat", scene);
    sphereMaterial.disableLighting = true;
    innerSphere.material = sphereMaterial;
    core.innerSphereMaterial = sphereMaterial;

    // 4. ANİMASYON VE UYARI MANTIĞI
    let colorPhase = 0;
    let flashPhase = 0;
    scene.onBeforeRenderObservable.add(() => {
        if (!core.isEnabled() || !core.innerSphereMaterial) return;

        const isWarning = gameManager.state.isCoreWarning;

        // Dış kabuğun (Icosahedron) animasyonu
        if (isWarning) {
            // UYARI DURUMU: Dış kabuğun şeffaflığını ve parlaklığını titreştir
            const shellFlashIntensity = Math.abs(Math.sin(flashPhase * 0.8)); // Daha yavaş bir titreşim
            coreMaterial.alpha = 0.3 + shellFlashIntensity * 0.4; // Şeffaflık 0.3 ile 0.7 arasında gidip gelsin
            coreMaterial.emissiveColor.set(0.3 + shellFlashIntensity * 0.5, 0, 0); // Kırmızı parlama artsın
        } else {
            // NORMAL DURUM: Dış kabuğu varsayılan haline döndür
            coreMaterial.alpha = 0.4;
            coreMaterial.emissiveColor.set(0.3, 0, 0);
        }

        // İç kürenin animasyonu
        if (isWarning) {
            // UYARI DURUMU: İç küre parlak beyaza dönsün ve flaş yapsın
            flashPhase += 0.2;
            const sphereFlashIntensity = Math.abs(Math.sin(flashPhase));
            core.innerSphereMaterial.emissiveColor.set(sphereFlashIntensity, sphereFlashIntensity, sphereFlashIntensity * 0.8);
        } else {
            // NORMAL DURUM: İç küre koyu turuncu tonlarında renk değiştirsin
            colorPhase += 0.01;
            // YENİ - Adım 2: Renkleri koyu turuncu etrafında yoğunlaştır
            const r = 0.8 + Math.sin(colorPhase) * 0.2; // Kırmızı her zaman yüksek (0.6 - 1.0)
            const g = 0.3 + Math.sin(colorPhase * 0.7 + 2) * 0.2; // Yeşil orta seviyede (0.1 - 0.5)
            const b = 0.05; // Mavi çok düşük
            core.innerSphereMaterial.emissiveColor.set(r, g, b);
        }
    });

    core.setEnabled(false);
    return core;
}


// Bu yeni fonksiyonu diğer yardımcı fonksiyonların (createHexGrid vb.) yanına ekleyin.
function spawnCoreArcs(coreMesh, scene) {
    if (!coreMesh || !coreMesh.isEnabled() || Math.random() > 0.1) {
        // Her frame'de değil, %10 ihtimalle çalıştırarak performansı koru.
        return;
    }

    const vertices = coreMesh.getVerticesData(BABYLON.VertexBuffer.PositionKind);
    if (!vertices) return;

    const vertexCount = vertices.length / 3;
    const i1 = Math.floor(Math.random() * vertexCount);
    const i2 = Math.floor(Math.random() * vertexCount);

    const p1_local = new BABYLON.Vector3(vertices[i1*3], vertices[i1*3+1], vertices[i1*3+2]);
    const p2_local = new BABYLON.Vector3(vertices[i2*3], vertices[i2*3+1], vertices[i2*3+2]);

    // Noktaları mesh'in dünya pozisyonuna taşı.
    const p1_world = BABYLON.Vector3.TransformCoordinates(p1_local, coreMesh.getWorldMatrix());
    const p2_world = BABYLON.Vector3.TransformCoordinates(p2_local, coreMesh.getWorldMatrix());

    const fractalPath = generateFractalLightning(p1_world, p2_world, 1.0, 0.2);
    
    const arc = BABYLON.MeshBuilder.CreateTube("coreArc", {path: fractalPath, radius: 0.04}, scene);
    
    // Şimşek için parlak mavi bir materyal oluştur (her seferinde yeniden oluşturmak yerine bir tane tutup kullanmak daha verimli olur).
    let arcMat = scene.getMaterialByName("coreArcMat");
    if (!arcMat) {
        arcMat = new BABYLON.StandardMaterial("coreArcMat", scene);
        arcMat.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0);
        arcMat.disableLighting = true;
    }
    arc.material = arcMat;

    // Glow Layer'a ekle (varsa)
    const glowLayer = scene.getGlowLayerByName("glow");
    if (glowLayer) glowLayer.addIncludedOnlyMesh(arc);

    // Kısa bir süre sonra şimşeği yok et.
    setTimeout(() => {
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(arc);
        arc.dispose();
    }, 200 + Math.random() * 200); // 200-400ms arası
}




    function isPointInPolygon(x, z, pentagonPoints) { let isInside = false;
for (let i = 0, j = pentagonPoints.length - 1;
 i < pentagonPoints.length;
 j = i++) { const xi = pentagonPoints[i][0], zi = pentagonPoints[i][1];
 const xj = pentagonPoints[j][0], zj = pentagonPoints[j][1]; const intersect = ((zi > z) !== (zj > z)) && (x < ((xj - xi) * (z - zi)) / (zj - zi) + xi);
 if (intersect) isInside = !isInside; } return isInside; } 
    function calculatePentagonPoints() { const points = [];
 const radius = GAME_CONSTANTS.GRID_WIDTH * GAME_CONSTANTS.HEX_RADIUS * 1.7; for (let i = 0; i < 5; i++) { const angle = (2 * Math.PI * i) / 5 - Math.PI / 2; points.push([radius * Math.cos(angle), radius * Math.sin(angle)]); 
} 
return points;
 } 


    function createPentaLasers(scene, glowLayer) { 
        const lasersContainer = new BABYLON.TransformNode("lasersContainer", scene); 
        const laserCount = 5; 
        const laserLength = GAME_CONSTANTS.LASER_LENGTH; 
        const laserRadius = 0.15; 
        const laserMaterial = new BABYLON.StandardMaterial("laserMat", scene); 
        laserMaterial.diffuseColor = new BABYLON.Color3(0.5, 0.8, 1); 
        laserMaterial.emissiveColor = new BABYLON.Color3(0.5, 0.8, 1.0); 
        laserMaterial.disableLighting = true; 
        for (let i = 0; i < laserCount; i++) { 
            const laserArm = new BABYLON.TransformNode(`laserArm_${i}`, scene); 
            laserArm.parent = lasersContainer; 
            const laser = BABYLON.MeshBuilder.CreateCylinder(`laser_${i}`, { height: laserLength, diameter: laserRadius, }, scene); 
            laser.material = laserMaterial; 
            laser.parent = laserArm; 
            laser.position.y = laserLength / 2; 
            const angle = (i * 2 * Math.PI / laserCount); 
            laserArm.rotation = new BABYLON.Vector3(Math.PI / 2, angle, 0); 
            glowLayer.addIncludedOnlyMesh(laser); 
        } 
        lasersContainer.position.y = 1.5; 
        lasersContainer.setEnabled(false); 
        return lasersContainer; 
    } 


    function createUnstableAura(emitter, scene) { 
        const particleSystem = new BABYLON.ParticleSystem("unstableAura", 1000, scene); 
        particleSystem.particleTexture = new BABYLON.Texture("https://www.babylonjs-playground.com/textures/flare.png", scene); 
        particleSystem.emitter = emitter; 
        particleSystem.minEmitBox = new BABYLON.Vector3(-0.5, 0, -0.5); 
        particleSystem.maxEmitBox = new BABYLON.Vector3(0.5, 0, 0.5); 
        particleSystem.color1 = new BABYLON.Color4(0.4, 0.7, 1.0, 1.0); 
        particleSystem.color2 = new BABYLON.Color4(0.2, 0.5, 1.0, 1.0); 
        particleSystem.colorDead = new BABYLON.Color4(0, 0, 0.2, 0.0); 
        particleSystem.minSize = 0.1; 
        particleSystem.maxSize = 0.3; 
        particleSystem.minLifeTime = 0.5; 
        particleSystem.maxLifeTime = 1.5; 
        particleSystem.emitRate = 300; 
        particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE; 
        particleSystem.gravity = new BABYLON.Vector3(0, 2, 0); 
        particleSystem.direction1 = new BABYLON.Vector3(-2, 2, -2); 
        particleSystem.direction2 = new BABYLON.Vector3(2, 2, 2); 
        particleSystem.minAngularSpeed = Math.PI; 
        particleSystem.maxAngularSpeed = Math.PI * 2; 
        particleSystem.stop(); 
        return particleSystem; 
    } 
     
function createFlyingHexAnimation(hex, targetPosition, scene, gameManager, isCombo) { 
    // Bu fonksiyon artık SADECE oyuncunun topladığı ve PENTA TILE'a giden hex'ler için. 
    const goldbergController = gameManager.goldbergController; 

    const colorName = hex.specialColor; 
    if (!colorName) return; // Eğer renk yoksa bir şey yapma 

    const playableHexMaterial = scene.getMaterialByName("playableHexMat"); 
    const glowLayer = scene.getGlowLayerByName("glow"); 

    // Hex'i anında sıfırla ki tekrar toplanmasın 
    hex.material = playableHexMaterial; 
    delete hex.specialColor; 

    const flyingHex = hex.clone("flyingHex_" + Math.random()); 
    flyingHex.material = scene.metadata.hexColors[colorName]; 
    flyingHex.isPlayable = false; 
    flyingHex.setParent(null); 
    flyingHex.position = hex.getAbsolutePosition(); 
     
    if (glowLayer) glowLayer.addIncludedOnlyMesh(flyingHex); 
    createTrailParticles(flyingHex, scene.metadata.hexColors[colorName].diffuseColor, scene); 
     
    // Her toplanan hex, oyuncunun kombo sayacını doldurur. 
    goldbergController.chargeCombo(colorName); 
     
    const frameRate = 60; 
    const animDuration = frameRate * 1.5; // 1.5 saniye uçuş süresi 
     
    const positionAnim = new BABYLON.Animation("hexFlyPos_" + Math.random(), "position", frameRate, BABYLON.Animation.ANIMATIONTYPE_VECTOR3); 
    const midPosition = BABYLON.Vector3.Lerp(flyingHex.position, targetPosition, 0.5); 
    midPosition.y += 5; // Güzel bir kavis için 

    positionAnim.setKeys([ 
        { frame: 0, value: flyingHex.position }, 
        { frame: animDuration / 2, value: midPosition }, 
        { frame: animDuration, value: targetPosition.clone() } 
    ]); 

    const animGroup = scene.beginDirectAnimation(flyingHex, [positionAnim], 0, animDuration, false); 
animGroup.onAnimationEnd = () => {
        // Animasyon bittiğinde...
        createImpactParticles(flyingHex.position, scene.metadata.hexColors[colorName].diffuseColor, scene);
        if (glowLayer) glowLayer.removeIncludedOnlyMesh(flyingHex);

        // --- YENİ EKLENEN KOD BAŞLANGICI ---

        // 1. Penta Tile'a hasar ver (isCombo: false, yani 1 puanlık vuruş).
        const pentaTileController = gameManager.pentaTileController;
        const isWin = pentaTileController.takeHit(false); 
        
        // 2. HUD'ı yeni skorla güncelle.
        gameManager.updateHUD();

        // --- YENİ EKLENEN KOD SONU ---

        // Uçan hex'i yok et.
        flyingHex.dispose();

        // Eğer bu vuruşla oyun kazanıldıysa, oyunu bitir.
        if (isWin) {
            gameManager.endGame(true);
        }
    };
} 


    // --- MAIN SCENE CREATION --- 
function createScene() {
    scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0.05, 0.05, 0.1, 1);
    scene.enablePhysics(GAME_CONSTANTS.PHYSICS_GRAVITY, new BABYLON.CannonJSPlugin());

    new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(3, 1, 0), scene);
    const glowLayer = new BABYLON.GlowLayer("glow", scene);
    glowLayer.intensity = 1.5;

    // --- Materyalleri Oluştur ---
    const solarWarningMat = new BABYLON.StandardMaterial("solarWarningMat", scene);
    solarWarningMat.diffuseColor = new BABYLON.Color3(1.0, 0.4, 0.0);
    solarWarningMat.emissiveColor = new BABYLON.Color3(0.8, 0.3, 0.0);
    solarWarningMat.alpha = 0.5;
    solarWarningMat.disableLighting = true;

    const solarBurningMat = new BABYLON.StandardMaterial("solarBurningMat", scene);
    solarBurningMat.diffuseColor = new BABYLON.Color3(1.0, 0.2, 0.0);
    solarBurningMat.emissiveColor = new BABYLON.Color3(1.0, 0.4, 0.1);
    solarBurningMat.specularColor = new BABYLON.Color3(0, 0, 0);

    const gravityAuraMat = new BABYLON.StandardMaterial("gravityAuraMat", scene);
    gravityAuraMat.diffuseColor = new BABYLON.Color3(0.1, 1.0, 0.2);
    gravityAuraMat.emissiveColor = new BABYLON.Color3(0.1, 1.0, 0.2);
    gravityAuraMat.alpha = 0.15;
    gravityAuraMat.disableLighting = true;
    gravityAuraMat.backFaceCulling = false;

    const hexColors = {
        'ice_blue': new BABYLON.StandardMaterial("iceBlueMat", scene),
        'solar_orange': new BABYLON.StandardMaterial("solarOrangeMat", scene),
        'em_blue': new BABYLON.StandardMaterial("emBlueMat", scene),
        'gravity_green': new BABYLON.StandardMaterial("gravityGreenMat", scene),
        'dark_purple': new BABYLON.StandardMaterial("darkPurpleMat", scene)
    };
    hexColors.ice_blue.diffuseColor = new BABYLON.Color3(0.4, 0.8, 1.0); hexColors.ice_blue.emissiveColor = new BABYLON.Color3(0.2, 0.4, 0.6);
    hexColors.solar_orange.diffuseColor = new BABYLON.Color3(1.0, 0.6, 0.0); hexColors.solar_orange.emissiveColor = new BABYLON.Color3(0.6, 0.3, 0.0);
    hexColors.em_blue.diffuseColor = new BABYLON.Color3(0.2, 0.2, 1.0); hexColors.em_blue.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.5);
    hexColors.gravity_green.diffuseColor = new BABYLON.Color3(0.1, 1.0, 0.2); hexColors.gravity_green.emissiveColor = new BABYLON.Color3(0.05, 0.5, 0.1);
    hexColors.dark_purple.diffuseColor = new BABYLON.Color3(0.7, 0.2, 1.0); hexColors.dark_purple.emissiveColor = new BABYLON.Color3(0.4, 0.1, 0.6);
    scene.metadata = { hexColors: hexColors };

    // --- Doğru Sıralama ---

    // 1. Tüm kontrolcüleri ve ana objeleri oluştur
    gameManager = new GameManager();
    
    const pentagonPoints = calculatePentagonPoints();
    createBoundaryHexagons(scene);
    const ground = createHexGrid(scene, pentagonPoints);
    const wallContainer = createGridBoundaryWalls(scene, pentagonPoints);
    wallContainer.parent = ground;
    
    const centralPentagonMesh = createPentagonTile(scene);
    const centralIcosahedronMesh = createIcosahedronCore(scene);
    createPentaLasers(scene, glowLayer);

    const movementController = new MovementController();
    const goldbergController = new GoldbergController(scene, movementController);
    const joystickController = new Joystick3DController(scene, movementController); // YENİ JOYSTICK
    const cameraController = new CameraController(scene, null);
    const pentaTileController = new PentaTileController(centralPentagonMesh);
    const uiController = new InGameUIController(scene);

    // 2. Kontrolcüleri GameManager'a TANIT
    gameManager.setControllers(pentaTileController, goldbergController, joystickController, cameraController, uiController);
    
    // 3. GameManager ve Kamera hazır olduğuna göre, 3D UI'ları oluştur
    uiController.createUI(cameraController.camera);
    joystickController.createUI(cameraController.camera); // YENİ JOYSTICK'İ OLUŞTUR

    // 4. Oyuncu nesnesini oluştur ve kameranın hedefini ayarla
    const playerMesh = goldbergController.create();
    cameraController.targetMesh = playerMesh;
    cameraController.reset();

    // 5. Klavye ve oyun döngüsü
    scene.onKeyboardObservable.add((kbInfo) => {
        if (!gameManager.state.isRunning) return;
        const isDown = kbInfo.type === BABYLON.KeyboardEventTypes.KEYDOWN;
        switch (kbInfo.event.key.toLowerCase()) {
            case "arrowup": case "w": movementController.moveDirections.forward = isDown; break;
            case "arrowdown": case "s": movementController.moveDirections.backward = isDown; break;
            case "arrowleft": case "a": movementController.moveDirections.left = isDown; break;
            case "arrowright": case "d": movementController.moveDirections.right = isDown; break;
        }
    });

    scene.registerBeforeRender(() => {
        if (!gameManager.state.isRunning) return;

        gameManager.update();
        gameManager.checkMechanicCollisions();
        goldbergController.update();
        cameraController.update();
        updateHexGridDeformation(ground, playerMesh.position);

        ground.getChildMeshes().forEach(hex => {
            if (hex.isPlayable && hex.specialColor) {
                const dist = BABYLON.Vector3.Distance(playerMesh.position, hex.getAbsolutePosition());
                if (dist < 2.5) {
                    createFlyingHexAnimation(hex, centralPentagonMesh.position, scene, gameManager, true);
                }
            }
        });
    });

    return scene;
};



    // --- INITIALIZE GAME --- 
    canvas = document.getElementById("renderCanvas"); 
    engine = new BABYLON.Engine(canvas, true); 
    scene = createScene(); 

    // Show stage select screen initially 
    document.getElementById('stageSelectScreen').style.display = 'flex'; 

    engine.runRenderLoop(() => { 
        if (scene) scene.render(); 
    }); 

window.addEventListener("resize", () => {
    engine.resize();
    
    // Ekran boyutuna göre UI konumlarını güncelle
    if (gameManager && gameManager.joystickController) {
        gameManager.joystickController.updatePositionForOrientation();
    }
    if (gameManager && gameManager.uiController) {
        gameManager.uiController.updatePositionsForOrientation();
    }
});

});
