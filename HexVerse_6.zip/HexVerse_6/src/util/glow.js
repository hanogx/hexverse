export function getGlowLayers(scene){
  const sharedGlow = new BABYLON.GlowLayer('glow', scene); sharedGlow.intensity = 0.8; sharedGlow.blurKernelSize = 64;
  const hex = new BABYLON.GlowLayer('hexGlowLayer', scene); hex.intensity=0.6; hex.blurKernelSize=64;
  const penta = new BABYLON.GlowLayer('pentaGlowLayer', scene); penta.intensity=0.6; penta.blurKernelSize=64;
  const core = new BABYLON.GlowLayer('coreGlowLayer', scene); core.intensity=0.4; core.blurKernelSize=64;
  return { sharedGlow, hex, penta, core };
}