const WORLD_UP = new BABYLON.Vector3(0,1,0);
const WORLD_RIGHT = new BABYLON.Vector3(1,0,0);

export function attachDragRotate(scene, canvas /*, goldbergIgnored */) {
  let isDragging=false; let prevX=0, prevY=0; let velX=0, velY=0; const damping=0.95;

  scene.onPointerObservable.add((pi)=>{
    const ev = pi.event; const sens = 0.008;
    switch (pi.type) {
      case BABYLON.PointerEventTypes.POINTERDOWN:
        isDragging = true; velX = velY = 0; prevX = ev.clientX; prevY = ev.clientY; canvas.style.cursor='grabbing';
        break;
      case BABYLON.PointerEventTypes.POINTERUP:
        isDragging = false; canvas.style.cursor='grab';
        break;
      case BABYLON.PointerEventTypes.POINTERMOVE: {
        if(!isDragging) return;
        const goldberg = scene.getMeshByName('g'); // her level rebuild’inde güncel mesh
        if(!goldberg) return;
        const dx = ev.clientX - prevX; const dy = ev.clientY - prevY;
        const yaw = BABYLON.Quaternion.RotationAxis(WORLD_UP, -dx*sens);
        const pitch = BABYLON.Quaternion.RotationAxis(WORLD_RIGHT, -dy*sens);
        const rot = yaw.multiply(pitch);
        goldberg.rotationQuaternion = goldberg.rotationQuaternion ? rot.multiply(goldberg.rotationQuaternion) : rot;
        velY = -dx*sens; velX = -dy*sens; prevX = ev.clientX; prevY = ev.clientY;
        break;
      }
    }
  });

  scene.registerBeforeRender(()=>{
    const goldberg = scene.getMeshByName('g');
    if(!isDragging && goldberg && goldberg.rotationQuaternion){
      const yawQ = BABYLON.Quaternion.RotationAxis(WORLD_UP, velY);
      const pitchQ = BABYLON.Quaternion.RotationAxis(WORLD_RIGHT, velX);
      goldberg.rotationQuaternion = yawQ.multiply(pitchQ).multiply(goldberg.rotationQuaternion);
      velY *= damping; velX *= damping;
      if(Math.abs(velY)<1e-4) velY=0; if(Math.abs(velX)<1e-4) velX=0;
    }
  });
}
