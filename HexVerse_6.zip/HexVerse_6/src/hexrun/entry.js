import Game from './game/Game.js';
import { SaveStore } from '../shared/SaveStore.js';
import { AudioManager } from '../shared/AudioManager.js';
import { createHexSelectionUI } from './ui/selectionUI.js';

// Expose legacy start hook for selection UI
window.__startHexRun = function(selectedFace) {
  try {
    const f = selectedFace || 'solar';
    window.dispatchEvent(new Event('hexrun:start'));
    const game = new Game(f);
    return game;
  } catch (e) {
    console.error('Failed to start HexRun:', e);
  }
};

// Build the selection UI on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => createHexSelectionUI());
} else {
  createHexSelectionUI();
}

// init shared systems
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => { try { AudioManager.init(); } catch(e){} });
} else {
  try { AudioManager.init(); } catch(e){}
}
