// from legacyEntry.js
export const FireHandlers = {
  solar: {
    single: (game, idx) => game.solarSingleFire(game.projectiles[idx], idx),
    combo:  game => game.solarComboFire()
  },
  em: {
    single: (game, projIndex) => game.emSingleFire(game.projectiles[projIndex], projIndex),
    combo:  game => game.emComboFire()
  },
  gravity: {
    single: (game, projIndex) => game.gravitySingleFire(game.projectiles[projIndex], projIndex),
    combo:  game => game.gravityComboFire()
  },
  dark: {
    single: (game, projIndex) => game.darkSingleFire(game.projectiles[projIndex], projIndex),
    combo:  game => game.darkComboFire()
  },
  wex: {
    single: (game, i) => game.wexSingleFire(game.projectiles[i], i),
    combo: game => game.wexComboFire()
  },
  hexcraft: {
    single: (game, projIndex) => game.darkSingleFire(game.projectiles[projIndex], projIndex),
    combo:  game => game.darkComboFire()
  }
};
