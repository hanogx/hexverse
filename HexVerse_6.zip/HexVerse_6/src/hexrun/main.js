import { createHexSelectionUI } from './ui/selectionUI.js';

window.__startHexRun = async (selectedHexType) => {
  // Game yerine küçük bir orkestratör yüklüyoruz
  const mod = await import('./game/Orchestrator.js?ts=' + Date.now());
  const Game = mod.default || mod.Game;
  document.getElementById('hexSelectionScreen').style.display = 'none';
  document.getElementById('renderCanvas').style.display = 'block';
  document.getElementById('hud').style.display = 'block';
  window.game = new Game(selectedHexType);
};

window.addEventListener('DOMContentLoaded', () => {
  try {
    const saved = JSON.parse(localStorage.getItem('planetData'));
    if (saved) { window.__planetLevel = saved.planetLevel; window.__hexData = saved.hexData; }
  } catch {}
  try {
    const planetLevel = localStorage.getItem('planetLevel');
    const hexData = JSON.parse(localStorage.getItem('hexData') || '{}');
    if (planetLevel) window.__planetLevel = parseInt(planetLevel);
    if (hexData) window.__hexData = hexData;
  } catch {}

  createHexSelectionUI();
});
