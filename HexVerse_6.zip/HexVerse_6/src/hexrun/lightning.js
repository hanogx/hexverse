// Fraktal yıldırım (midpoint displacement)
export function generateFractalLightning(start, end, disp, detail, branchChance=0.3){
  const points=[]; function subdivide(p1,p2,cur){ if(cur<detail){ points.push(p1,p2); } else {
    const mid=p1.add(p2).scale(0.5); const dir=p2.subtract(p1).normalize();
    const perp=BABYLON.Vector3.Cross(dir, BABYLON.Vector3.Up()).normalize();
    const offset=(Math.random()-0.5)*cur; mid.addInPlace(perp.scale(offset));
    subdivide(p1,mid,cur*0.5); subdivide(mid,p2,cur*0.5);
    if(Math.random()<branchChance){ const bdir=BABYLON.Vector3.Cross(dir,perp).normalize(); const blen=cur*(0.7+0.3*Math.random()); const bend=mid.add(bdir.scale(blen)); subdivide(mid,bend,cur*0.5); }
  } }
  subdivide(start,end,disp); return points;
}
