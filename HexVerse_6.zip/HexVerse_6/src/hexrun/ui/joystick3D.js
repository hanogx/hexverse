// from legacyEntry.js
export class Joystick3DController {
    constructor(scene, movementCallback) {
        this.scene = scene;
        this.movementCallback = movementCallback;
        this.camera = null;
        this.uiParent = null;
        this.base = null;
        this.nub = null;
        this.isDragging = false;
        this.pointerId = -1;
        this.baseRadius = 7;
        this.maxPixelRadius = 150;
        this.initialPointerPos = new BABYLON.Vector2(0, 0);
        this._pointerObserver = null;
        
        // Sürekli hareket için
        this._moveInterval = null;
        this._currentMoveX = 0;
        this._currentMoveZ = 0;
    }

    // --- EKRAN ORANINA GÖRE RESPONSIVE POZİSYONLAMA ---
// ActionButtonsController sınıfında updatePosition fonksiyonunu güncelleyin
updatePosition() {
    if (!this.camera || !this.uiParent) return;
    
    // Ekran boyutlarını al
    const engine = this.scene.getEngine();
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const aspectRatio = width / height;
    
    // Viewport boyutlarını hesapla (kameranın görüş alanı)
    const fov = this.camera.fov;
    const distance = this.camera.position.z;
    
    // Viewport genişliği ve yüksekliği (dünya koordinatlarında)
    const viewportHeight = 2.0 * Math.tan(fov / 2) * distance;
    const viewportWidth = viewportHeight * aspectRatio;
    
    // Joystick konumu - SAĞ ALT KÖŞE
    // Ekranın sağ kenarından %15 içeride, alt kenarından %15 yukarıda
    const rightMarginPercent = 0.20;
    const bottomMarginPercent = 0.18;
    
    const xPos = (viewportWidth / 2) * (1 - rightMarginPercent * 2);
    const yPos = -(viewportHeight / 2) * (1 - bottomMarginPercent * 2);
    
    // Z değeri - kameraya olan mesafe
    const zPos = distance * 0.8; // Kameradan biraz önde
    
    this.uiParent.position.set(xPos, yPos, zPos);
}


    createUI(camera) {
        this.camera = camera;
        if (this.uiParent) this.uiParent.dispose();

        this.uiParent = new BABYLON.TransformNode("JoystickUIParent", this.scene);
        this.uiParent.parent = this.camera;

        // Joystick tabanı - HEXAGON
        const baseMaterial = new BABYLON.PBRMaterial("joyBaseMat", this.scene);
        baseMaterial.metallic = 0.3;
        baseMaterial.roughness = 0.7;
        baseMaterial.albedoColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        baseMaterial.alpha = 0.5;

        // Hexagon taban (6 köşeli silindir)
        this.base = BABYLON.MeshBuilder.CreateCylinder("joystickBase", { 
            height: 0.2, 
            diameter: this.baseRadius * 1.5, 
            tessellation: 6  // 6 köşeli hexagon
        }, this.scene);
        this.base.material = baseMaterial;
        this.base.parent = this.uiParent;
        this.base.rotation.x = Math.PI / 2;
        this.base.isPickable = true;

        // Joystick nub (nipple) - HEXAGON
        const nubMaterial = new BABYLON.PBRMaterial("joyNubMat", this.scene);
        nubMaterial.metallic = 0.8;
        nubMaterial.roughness = 0.4;
        nubMaterial.albedoColor = new BABYLON.Color3(0.9, 0.1, 0.1);
        nubMaterial.emissiveColor = new BABYLON.Color3(0.5, 0.05, 0.05);

        // Hexagon nub (6 köşeli silindir)
        this.nub = BABYLON.MeshBuilder.CreateCylinder("joystickNub", { 
            height: 0.5, 
            diameter: 5, 
            tessellation: 6  // 6 köşeli hexagon
        }, this.scene);
        this.nub.material = nubMaterial;
        this.nub.parent = this.base;
        this.nub.position.z = -0.5;  // Orijinal pozisyonu koruyoruz
        this.nub.isPickable = false;

        // Dokunma alanı - görünmez ama tıklanabilir (daha geniş)
        const touchArea = BABYLON.MeshBuilder.CreateCylinder("joystickTouchArea", { 
            diameter: this.baseRadius * 3, 
            height: 0.1,
            tessellation: 6  // Hexagon şeklinde dokunma alanı
        }, this.scene);
        touchArea.visibility = 0;
        touchArea.parent = this.base;
        touchArea.isPickable = true;

        // Pointer olaylarını ayarla
        this._setupPointerEvents();
        
        // Sürekli hareket için render loop'a ekle
        this.scene.registerBeforeRender(() => {
            if (this._currentMoveX !== 0 || this._currentMoveZ !== 0) {
                this.movementCallback(this._currentMoveX, this._currentMoveZ);
            }
        });
        
        this.updatePosition();
        this.adjustUIScale();
        
        window.addEventListener('resize', () => {
            this.updatePosition();
            this.adjustUIScale();
        });
    }
    
    _setupPointerEvents() {
    // Önceki observer'ı temizle
    if (this._pointerObserver) {
        this.scene.onPointerObservable.remove(this._pointerObserver);
    }
    
    // Yeni observer ekle
    this._pointerObserver = this.scene.onPointerObservable.add((pointerInfo) => {
        const event = pointerInfo.event;
        
        // POINTERDOWN - Joystick'e tıklandığında
        if (pointerInfo.type === BABYLON.PointerEventTypes.POINTERDOWN) {
            const pickedMesh = pointerInfo.pickInfo?.pickedMesh;
            
            if (pickedMesh && (pickedMesh === this.base || pickedMesh.name === "joystickTouchArea")) {
                this.isDragging = true;
                this.pointerId = event.pointerId;
                this.initialPointerPos.x = event.clientX;
                this.initialPointerPos.y = event.clientY;
            }
        }
        
        // POINTERMOVE - Sürükleme sırasında
        else if (pointerInfo.type === BABYLON.PointerEventTypes.POINTERMOVE && this.isDragging) {
            if (event.pointerId === this.pointerId) {
                const deltaX = event.clientX - this.initialPointerPos.x;
                const deltaY = event.clientY - this.initialPointerPos.y;
                
                // Hareket vektörünü hesapla
                const moveVector = new BABYLON.Vector2(deltaX, deltaY);
                const distance = moveVector.length();
                
                // Ölü bölge (deadzone) - çok küçük hareketleri filtrele
                const deadzone = 5; // 5 piksel
                if (distance < deadzone) {
                    this._currentMoveX = 0;
                    this._currentMoveZ = 0;
                    this.nub.position.x = 0;
                    this.nub.position.z = 0;
                    return;
                }
                
                // Vektörü sınırla - GÖRSEL SINIR
                const visualLimit = this.maxPixelRadius;
                let visualScale = 1;
                if (distance > visualLimit) {
                    visualScale = visualLimit / distance;
                }
                
                // Nub pozisyonunu güncelle - GÖRSEL SINIR ile
                const nubX = moveVector.x * visualScale / this.maxPixelRadius * (this.baseRadius / 2);
                const nubZ = moveVector.y * visualScale / this.maxPixelRadius * (this.baseRadius / 2);
                
                // Nub'ı hareket ettir - GÖRSEL olarak sınırlı
                this.nub.position.x = nubX;
                this.nub.position.z = nubZ;
                
                // SANAL SINIR - Daha geniş hareket alanı için
                const virtualLimit = this.maxPixelRadius * 2; // 2 kat daha geniş sanal hareket alanı
                
                // Hareket gücünü hesapla - SANAL SINIR ile
                const force = Math.min(1.0, distance / virtualLimit);
                
                // Yön vektörünü normalize et
                const normalizedVector = distance > 0 ? 
                    new BABYLON.Vector2(moveVector.x / distance, moveVector.y / distance) : 
                    new BABYLON.Vector2(0, 0);
                
                // Hareket yönünü düzelt - SANAL SINIR ile ölçeklendir
                this._currentMoveX = normalizedVector.x * (distance / virtualLimit);
                this._currentMoveZ = -normalizedVector.y * (distance / virtualLimit);

                if (this.movementCallback) {
                    this.movementCallback(this._currentMoveX, this._currentMoveZ);
                }
                
                // Joystick'in merkeze olan uzaklığını kaydet - basılı tutma mantığı için
                this.lastDeltaX = deltaX;
                this.lastDeltaY = deltaY;
            }
        }
        
        // POINTERUP - Sürükleme bittiğinde
        else if ((pointerInfo.type === BABYLON.PointerEventTypes.POINTERUP || 
                 pointerInfo.type === BABYLON.PointerEventTypes.POINTEROUT) && 
                 this.isDragging) {
            if (event.pointerId === this.pointerId) {
                this.isDragging = false;
                this.pointerId = -1;
                
                // Nub'ı merkeze getir
                this.nub.position.x = 0;
                this.nub.position.z = 0;
                
                // Hareketi durdur
                this._currentMoveX = 0;
                this._currentMoveZ = 0;
                this.lastDeltaX = 0;
                this.lastDeltaY = 0;
            }
        }
    });
}

adjustUIScale() {
    if (this.uiParent) {
        // Ekran boyutuna göre ölçeklendirme
        const engine = this.scene.getEngine();
        const width = engine.getRenderWidth();
        const height = engine.getRenderHeight();
        
        // Daha küçük ekranlarda daha büyük UI
        const baseScale = 0.15;
        const minDimension = Math.min(width, height);
        
        // Referans çözünürlük (1080p)
        const referenceResolution = 1080;
        
        // Ölçek faktörü: küçük ekranlarda daha büyük, büyük ekranlarda daha küçük
        const scaleFactor = Math.max(0.8, Math.min(1.5, referenceResolution / minDimension));
        
        const finalScale = baseScale * scaleFactor;
        this.uiParent.scaling.setAll(finalScale);
    }
}

    show() {
        if (this.base) this.base.isVisible = true;
        if (this.nub) this.nub.isVisible = true;
    }
    
    hide() {
        if (this.base) this.base.isVisible = false;
        if (this.nub) this.nub.isVisible = false;
    }
}
