// src/hexrun/ui/overview.js
import { getOverview } from '../../shared/PlanetState.js';

export function renderHexOverview(host){
  if (!host) return;
  const data = getOverview();
  const wrap = document.createElement('div');
  wrap.id = 'hexOverview';
  wrap.style.cssText = 'width:100%;max-width:980px;margin:0 auto 16px;display:flex;flex-direction:column;align-items:center;color:#fff;';

  const title = document.createElement('div');
  title.textContent = `Goldberg Energy Matrix — Level ${data.level}`;
  title.style.cssText = 'font-size:18px;margin-bottom:10px;opacity:.9';
  wrap.appendChild(title);

  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:repeat(2,minmax(240px,1fr));gap:12px;width:100%';
  // Colors: gravity is ALWAYS green
  const COLORS = { solar:'#f59e0b', em:'#22d3ee', gravity:'#22c55e', dark:'#a855f7' };

  const pretty = { solar:'Solar', em:'EM', gravity:'Gravity', dark:'Dark Energy' };

  for (const k of ['solar','em','gravity','dark']){
    const r = data.rows[k];
    const card = document.createElement('div');
    card.style.cssText = 'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px;';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;';
    head.innerHTML = `<b>${pretty[k]}</b><span style="font-size:12px;opacity:.9">${r.active} / ${r.total}</span>`;
    const bar = document.createElement('div');
    bar.style.cssText = 'height:8px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden;margin:8px 0;';
    const fill = document.createElement('div');
    fill.style.cssText = `height:100%;width:${Math.round(r.eff*100)}%;background:${COLORS[k]};transition:width .2s`;
    bar.appendChild(fill);
    const meta = document.createElement('div');
    meta.style.cssText = 'font-size:12px;display:flex;justify-content:space-between;opacity:.85';
    meta.innerHTML = `<span>Verimlilik: ${Math.round(r.eff*100)}%</span><span>Gerekli run: <b>${r.need}</b></span>`;
    if (k === data.recommended){
      const badge = document.createElement('span');
      badge.textContent = 'ÖNERİLEN';
      badge.style.cssText = `margin-left:6px;padding:2px 6px;border-radius:8px;background:${COLORS[k]};color:#000;font-weight:700;font-size:10px;`;
      head.appendChild(badge);
    }
    card.appendChild(head); card.appendChild(bar); card.appendChild(meta);
    grid.appendChild(card);
  }
  host.appendChild(wrap);
}
