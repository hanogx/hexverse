// HexRun Selection — unified hx-* theme (same as Penta)
import { Config } from '../../shared/Config.js';

// Legacy start hook provided by entry.js
// window.__startHexRun(face)

export function createHexSelectionUI() {
  const host = document.getElementById('hexSelectionScreen');
  if (!host) return;
  document.getElementById('backInRunHex')?.remove();
  document.querySelector('.hexTopbar')?.remove();

  // Use hx overlay structure
  host.className = 'hx-overlay';
  host.innerHTML = `
    <div class="topbar">
      <button id="hexHubBtn" class="hx-btn ghost sm">Back to Hub</button>
    </div>
    <div class="scroll">
      <div class="panel">
        <h1 class="mb-2">Hex Runs</h1>
        <div id="hex-cards" class="hx-list"></div>
      </div>
    </div>
  `;

  // back to hub (selection screen için sadece bu var)
  const hubBtn = document.getElementById('hexHubBtn');
  hubBtn.onclick = () => { window.location.href = 'index.html'; };

  const list = document.getElementById('hex-cards');

  // Aynı isimlendirme ve görünüm dili
  const FACES = [
    { key:'solar',   name:'Solar' },
    { key:'em',      name:'EM' },
    { key:'gravity', name:'Gravity' },
    { key:'dark',    name:'Dark Energy' }
  ];

  const runCost = (Config?.energy?.costPerRun ?? 1);

  FACES.forEach(face => {
    const card = document.createElement('div');
    card.className = 'hx-card select-item';
    card.dataset.face = face.key;

    card.innerHTML = `
      <div class="head">
        <div class="name">${face.name}</div>
        <div class="count"></div>
      </div>

      <div class="meta">
        <span class="req"><i class="dot energy"></i>Cost ${runCost}</span>
      </div>

      <div class="hx-bar enter">ENTER</div>
    `;

    const go = () => {
      // seçim overlay’i tam temizle
document.body.classList.remove('mode-select');
document.body.classList.add('mode-game');

// Seçim ekranında yaratılmış "Back" vb. butonları gizle/temizle
const topbar = document.querySelector('.hexTopbar'); if (topbar) topbar.remove();
const back   = document.getElementById('backInRunHex'); if (back) back.style.display = 'none';
      // seçim ekranını gizle, run'a gir
      host.remove();
      // ensure canvas/HUD visible
      const cvs = document.getElementById('renderCanvas'); if (cvs) cvs.style.display = 'block';
      const hud = document.getElementById('hud'); if (hud) hud.style.display = 'block';
      if (typeof window.__startHexRun === 'function') {
        window.__startHexRun(face.key);
        // defer back button to next tick so selection DOM is gone
        setTimeout(() => { showHexInRunBack(); window.dispatchEvent(new Event('resize')); }, 0);
      } else {
        console.error('HexRun starter not found');
      }
    };

    card.querySelector('.enter')?.addEventListener('click', (e) => { e.stopPropagation(); go(); });
    card.addEventListener('click', (e) => {
      if (e.target && e.target.closest && e.target.closest('.enter')) return;
      go();
    });

    list.appendChild(card);
  });

  // açık başlat
  host.style.display = 'flex';
}

// Hex run içindeki geri butonu (seçim ekranından bağımsız id/mantık)
function showHexInRunBack() {
  let back = document.getElementById('backInRunHex');
  if (!back) {
    back = document.createElement('button');
    back.id = 'backInRunHex';
    back.className = 'hx-btn ghost sm';
    back.textContent = 'Back';
    back.style.cssText = 'position:fixed;top:12px;left:12px;z-index:900';
    back.addEventListener('click', () => {
      // Basit ve sağlam yol: seçim ekranına geri yükle
      window.location.href = 'hexrun.html';
    });
    document.body.appendChild(back);
  }
  back.style.display = 'inline-flex';
}
