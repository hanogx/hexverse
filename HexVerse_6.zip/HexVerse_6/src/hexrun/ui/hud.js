// from legacyEntry.js
export class GameHUD {
  constructor(game) {
    this.game = game;
    this.scene = game.scene;
    this.gui = game.gui;
    
    // Ana HUD konteynerlerini oluştur
    this.createHUDContainers();
    
    // Aktif bildirimleri ve sayaçları takip etmek için
    this.activeNotifications = [];
    this.activeCountdowns = {};
  }
  
  createHUDContainers() {
    // Üst orta bildirim alanı
    this.notificationContainer = new BABYLON.GUI.StackPanel();
    this.notificationContainer.width = "500px";
    this.notificationContainer.height = "150px";
    this.notificationContainer.horizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_CENTER;
    this.notificationContainer.verticalAlignment = BABYLON.GUI.Control.VERTICAL_ALIGNMENT_TOP;
    this.notificationContainer.top = "120px";
    this.gui.addControl(this.notificationContainer);
    
    // Sağ üst sayaç alanı
    this.countdownContainer = new BABYLON.GUI.StackPanel();
    this.countdownContainer.width = "400px";
    this.countdownContainer.height = "250px";
    this.countdownContainer.horizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_RIGHT;
    this.countdownContainer.verticalAlignment = BABYLON.GUI.Control.VERTICAL_ALIGNMENT_TOP;
    this.countdownContainer.top = "120px";
    this.countdownContainer.right = "20px";
    this.gui.addControl(this.countdownContainer);
    
    // Sol üst durum alanı
    this.statusContainer = new BABYLON.GUI.StackPanel();
    this.statusContainer.width = "400px";
    this.statusContainer.height = "300px";
    this.statusContainer.horizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_LEFT;
    this.statusContainer.verticalAlignment = BABYLON.GUI.Control.VERTICAL_ALIGNMENT_TOP;
    this.statusContainer.top = "120px";
    this.statusContainer.left = "20px";
    this.gui.addControl(this.statusContainer);
  }
  
  // Başarı bildirimi göster
  showNotification(text, color, duration = 2000) {
    const notification = new BABYLON.GUI.TextBlock();
    notification.text = text;
    notification.color = color;
    notification.fontSize = 42;
    notification.fontFamily = "Orbitron";
    notification.height = "50px";
    notification.textHorizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_CENTER;
    notification.outlineWidth = 2;
    notification.outlineColor = "black";

  // Glow efekti için shadow desteği ekle
  notification.shadowBlur = 0; // Varsayılan olarak glow yok
  notification.shadowColor = color;
  notification.shadowOffsetX = 0;
  notification.shadowOffsetY = 0;
    
    // Animasyon için başlangıç değerleri
    notification.alpha = 0;
    notification.scaleX = 0.5;
    notification.scaleY = 0.5;
    
    this.notificationContainer.addControl(notification);
    this.activeNotifications.push(notification);
    
    // Giriş animasyonu
    const fadeInAnimation = () => {
      notification.alpha += 0.1;
      notification.scaleX += 0.05;
      notification.scaleY += 0.05;
      
      if (notification.alpha < 1) {
        requestAnimationFrame(fadeInAnimation);
      } else {
        // Tam görünür olduktan sonra
        notification.alpha = 1;
        notification.scaleX = 1;
        notification.scaleY = 1;
        
        // Belirli süre sonra kaybolma animasyonu
        setTimeout(() => {
          const fadeOutAnimation = () => {
            notification.alpha -= 0.05;
            
            if (notification.alpha > 0) {
              requestAnimationFrame(fadeOutAnimation);
            } else {
              // Tamamen kaybolduğunda kaldır
              this.notificationContainer.removeControl(notification);
              const index = this.activeNotifications.indexOf(notification);
              if (index !== -1) {
                this.activeNotifications.splice(index, 1);
              }
            }
          };
          fadeOutAnimation();
        }, duration);
      }
    };
    
    fadeInAnimation();
    
    return notification;
  }
  
  // Geri sayım göster
  showCountdown(id, text, color, duration, onComplete = null) {
    // Önceki aynı ID'li sayacı temizle
    if (this.activeCountdowns[id]) {
      this.countdownContainer.removeControl(this.activeCountdowns[id].control);
      clearInterval(this.activeCountdowns[id].interval);
      delete this.activeCountdowns[id];
    }
    
    const countdownControl = new BABYLON.GUI.Rectangle();
    countdownControl.width = "280px";
    countdownControl.height = "60px";
    countdownControl.cornerRadius = 10;
    countdownControl.color = color;
    countdownControl.thickness = 2;
    countdownControl.background = "rgba(0, 0, 0, 0.5)";
    
    const countdownText = new BABYLON.GUI.TextBlock();
    countdownText.text = `${text}: ${(duration / 1000).toFixed(1)}s`;
    countdownText.color = color;
    countdownText.fontSize = 36;
    countdownText.fontFamily = "Rajdhani";
    
    countdownControl.addControl(countdownText);
    this.countdownContainer.addControl(countdownControl);
    
    const startTime = performance.now();
    const interval = setInterval(() => {
      const elapsedTime = performance.now() - startTime;
      const remainingTime = Math.max(0, duration - elapsedTime);
      
      if (remainingTime <= 0) {
        clearInterval(interval);
        this.countdownContainer.removeControl(countdownControl);
        delete this.activeCountdowns[id];
        
        if (onComplete) onComplete();
      } else {
        countdownText.text = `${text}: ${(remainingTime / 1000).toFixed(1)}s`;
        
        // Son 3 saniyede renk değişimi
        if (remainingTime < 3000) {
          countdownText.color = "red";
          countdownControl.color = "red";
        }
      }
    }, 100);
    
    this.activeCountdowns[id] = {
      control: countdownControl,
      interval: interval
    };
    
    return countdownControl;
  }
  
  // Durum bildirimi göster
  showStatus(id, text, color, duration = 3000) {

    const statusControl = new BABYLON.GUI.Rectangle();
    statusControl.width = "280px";
    statusControl.height = "60px";
    statusControl.cornerRadius = 10;
    statusControl.color = color;
    statusControl.thickness = 2;
    statusControl.background = "rgba(0, 0, 0, 0.5)";
    statusControl.alpha = 0;
    statusControl.name = id;
    
    const statusText = new BABYLON.GUI.TextBlock();
    statusText.text = text;
    statusText.color = color;
    statusText.fontSize = 36;
    statusText.fontFamily = "Rajdhani";
    
    statusControl.addControl(statusText);
    this.statusContainer.addControl(statusControl);
    
    // Giriş animasyonu
    let alpha = 0;
    const fadeIn = () => {
      alpha += 0.1;
      statusControl.alpha = alpha;
      
      if (alpha < 1) {
        requestAnimationFrame(fadeIn);
      } else {
        if (duration > 0) {
          setTimeout(() => {
            let fadeAlpha = 1;
            const fadeOut = () => {
              fadeAlpha -= 0.05;
              statusControl.alpha = fadeAlpha;
              
              if (fadeAlpha > 0) {
                requestAnimationFrame(fadeOut);
              } else {
                this.statusContainer.removeControl(statusControl);
              }
            };
            fadeOut();
          }, duration);
        }
      }
    };
    
    fadeIn();
    
    return statusControl;
  }
  
  // Özel başarı bildirimleri
showMexShot() {
  // Run tipine göre renk seç
  let color;
  switch(this.game.initialFace) {
    case 'solar':
      color = "#FFA500"; // Turuncu
      break;
    case 'em':
      color = "#00BFFF"; // Mavi
      break;
    case 'gravity':
      color = "#32CD32"; // Yeşil
      break;
    case 'dark':
      color = "#9932CC"; // Mor
      break;
    default:
      color = "#FFA500"; // Varsayılan turuncu
  }
  
  const notification = this.showNotification("MEX SHOT!", color, 1500);
  
  // Daha kalın yazı ve glow efekti
  notification.fontWeight = "bold";
  notification.shadowBlur = 10;
  notification.shadowColor = color;
  notification.shadowOffsetX = 0;
  notification.shadowOffsetY = 0;
  notification.outlineWidth = 3; // Daha kalın outline
  
  return notification;
}

showWexShot() {
  const color = "#00BFFF"; // WEX için mavi
  const notification = this.showNotification("WEX SHOT!", color, 1500);
  
  // Daha kalın yazı ve glow efekti
  notification.fontWeight = "bold";
  notification.shadowBlur = 10;
  notification.shadowColor = color;
  notification.shadowOffsetX = 0;
  notification.shadowOffsetY = 0;
  notification.outlineWidth = 3; // Daha kalın outline
  
  return notification;
}

  
showComboReady() {
  // 500ms gecikme ekleyerek "MEX/WEX Shot!" yazısının önce görünmesini sağla
  setTimeout(() => {
    this.showNotification("COMBO READY!", "#FFD700", 2000);
  }, 500);
}
  
  showPerfect() {
    const perfect = this.showNotification("PERFECT!", "#FF00FF", 2000);
    perfect.fontSize = 48; // Daha büyük font
    return perfect;
  }
  
  // Özel sayaçlar
  showSolarComboTimer(duration) {
    return this.showCountdown("solarCombo", "Solar Burst", "#FFA500", duration);
  }
  
  showEMShieldTimer(duration) {
    return this.showCountdown("emShield", "Shield", "#00BFFF", duration);
  }
  
  showGravityStunTimer(duration) {
    return this.showCountdown("gravityStun", "Time Freeze", "#32CD32", duration);
  }
  
  showDarkPortalsTimer(duration) {
    return this.showCountdown("darkPortals", "Portals", "#9932CC", duration);
  }
  
  showWexComboTimer(duration) {
    return this.showCountdown("wexCombo", "Ice Storm", "#00BFFF", duration);
  }
  
  // Özel durum bildirimleri
showModeSwitch(mode) {
  // Rengi belirle - MEX modunda run rengini, WEX modunda mavi rengi kullan
  let color;
  if (mode === "mex") {
    // Run tipine göre renk seç
    switch(this.game.initialFace) {
      case 'solar':
        color = "#FFA500"; // Turuncu
        break;
      case 'em':
        color = "#00BFFF"; // Mavi
        break;
      case 'gravity':
        color = "#32CD32"; // Yeşil
        break;
      case 'dark':
        color = "#9932CC"; // Mor
        break;
      default:
        color = "#FFA500"; // Varsayılan turuncu
    }
  } else {
    color = "#00BFFF"; // WEX modu için mavi
  }
  
  const text = mode === "mex" ? "MEX MODE" : "WEX MODE";
  return this.showStatus("modeSwitch", text, color);
}

  showEnergyDrained() {
    return this.showStatus("energyDrained", "ENERGY DRAINED!", "#FF0000", 2000);
  }
  
showEnergyGained() {
  return this.showStatus("energyGained", "ENERGY GAINED!", "#32CD32", 2000); // Yeşil renk
}
  showImmunityActive() {
    return this.showStatus("immunity", "SHIELD ACTIVE", "#00BFFF", 0); // Süresiz
  }
  
  hideImmunity() {
    // İlgili durum bildirimini kaldır
    const controls = this.statusContainer.children;
    for (let i = 0; i < controls.length; i++) {
      if (controls[i].name === "immunity") {
        this.statusContainer.removeControl(controls[i]);
        break;
      }
    }
  }
  
  // Tüm bildirimleri temizle
  clearAll() {
    // Tüm bildirimleri temizle
    while (this.activeNotifications.length > 0) {
      const notification = this.activeNotifications.pop();
      this.notificationContainer.removeControl(notification);
    }
    
    // Tüm sayaçları temizle
    for (const id in this.activeCountdowns) {
      clearInterval(this.activeCountdowns[id].interval);
      this.countdownContainer.removeControl(this.activeCountdowns[id].control);
    }
    this.activeCountdowns = {};
    
    // Tüm durum bildirimlerini temizle
    while (this.statusContainer.children.length > 0) {
      this.statusContainer.removeControl(this.statusContainer.children[0]);
    }
  }
}


// ----- Minimal Back button (non-invasive) -----
function __attachTopbar(){
  // Prevent duplicates
  if (document.getElementById('backInRunHex')) return;
  const back = document.createElement('button');
  back.id = 'backInRunHex';
  back.className = 'hx-btn ghost sm hx-fab';
  back.textContent = 'Back';
  back.addEventListener('click', ()=>{ window.location.href = 'hexrun.html'; });
  document.body.appendChild(back);
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', __attachTopbar);
} else {
  setTimeout(__attachTopbar, 30);
}
