// from legacyEntry.js
export class ActionButtonsController {
    constructor(scene, fireCallback, comboCallback) {
        this.scene = scene;
        this.fireCallback = fireCallback;
        this.comboCallback = comboCallback;
        this.flipCallback = null;
        this.camera = null;
        this.uiParent = null;
        this.fireButton = null;
        this.comboButton = null;
        this.flipButton = null;
        this.isComboEnabled = false;
        
        // Materyalleri tanımla
        this.fireMat = null;
        this.fireCapMat = null;
        this.comboMat_active = null;
        this.comboCapMat_active = null;
        this.comboMat_inactive = null;
        this.comboCapMat_inactive = null;
        this.flipMat = null;
        this.flipCapMat = null; 
    }

setFlipCallback(callback) {
    this.flipCallback = callback;
}


    _cleanupOldUI() {
        this.scene.getTransformNodeByName("ActionButtonsParent")?.dispose();
        if (this.fireButton) this.fireButton.dispose();
        if (this.comboButton) this.comboButton.dispose();
        this.fireButton = null;
        this.comboButton = null;
        this.flipButton = null;
        this.uiParent = null;
    }
    
    // --- EKRAN ORANINA GÖRE RESPONSIVE POZİSYONLAMA ---
updatePosition() {
    if (!this.camera || !this.uiParent) return;
    
    // Ekran boyutlarını al
    const engine = this.scene.getEngine();
    const width = engine.getRenderWidth();
    const height = engine.getRenderHeight();
    const aspectRatio = width / height;
    
    // Viewport boyutlarını hesapla (kameranın görüş alanı)
    const fov = this.camera.fov;
    const distance = this.camera.position.z;
    
    // Viewport genişliği ve yüksekliği (dünya koordinatlarında)
    const viewportHeight = 2.0 * Math.tan(fov / 2) * distance;
    const viewportWidth = viewportHeight * aspectRatio;
    
    // Butonlar konumu - SOL ALT KÖŞE
    // Ekranın sol kenarından %15 içeride, alt kenarından %15 yukarıda
    const leftMarginPercent = 0.18;
    const bottomMarginPercent = 0.25;
    
    const xPos = -(viewportWidth / 2) * (1 - leftMarginPercent * 2);
    const yPos = -(viewportHeight / 2) * (1 - bottomMarginPercent * 2);
    
    // Z değeri - kameraya olan mesafe
    const zPos = distance * 0.8; // Kameradan biraz önde
    
    this.uiParent.position.set(xPos, yPos, zPos);
}

createUI(camera) {
        this.camera = camera;
        this._cleanupOldUI();
        
        this.uiParent = new BABYLON.TransformNode("ActionButtonsParent", this.scene);
        this.uiParent.parent = camera;

        const basePBR = new BABYLON.PBRMaterial("buttonPBRMat", this.scene);
        basePBR.metallic = 0.3;
        basePBR.roughness = 0.4;
        basePBR.alpha = 0.6;
        
        this.fireMat = basePBR.clone("fireMat");
        this.fireMat.albedoColor = new BABYLON.Color3(0.8, 0.1, 0.1);
        this.fireMat.emissiveColor = new BABYLON.Color3(0.4, 0.05, 0.05);
        
        this.fireCapMat = basePBR.clone("fireCapMat");
        this.fireCapMat.albedoColor = new BABYLON.Color3(0.9, 0.2, 0.2);
        this.fireCapMat.emissiveColor = new BABYLON.Color3(0.5, 0.1, 0.1);
        
        this.comboMat_active = basePBR.clone("comboMatActive");
        this.comboMat_active.albedoColor = new BABYLON.Color3(1, 0.8, 0);
        this.comboMat_active.emissiveColor = new BABYLON.Color3(0.5, 0.4, 0);
        
        this.comboCapMat_active = basePBR.clone("comboCapMatActive");
        this.comboCapMat_active.albedoColor = new BABYLON.Color3(1, 0.9, 0);
        this.comboCapMat_active.emissiveColor = new BABYLON.Color3(0.6, 0.5, 0);
        
        this.comboMat_inactive = basePBR.clone("comboMatInactive");
        this.comboMat_inactive.albedoColor = new BABYLON.Color3(0.2, 0.2, 0.2);
        this.comboMat_inactive.emissiveColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        this.comboMat_inactive.alpha = 0.5;
        
        this.comboCapMat_inactive = basePBR.clone("comboCapMatInactive");
        this.comboCapMat_inactive.albedoColor = new BABYLON.Color3(0.3, 0.3, 0.3);
        this.comboCapMat_inactive.emissiveColor = new BABYLON.Color3(0.15, 0.15, 0.15);
        this.comboCapMat_inactive.alpha = 0.5;
        
        // Flip buton materyalleri
        this.flipMat = basePBR.clone("flipMat");
        this.flipMat.albedoColor = new BABYLON.Color3(0.1, 0.4, 0.8); // Mavi renk
        this.flipMat.emissiveColor = new BABYLON.Color3(0.05, 0.2, 0.4);
        
        this.flipCapMat = basePBR.clone("flipCapMat");
        this.flipCapMat.albedoColor = new BABYLON.Color3(0.2, 0.5, 0.9);
        this.flipCapMat.emissiveColor = new BABYLON.Color3(0.1, 0.25, 0.45);

        const createButton = (name, yPos) => {
            const button = BABYLON.MeshBuilder.CreateCylinder(name, { height: 1, diameter: 5, tessellation: 6 }, this.scene);
            button.parent = this.uiParent;
            button.position.y = yPos;
            button.rotation.x = Math.PI / 2;
            
            const cap = BABYLON.MeshBuilder.CreateCylinder(name + "Cap", { height: 0.2, diameter: 4.5, tessellation: 6 }, this.scene);
            cap.parent = button;
            cap.position.y = 0.6;
            return button;
        };

        // Butonların yerlerini ayarla - COMBO BUTON ÜSTTE, FIRE BUTON ORTADA, FLIP BUTON ALTTA
        this.comboButton = createButton("comboButton", 0);
        this.fireButton = createButton("fireButton", -6);
        this.flipButton = createButton("flipButton", -12); // Fire butonunun altında
        
        this.fireButton.material = this.fireMat;
        this.fireButton.getChildren()[0].material = this.fireCapMat;
        
        this.flipButton.material = this.flipMat;
        this.flipButton.getChildren()[0].material = this.flipCapMat;
        
        const setupActions = (button, callback) => {
           if (!callback) return; // Callback yoksa işlem yapma
    
    button.actionManager = new BABYLON.ActionManager(this.scene);
    const action = new BABYLON.ExecuteCodeAction(
        BABYLON.ActionManager.OnPickTrigger, 
        () => {
            // isEnabled özelliğini kontrol et (sadece combo butonu için)
            if (button === this.comboButton && !this.isComboEnabled) return;
            
            callback();
            
            // Animasyon
            if (button._isAnimating) return;
            button._isAnimating = true;
            
            const startScale = button.scaling.clone();
            const animation = new BABYLON.Animation(
                "clickAnimation",
                "scaling",
                30,
                BABYLON.Animation.ANIMATIONTYPE_VECTOR3
            );
            
            animation.setKeys([
                { frame: 0, value: startScale },
                { frame: 5, value: startScale.scale(0.85) },
                { frame: 10, value: startScale }
            ]);
            
            button.animations = [animation];
            this.scene.beginAnimation(button, 0, 10, false, 1, () => {
                button._isAnimating = false;
            });
        }
    );
    button.actionManager.registerAction(action);
    
    // Kapak için de aynı aksiyonu ekle
    const cap = button.getChildren()[0];
    cap.actionManager = new BABYLON.ActionManager(this.scene);
    cap.actionManager.registerAction(action);
};

        setupActions(this.fireButton, this.fireCallback);
        setupActions(this.comboButton, this.comboCallback);
if (this.flipButton) {
    setupActions(this.flipButton, this.flipCallback);
}
        
        this.updateComboButtonState(false);
        this.updatePosition(); // İlk pozisyonu hesapla
        this.adjustUIScale();
        window.addEventListener('resize', () => this.updatePosition());
    }


    
    updateComboButtonState(isEnabled) {
        if (!this.comboButton) return;
        
        this.isComboEnabled = isEnabled;
        const glowLayer = this.scene.getGlowLayerByName("glow");
        const comboCap = this.comboButton.getChildren()[0];

        if (isEnabled) {
            this.comboButton.material = this.comboMat_active;
            comboCap.material = this.comboCapMat_active;
            if (glowLayer) glowLayer.addIncludedOnlyMesh(comboCap);
        } else {
            this.comboButton.material = this.comboMat_inactive;
            comboCap.material = this.comboCapMat_inactive;
            if (glowLayer) glowLayer.removeIncludedOnlyMesh(comboCap);
        }
    }
    
adjustUIScale() {
    if (this.uiParent) {
        // Ekran boyutuna göre ölçeklendirme
        const engine = this.scene.getEngine();
        const width = engine.getRenderWidth();
        const height = engine.getRenderHeight();
        
        // Daha küçük ekranlarda daha büyük UI
        const baseScale = 0.15;
        const minDimension = Math.min(width, height);
        
        // Referans çözünürlük (1080p)
        const referenceResolution = 1080;
        
        // Ölçek faktörü: küçük ekranlarda daha büyük, büyük ekranlarda daha küçük
        const scaleFactor = Math.max(0.8, Math.min(1.5, referenceResolution / minDimension));
        
        const finalScale = baseScale * scaleFactor;
        this.uiParent.scaling.setAll(finalScale);
    }
}
    
    show() {
        if (this.fireButton) this.fireButton.isVisible = true;
        if (this.comboButton) this.comboButton.isVisible = true;
    }
    
    hide() {
        if (this.fireButton) this.fireButton.isVisible = false;
        if (this.comboButton) this.comboButton.isVisible = false;
    }
}
