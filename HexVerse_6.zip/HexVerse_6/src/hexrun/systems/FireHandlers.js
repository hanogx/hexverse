export { FireHandlers as default, FireHandlers } from "../core/fireHandlers.js";
