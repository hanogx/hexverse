export function createHubButtons(scene, camera, glow){
  const parent = new BABYLON.TransformNode('hubButtonsUIParent', scene);
  parent.parent = camera; parent.position = new BABYLON.Vector3(0,-3.5,12); parent.scaling = new BABYLON.Vector3(0.5,0.5,0.5);

  // Materials
  const hexBlueMat = new BABYLON.PBRMaterial('hexBlueMat', scene); hexBlueMat.albedoColor=new BABYLON.Color3(0,0.75,1); hexBlueMat.emissiveColor=new BABYLON.Color3(0,0.5,0.8); hexBlueMat.metallic=0.8; hexBlueMat.roughness=0.2; hexBlueMat.alpha=0.7;
  const pentaRedMat = new BABYLON.PBRMaterial('pentaRedMat', scene); pentaRedMat.albedoColor=new BABYLON.Color3(1,0.2,0.2); pentaRedMat.emissiveColor=new BABYLON.Color3(0.8,0.2,0.2); pentaRedMat.metallic=0.8; pentaRedMat.roughness=0.2; pentaRedMat.alpha=0.7;
  const coreRunMat = new BABYLON.PBRMaterial('coreRunMat', scene); coreRunMat.albedoColor=new BABYLON.Color3(1.0,0.5,0.1); coreRunMat.emissiveColor=new BABYLON.Color3(0.8,0.4,0.1); coreRunMat.metallic=0.8; coreRunMat.roughness=0.2; coreRunMat.alpha=0.4;
  const coreSphereMat = new BABYLON.PBRMaterial('coreSpheremat', scene); coreSphereMat.albedoColor=new BABYLON.Color3(1.0,0.1,0.1); coreSphereMat.emissiveColor=new BABYLON.Color3(1.0,0.2,0.2); coreSphereMat.metallic=0.5; coreSphereMat.roughness=0.2;
  const pvpSoonMat = new BABYLON.PBRMaterial('pvpSoonMat', scene); pvpSoonMat.albedoColor=new BABYLON.Color3(0.4,0.4,0.4); pvpSoonMat.emissiveColor=new BABYLON.Color3(0.2,0.2,0.2); pvpSoonMat.metallic=0.5; pvpSoonMat.roughness=0.5; pvpSoonMat.alpha=0.5;

  const hexButton = BABYLON.MeshBuilder.CreateCylinder('hexButton', {height:0.3, diameter:2.0, tessellation:6, updatable:true}, scene); hexButton.material = hexBlueMat; hexButton.parent = parent; hexButton.position.x = -3.6; hexButton.rotation.x = Math.PI/2;
  const pentaButton = BABYLON.MeshBuilder.CreateCylinder('pentaButton', {height:0.3, diameter:2.0, tessellation:5, updatable:true}, scene); pentaButton.material = pentaRedMat; pentaButton.parent = parent; pentaButton.position.x=-1.2; pentaButton.rotation.x = Math.PI/2;
  const coreRunPenta = BABYLON.MeshBuilder.CreateCylinder('coreRunPenta', {height:0.3, diameter:2.0, tessellation:5, updatable:true}, scene); coreRunPenta.material=coreRunMat; coreRunPenta.parent = parent; coreRunPenta.position.x=1.2; coreRunPenta.rotation.x = Math.PI/2;
  const coreSphere = BABYLON.MeshBuilder.CreateSphere('coreSphere', { diameter:1.0, segments:16 }, scene); coreSphere.material = coreSphereMat; coreSphere.parent = coreRunPenta; coreSphere.position.z = 0.0;
  const pvpGoldberg = BABYLON.MeshBuilder.CreateGoldberg('pvpGoldberg', { m:3, n:0, size:0.9 }, scene); pvpGoldberg.material = pvpSoonMat; pvpGoldberg.parent = parent; pvpGoldberg.position.x = 3.6; pvpGoldberg.rotation.x = Math.PI/2;

  if(glow){ glow.hex.addIncludedOnlyMesh(hexButton); glow.penta.addIncludedOnlyMesh(pentaButton); glow.core.addIncludedOnlyMesh(coreRunPenta); glow.core.addIncludedOnlyMesh(coreSphere); }

  const createLabel=(button, text, italic=false)=>{
    const plane = BABYLON.MeshBuilder.CreatePlane('lbl_'+button.name, {width:2.0, height:1.0}, scene);
    plane.parent = parent; plane.position.x = button.position.x; plane.position.y = (button.position.y||0) - 1.5;
    const mat = new BABYLON.StandardMaterial('lblmat_'+button.name, scene); mat.diffuseColor = new BABYLON.Color3(0,0,0); mat.specularColor = new BABYLON.Color3(0,0,0); mat.emissiveColor = new BABYLON.Color3(1,1,1); mat.backFaceCulling=false; plane.material = mat;
    const tex = new BABYLON.DynamicTexture('lbltex_'+button.name, {width:256, height:128}, scene); mat.diffuseTexture = tex; mat.useAlphaFromDiffuseTexture = true; tex.hasAlpha = true;
    const ctx = tex.getContext(); ctx.clearRect(0,0,256,128); ctx.font = (italic? 'italic ':'') + 'bold 36px Arial'; ctx.fillStyle = italic ? 'rgba(255,255,255,0.5)' : 'white'; ctx.textAlign='center'; ctx.textBaseline='middle';
    text.split('\n').forEach((line,i)=>{ const y = 64 + (i - (text.split('\n').length - 1)/2)*40; ctx.fillText(line, 128, y); }); tex.update();
  };
  createLabel(hexButton, 'ENTER\nHEX'); createLabel(pentaButton, 'ENTER\nPENTA'); createLabel(coreRunPenta, 'ENTER\nCORE'); createLabel(pvpGoldberg, 'PvP\nSOON', true);

  const animate=(mesh, hover)=>{
    const scale = hover?1.1:1.0; BABYLON.Animation.CreateAndStartAnimation('scaleAnim', mesh, 'scaling', 30, 10, mesh.scaling, new BABYLON.Vector3(scale,scale,scale), BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
    if(mesh.material){ BABYLON.Animation.CreateAndStartAnimation('emissiveAnim', mesh.material, 'emissiveIntensity', 30, 10, mesh.material.emissiveIntensity||0.5, hover?1.0:0.5, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT); }
  };
  const click=(mesh, layer)=>{ if(mesh.material){ mesh.material.emissiveIntensity = 3.0; } if(layer){ layer.intensity = 1.5; } setTimeout(()=>{ if(mesh.material) mesh.material.emissiveIntensity=0.5; if(layer) layer.intensity=0.8; }, 200); };
  const bind=(m, fn)=>{ m.actionManager = new BABYLON.ActionManager(scene); m.actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPointerOverTrigger, ()=>animate(m,true))); m.actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPointerOutTrigger, ()=>animate(m,false))); m.actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPickTrigger, fn)); };

  bind(hexButton, ()=>{ click(hexButton, glow?.hex); window.location.href = "hexrun.html"; });
  bind(pentaButton, ()=>{ click(pentaButton, glow?.penta); window.location.href = "pentarun.html?stage=select"; });
  bind(coreRunPenta, ()=>{ click(coreRunPenta, glow?.core); click(coreSphere, glow?.core); window.location.href = "pentarun.html?mode=core"; });
  bind(coreSphere, ()=>{ click(coreRunPenta, glow?.core); click(coreSphere, glow?.core); window.location.href = "pentarun.html?mode=core"; });

  pvpGoldberg.actionManager = new BABYLON.ActionManager(scene);
  pvpGoldberg.actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPointerOverTrigger, ()=>{
    BABYLON.Animation.CreateAndStartAnimation('pvpHover', pvpGoldberg, 'scaling', 30, 10, pvpGoldberg.scaling, new BABYLON.Vector3(1.05,1.05,1.05), BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
  }));
  pvpGoldberg.actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPointerOutTrigger, ()=>{
    BABYLON.Animation.CreateAndStartAnimation('pvpOut', pvpGoldberg, 'scaling', 30, 10, pvpGoldberg.scaling, new BABYLON.Vector3(1,1,1), BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
  }));

  return { hexButton, pentaButton, coreRunButton: coreRunPenta, coreSphere, pvpButton: pvpGoldberg, container: parent, ...glow };
}