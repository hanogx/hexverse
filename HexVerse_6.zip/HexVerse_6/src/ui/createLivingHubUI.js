import { SaveStore } from '../shared/SaveStore.js';
import { levelData } from '../systems/levelData.js';

export function createLivingHubUI(scene){
  const removeOld = document.getElementById('living-hub-ui'); if(removeOld) removeOld.remove();
  const link=document.createElement('link'); link.rel='stylesheet'; link.href='https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700&family=Rajdhani:wght@500;600;700&display=swap'; document.head.appendChild(link);
  const colors={ hexBlue:'#00BFFF', pentaRed:'#FF3A44', coreDeepRed:'#8B0000', solarOrange:'#FFA500', emBlue:'#4169E1', gravityGreen:'#32CD32', darkPurple:'#9932CC', background:'rgba(0,0,0,0.7)', text:'#FFFFFF' };

  const data={ planetLevel:0, hexData:{ solar:{active:6,total:8}, em:{active:6,total:8}, gravity:{active:5,total:7}, darkEnergy:{active:5,total:7} }, pentaData:{active:5,total:12} };
  const root=document.createElement('div'); root.id='living-hub-ui'; Object.assign(root.style,{position:'absolute',top:'0',left:'0',width:'100%',height:'100%',pointerEvents:'none',fontFamily:"'Orbitron', 'Rajdhani', sans-serif",color:colors.text,zIndex:'1000'});

  // Top-left panel (level + selector)
  const tl=document.createElement('div'); Object.assign(tl.style,{position:'absolute',top:'20px',left:'20px',padding:'10px 15px',backgroundColor:'rgba(0,0,0,0.6)',borderRadius:'8px',backdropFilter:'blur(5px)',border:'1px solid rgba(255,255,255,0.2)',pointerEvents:'auto'});
  const row=document.createElement('div'); Object.assign(row.style,{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'10px'});
  const lvlInfo=document.createElement('div'); lvlInfo.textContent='BASE LEVEL'; Object.assign(lvlInfo.style,{color:colors.text,fontSize:'16px',fontWeight:'bold',textShadow:`0 0 10px ${colors.hexBlue}`,letterSpacing:'1px'});
  const up=document.createElement('div'); up.innerHTML='▲'; Object.assign(up.style,{width:'24px',height:'24px',backgroundColor:'rgba(0,0,0,0.5)',color:colors.text,border:`1px solid ${colors.text}`,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',marginLeft:'10px',boxShadow:'0 0 5px rgba(255,255,255,0.3)',fontSize:'12px'});
  up.onmouseover=()=>{ up.style.backgroundColor='rgba(255,255,255,0.9)'; up.style.color='black'; up.style.boxShadow='0 0 10px rgba(255,255,255,0.8)'; };
  up.onmouseout =()=>{ up.style.backgroundColor='rgba(0,0,0,0.5)'; up.style.color=colors.text; up.style.boxShadow='0 0 5px rgba(255,255,255,0.3)'; };
  up.onclick=()=> alert('Upgrade screen is not ready yet!');
  row.appendChild(lvlInfo); row.appendChild(up); tl.appendChild(row);

  const label=document.createElement('div'); label.textContent='SELECT LEVEL'; Object.assign(label.style,{color:'#AAA',fontSize:'12px',marginBottom:'5px'}); tl.appendChild(label);
  const select=document.createElement('select'); Object.assign(select.style,{width:'100%',padding:'5px',backgroundColor:'rgba(0,0,0,0.8)',color:colors.text,border:'1px solid rgba(255,255,255,0.2)',borderRadius:'6px',outline:'none',pointerEvents:'auto'});
  const base=new Option('Base Level', 0); select.appendChild(base); for(let i=1;i<=30;i++){ select.appendChild(new Option(`Level ${i}`, i)); }
select.onchange = () => {
  const newLevel = parseInt(select.value);
  data.planetLevel = newLevel;
  lvlInfo.textContent = newLevel === 0 ? 'BASE LEVEL' : `PLANET LEVEL: ${newLevel}`;
  if (newLevel >= 0 && newLevel < levelData.length) {
    const L = levelData[newLevel];
    data.hexData = {
      solar:   {active: Math.floor(L.solar*0.8),   total: L.solar},
      em:      {active: Math.floor(L.electro*0.8), total: L.electro},
      gravity: {active: Math.floor(L.gravity*0.8), total: L.gravity},
      darkEnergy:{active: Math.floor(L.dark*0.8),  total: L.dark}
    };
    const pTotal = Math.min(12, 6 + Math.floor(newLevel/3));
    data.pentaData = {active: Math.floor(pTotal*0.8), total: pTotal};
    update(data);
    SaveStore.set('goldberg.level', newLevel);
    if (window.hexverse && typeof window.hexverse.setLevel === 'function') window.hexverse.setLevel(newLevel);
  }
};

  tl.appendChild(select); root.appendChild(tl);

  // Top-right stats
  const tr=document.createElement('div'); Object.assign(tr.style,{position:'absolute',top:'20px',right:'20px',padding:'15px',backgroundColor:'rgba(0,0,0,0.6)',borderRadius:'10px',backdropFilter:'blur(5px)',boxShadow:'0 0 15px rgba(0,0,0,0.7)',pointerEvents:'auto'});
  const mkRow=(label,color)=>{ const r=document.createElement('div'); Object.assign(r.style,{display:'flex',justifyContent:'space-between',alignItems:'center',margin:'4px 0'}); const l=document.createElement('div'); l.textContent=label; Object.assign(l.style,{color, fontWeight:'600'}); const s=document.createElement('div'); s.textContent='0/0 (0%)'; r.appendChild(l); r.appendChild(s); return {row:r, stat:s}; };
  const solar=mkRow('Solar Hex', colors.solarOrange), em=mkRow('EM Hex', colors.emBlue), grav=mkRow('Gravity Hex', colors.gravityGreen), dark=mkRow('Dark Energy Hex', colors.darkPurple);
  [solar.row, em.row, grav.row, dark.row].forEach(el=>tr.appendChild(el));
  const pentaTitle=document.createElement('div'); pentaTitle.textContent='Penta'; Object.assign(pentaTitle.style,{marginTop:'10px', color:colors.pentaRed, fontWeight:'700'}); tr.appendChild(pentaTitle);
  const pentaRow=mkRow('Active/Total', colors.pentaRed); tr.appendChild(pentaRow.row); root.appendChild(tr);

  // Right-bottom quick controls (hide/show)
  const rb=document.createElement('div'); Object.assign(rb.style,{position:'absolute', right:'20px', bottom:'20px', pointerEvents:'auto'}); const toggle=document.createElement('button'); toggle.innerHTML='👁'; Object.assign(toggle.style,{cursor:'pointer', padding:'10px',borderRadius:'50%', backgroundColor:colors.background, color:colors.text, border:'1px solid rgba(255,255,255,0.2)'}); let visible=true; toggle.onclick=()=>{ visible=!visible; tr.style.display=visible?'block':'none'; tl.style.display=visible?'block':'none'; toggle.innerHTML=visible?'👁':'👀'; }; rb.appendChild(toggle); root.appendChild(rb);

  const update=(d)=>{
    if(d.planetLevel!==undefined){ lvlInfo.textContent = d.planetLevel===0? 'BASE LEVEL' : `PLANET LEVEL: ${d.planetLevel}`; select.value = d.planetLevel; }
    const upd=(stat,{active,total})=> stat.textContent = `${active}/${total} (${Math.round(active/total*100)}%)`;
    if(d.hexData){ upd(solar.stat, d.hexData.solar); upd(em.stat, d.hexData.em); upd(grav.stat, d.hexData.gravity); upd(dark.stat, d.hexData.darkEnergy); }
    if(d.pentaData){ upd(pentaRow.stat, d.pentaData); }
  };

  document.body.appendChild(root);
  window.updateLivingHubUI = update; window.getLivingHubData = ()=>data;
  return { updateLivingHubUI:update };
}