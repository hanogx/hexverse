import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline, Box } from '@mui/material';
import { SelectionScreen } from './components/SelectionScreen';

// Create theme matching HexVerse design
const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#00E5FF',
      light: '#4AEEFF',
      dark: '#00B2CC',
    },
    secondary: {
      main: '#8B5CF6',
      light: '#A78BFA',
      dark: '#7C3AED',
    },
    background: {
      default: '#05070B',
      paper: '#0B1324',
    },
    text: {
      primary: '#E8F0FF',
      secondary: '#9FB0C7',
    },
  },
  typography: {
    fontFamily: 'Inter, Rajdhani, system-ui, -apple-system, sans-serif',
  },
  shape: {
    borderRadius: 12,
  },
});

const hexGames = [
  {
    key: 'solar',
    name: 'Solar',
    description: 'Solar energy manipulation',
    available: true,
    cost: 1,
  },
  {
    key: 'em',
    name: 'EM',
    description: 'Electromagnetic fields',
    available: true,
    cost: 1,
  },
  {
    key: 'gravity',
    name: 'Gravity',
    description: 'Gravitational forces',
    available: true,
    cost: 1,
  },
  {
    key: 'dark',
    name: 'Dark Energy',
    description: 'Dark matter manipulation',
    available: false, // Example of locked game
    cost: 1,
  },
];

function App() {
  const handleGameSelect = (gameKey: string) => {
    console.log(`Starting ${gameKey} game...`);
    // In real implementation, this would start the selected game
  };

  const handleBackToHub = () => {
    console.log('Returning to hub...');
    // In real implementation, this would navigate to the main hub
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ 
        width: '100vw', 
        height: '100vh', 
        background: 'radial-gradient(900px 600px at 20% 20%, #0d1730 0%, rgba(0,0,0,.6) 60%), #000',
        overflow: 'hidden'
      }}>
        <SelectionScreen
          title="Hex Runs"
          games={hexGames}
          onGameSelect={handleGameSelect}
          onBackToHub={handleBackToHub}
        />
      </Box>
    </ThemeProvider>
  );
}

export default App;