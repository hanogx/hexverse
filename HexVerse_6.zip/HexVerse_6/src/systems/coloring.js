import { levelData } from './levelData.js';

// Dış yüzeyler: pentagonları kırmızı, hex'leri koyu gri (vertex color)
export function colorFaces(goldberg, level){
  const L = levelData[level];

  // Yüz bilgileri
  const T = L.m*L.m + L.m*L.n + L.n*L.n;
  const totalFaces = 10*T + 2;
  const nbFaces = goldberg.goldbergData?.nbFaces
    ?? goldberg.goldbergData?.faceCenters?.length
    ?? totalFaces;

  let faceSizes = goldberg.goldbergData?.faceSizes;
  if (!faceSizes || faceSizes.length !== nbFaces) {
    faceSizes = Array.from({length: nbFaces}, (_,i)=> i<12?5:6);
  }

  const colset = [];
  for (let i=0;i<nbFaces;i++){
    if (faceSizes[i] === 5){
      // Pentagons: soft kırmızı (dış)
      colset.push([i,i,new BABYLON.Color4(0.4,0.1,0.1,1)]);
    } else {
      // Hexagons: koyu gri metalik ton
      colset.push([i,i,new BABYLON.Color4(0.2,0.2,0.22,1)]);
    }
  }
  goldberg.setGoldbergFaceColors(colset);
  return goldberg;
}

// İç yüzeyler: level dağılımına göre parlak renkler + emissive materyal
export function colorInner(goldberg, level){
  const L = levelData[level];

  const T = L.m*L.m + L.m*L.n + L.n*L.n;
  const totalFaces = 10*T + 2;

  const nbFaces = goldberg.goldbergData?.nbFaces
    ?? goldberg.goldbergData?.faceCenters?.length
    ?? totalFaces;

  let faceSizes = goldberg.goldbergData?.faceSizes;
  if (!faceSizes || faceSizes.length !== nbFaces) {
    faceSizes = Array.from({length: nbFaces}, (_,i)=> i<12?5:6);
  }

  const hexIdx=[], pentIdx=[];
  for (let i=0;i<nbFaces;i++){
    (faceSizes[i]===6?hexIdx:pentIdx).push(i);
  }

  const colset = [];
  // Pentagons: parlak kırmızı (inner)
  pentIdx.forEach(i => colset.push([i,i,new BABYLON.Color4(1.0,0.2,0.2,1)]));

  let k=0;
  const push = (c,n)=>{ for(let i=0;i<n && k<hexIdx.length;i++,k++) colset.push([hexIdx[k],hexIdx[k], c]); };
  push(new BABYLON.Color4(1.0,0.5,0.1,1), L.solar);    // turuncu
  push(new BABYLON.Color4(0.2,0.5,1.0,1), L.electro);  // mavi
  push(new BABYLON.Color4(0.2,0.9,0.4,1), L.gravity); // yeşil
  push(new BABYLON.Color4(0.8,0.2,1.0,1), L.dark);    // mor

  goldberg.setGoldbergFaceColors(colset);

  // İç materyal — hafif emissive
  const innerMaterial = new BABYLON.StandardMaterial("innerMaterial", goldberg.getScene());
  innerMaterial.emissiveColor = new BABYLON.Color3(0.3,0.3,0.3);
  innerMaterial.disableLighting = false;
  goldberg.material = innerMaterial;

  return goldberg;
}
