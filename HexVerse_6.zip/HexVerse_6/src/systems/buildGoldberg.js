import { levelData } from './levelData.js';
import { colorFaces, colorInner } from './coloring.js';

export function buildGoldberg(scene, glowLayer){
  // 🎨 Ayarlar (goldberg.html ile aynı değerler)
  const DEPTH = 0.12;
  const THICKNESS = 0.06;
  const EDGE_WIDTH = 0.5;

  let g = null, inner = null;
  let currentLevel = 0;

  // ---- goldberg.html'deki geometri yardımcıları ----
  const addFaceDepth = (goldberg, depth = 0.08) => {
    const positions = goldberg.getVerticesData(BABYLON.VertexBuffer.PositionKind);
    const normals   = goldberg.getVerticesData(BABYLON.VertexBuffer.NormalKind);
    if (positions && normals) {
      for (let i = 0; i < positions.length; i += 3) {
        positions[i]     += normals[i]     * depth;
        positions[i + 1] += normals[i + 1] * depth;
        positions[i + 2] += normals[i + 2] * depth;
      }
      goldberg.setVerticesData(BABYLON.VertexBuffer.PositionKind, positions);
      goldberg.refreshBoundingInfo();
    }
  };

  const addThickness = (goldberg, thickness = 0.1) => {
    if (thickness <= 0) return;
    const positions = goldberg.getVerticesData(BABYLON.VertexBuffer.PositionKind);
    const normals   = goldberg.getVerticesData(BABYLON.VertexBuffer.NormalKind);
    const indices   = goldberg.getIndices();
    if (!positions || !normals || !indices) return;

    const innerPositions = [];
    for (let i = 0; i < positions.length; i += 3) {
      innerPositions.push(
        positions[i]     - normals[i]     * thickness,
        positions[i + 1] - normals[i + 1] * thickness,
        positions[i + 2] - normals[i + 2] * thickness
      );
    }

    const newPositions = [...positions, ...innerPositions];
    const newNormals   = [...normals];
    for (let i = 0; i < normals.length; i += 3) {
      newNormals.push(-normals[i], -normals[i + 1], -normals[i + 2]);
    }

    const vertexCount = positions.length / 3;
    const newIndices  = [...indices];

    // iç yüzler (ters sıralı)
    for (let i = 0; i < indices.length; i += 3) {
      newIndices.push(
        indices[i + 2] + vertexCount,
        indices[i + 1] + vertexCount,
        indices[i]     + vertexCount
      );
    }

    // açık kenarları kapat
    const edges = new Map();
    for (let i = 0; i < indices.length; i += 3) {
      const addEdge = (v1, v2) => {
        const key = v1 < v2 ? `${v1}-${v2}` : `${v2}-${v1}`;
        edges.set(key, (edges.get(key) || 0) + 1);
      };
      addEdge(indices[i], indices[i + 1]);
      addEdge(indices[i + 1], indices[i + 2]);
      addEdge(indices[i + 2], indices[i]);
    }
    edges.forEach((count, edge) => {
      if (count === 1) {
        const [v1, v2] = edge.split('-').map(Number);
        newIndices.push(v1, v2, v2 + vertexCount, v1, v2 + vertexCount, v1 + vertexCount);
      }
    });

    goldberg.setVerticesData(BABYLON.VertexBuffer.PositionKind, newPositions);
    goldberg.setVerticesData(BABYLON.VertexBuffer.NormalKind,   newNormals);
    goldberg.setIndices(newIndices);
    goldberg.refreshBoundingInfo();
  };
  // ---------------------------------------------------

  const rebuild = () => {
    if (g) g.dispose();
    if (inner) inner.dispose();

    const { m, n } = levelData[currentLevel];

    // Dış Goldberg
    g = BABYLON.MeshBuilder.CreateGoldberg('g', { m, n, updatable: true }, scene);
    addFaceDepth(g, DEPTH);
    addThickness(g, THICKNESS);

    g.rotationQuaternion = BABYLON.Quaternion.Identity();

    // Dış yüzey renkleri (hex koyu gri, pentagon kırmızı soft)
    colorFaces(g, currentLevel);

    // Dış materyal (vertex color + speküler)
    const mat = new BABYLON.StandardMaterial('outerGoldbergMaterial', scene);
    mat.specularColor = new BABYLON.Color3(0.1, 0.1, 0.1);
    mat.specularPower = 64;
    mat.useVertexColors = true;
    g.material = mat;

    // Kenar çizgileri (mavi)
    g.enableEdgesRendering();
    g.edgesWidth = EDGE_WIDTH;
    g.edgesColor = new BABYLON.Color4(0.5, 0.7, 1.0, 1.0);

    // İç Goldberg
    inner = BABYLON.MeshBuilder.CreateGoldberg('innerGoldberg', { m, n, updatable: true }, scene);
    inner.scaling = new BABYLON.Vector3(0.99, 0.99, 0.99);
    colorInner(inner, currentLevel);
    inner.parent = g;

    // Glow dahil et
    if (glowLayer) {
      glowLayer.addIncludedOnlyMesh(g);
      glowLayer.addIncludedOnlyMesh(inner);
    }
  };

  const updateLevelInfo = ()=>{/* UI modülü dolduracak */};

  // İlk kurulum
  rebuild();

  return {
    goldberg: g,
    innerGoldberg: inner,
    getLevel: () => currentLevel,
    setLevel: (lv) => { currentLevel = lv; rebuild(); },
    updateLevelInfo
  };
}
