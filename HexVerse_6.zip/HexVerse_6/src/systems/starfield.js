export function createStarfield(scene){
  const starSphere = BABYLON.MeshBuilder.CreateSphere('starSphere', { diameter: 160, segments: 1 }, scene);
  starSphere.isVisible = false;

  const dt = new BABYLON.DynamicTexture('starTexture', 64, scene, false);
  const ctx = dt.getContext();
  const draw = ()=>{
    ctx.clearRect(0,0,64,64);
    const cx=32, cy=32, r=16; const grad = ctx.createRadialGradient(cx,cy,0,cx,cy,r);
    grad.addColorStop(0,'rgba(255,255,255,1)'); grad.addColorStop(0.2,'rgba(240,240,255,0.9)');
    grad.addColorStop(0.5,'rgba(200,200,255,0.4)'); grad.addColorStop(1,'rgba(100,100,200,0)');
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle = 'rgba(200,200,255,0.3)'; ctx.lineWidth = 1;
    for(let i=0;i<4;i++){ const a=(Math.PI/4)*i; ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+Math.cos(a)*64, cy+Math.sin(a)*64); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(200,200,255,0.15)';
    for(let i=0;i<4;i++){ const a=(Math.PI/4)*(i+0.5); ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+Math.cos(a)*64*0.7, cy+Math.sin(a)*64*0.7); ctx.stroke(); }
    dt.update();
  };
  draw();

  const ps = new BABYLON.ParticleSystem('stars', 3000, scene);
  ps.particleTexture = dt; const em = new BABYLON.SphereParticleEmitter();
  em.radius = 80; em.radiusRange = 0.2; ps.particleEmitterType = em; ps.emitter = starSphere;
  ps.minSize=0.2; ps.maxSize=0.8; ps.minLifeTime=Number.MAX_SAFE_INTEGER; ps.maxLifeTime=Number.MAX_SAFE_INTEGER;
  ps.minEmitPower=0; ps.maxEmitPower=0; ps.direction1 = new BABYLON.Vector3(0,0,0); ps.direction2 = new BABYLON.Vector3(0,0,0);
  ps.manualEmitCount = 3000; const ages=[]; ps.updateFunction=(particles)=>{
    for(let i=0;i<particles.length;i++){
      const p=particles[i]; if(p.twinkleSpeed===undefined){
        p.twinkleSpeed = 0.01 + Math.random()*0.015; p.twinkleOffset = Math.random()*100; ages[i]=0;
        const t=Math.random(); if(t>0.9) p.baseColor=new BABYLON.Color4(1,0.6,0.6,1); else if(t>0.7) p.baseColor=new BABYLON.Color4(0.8,0.8,1,1); else if(t>0.5) p.baseColor=new BABYLON.Color4(1,0.8,0.6,1); else p.baseColor=new BABYLON.Color4(1,1,1,1);
        const s=Math.random(); if(s>0.97){ p.size=1.0; p.twinkleSpeed=0.001+Math.random()*0.003; } else if(s>0.85){ p.size=0.7; p.twinkleSpeed=0.002+Math.random()*0.005; } else if(s>0.5){ p.size=0.4; p.twinkleSpeed=0.004+Math.random()*0.008; } else { p.size=0.2; p.twinkleSpeed=0.006+Math.random()*0.012; }
      }
      ages[i]=(ages[i]||0)+0.016; const a=0.2 + 0.8*Math.abs(Math.sin(ages[i]*p.twinkleSpeed + p.twinkleOffset));
      p.color = new BABYLON.Color4(p.baseColor.r, p.baseColor.g, p.baseColor.b, a);
    }
  }; ps.start();
}