# Hexverse — Build & Run

## Requirements
- Node.js 18+
- NPM (or pnpm/yarn)

## Dev server
```bash
npm i
npm run dev
# open http://localhost:5173
# Pages:
#  - /index.html   (Living Hub)
#  - /hexrun.html  (Hex Run)
#  - /pentarun.html (Penta Run)
```

## Build
```bash
npm run build
npm run preview   # serves dist/
```

## Mobile (Capacitor) — next step
```bash
npm i -D @capacitor/cli
npm i @capacitor/core
npx cap init hexverse com.hexverse.app
npm run build
npx cap add android
npx cap add ios
npx cap copy
npx cap open android   # Android Studio
npx cap open ios       # Xcode
```

## Notes
- Placeholder audio files are under `assets/audio/`. Replace `click.mp3`, `hit.mp3`, `reward.mp3`, `ambient.mp3` with real assets.
- If you keep using CDN Babylon scripts, ensure network is available. Later we can switch to `@babylonjs/*` ESM packages for full bundling.
- For production we will add: Firebase Analytics/Remote Config, Auth, AdMob/RevenueCat, Sentry, etc.
