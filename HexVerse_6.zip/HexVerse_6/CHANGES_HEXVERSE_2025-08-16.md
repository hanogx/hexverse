# Hexverse UI Unify & Cleanup — 2025‑08‑16

## Neler değişti?
1) **Buton dili tekleştirildi (hx-*)**
   - `hexrun` seçim ekranı Penta ile aynı `hx-card + ENTER bar` ve aynı font/ölçeklemeyi kullanıyor.
   - Dosya: `src/hexrun/ui/selectionUI.js` tamamen güncellendi.

2) **Core Stage akışı netleştirildi**
   - Penta seçim ekranı (normal mod): **Core Stage gizli**.
   - Hub → **Enter Core** ile gidildiğinde (`pentarun.html?mode=core`): **sadece Core Stage (13)** listelenir.
   - Dosya: `src/pentarun/legacyEntry.js` (URL param okuma + filtre).

3) **Back davranışı ayrıştırıldı**
   - Seçim ekranlarında yalnız **Back to Hub** var.
   - Run içindeyken ayrı, **kayan** `Back` butonu var:
     - HexRun: `backInRunHex` (seçime döndürür).
     - Penta/Core: `backInRunPenta` (seçime döndürür).
   - Run → Select dönüşlerinde in‑run back otomatik temizlenir.

4) **Temizlik (kullanılmayan/dublike)**
   - Kaldırıldı:  
     - `src/hexrun/legacyEntry.js`  
     - `src/hexrun/input/joystick3D.js`  
     - `src/hexrun/ui/Joystick3DController.js`  
     - `src/hexrun/ui/GameHUD.js`  
     - `src/pentarun/entry_mod.js`  
     - `src/pentarun/main.js`  
     - `src/pentarun/ui/stageSelect.js`  
     - `src/_unused/` klasörü
   - Bu dosyalar projede hiçbir yerden **import** edilmiyordu.

## Nasıl test edilir?
- **Hub → Enter Penta**: 1–12 görünür, Core görünmez. Bir stage’e gir, sol üst **Back** ile seçime dön.
- **Hub → Enter Core**: yalnız **Core Stage** görünür. Gir, sol üst **Back** ile seçime dön.
- **Hub → Enter Hex**: dört yüz (Solar/EM/Gravity/Dark) **aynı kart/ENTER barı** ile görünür. Gir, sol üst **Back** ile Hex seçime dön.

## Notlar
- Hex/Penta buton ölçeklemesi `theme.css` içindeki `clamp()` değerleriyle **aynı** davranır.
- İleride yeni ekranlar için de `hx-overlay`, `hx-list`, `hx-card`, `hx-bar`, `hx-btn` kullanmaya devam edersen tasarım dili tutarlı kalır.
