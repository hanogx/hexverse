import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
  base: './',
  build: {
    rollupOptions: {
      input: {
        hub: resolve(__dirname, 'index.html'),
        hexrun: resolve(__dirname, 'hexrun.html'),
        pentarun: resolve(__dirname, 'pentarun.html'),
      }
    }
  },
  server: {
    host: true,
    port: 5173
  }
});
